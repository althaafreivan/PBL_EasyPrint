# EasyPrint — Sistem Informasi Pemesanan & Manajemen Pesanan Percetakan

UMKM **Restu Ibu Print & Fotocopy** · PBL Terintegrasi TI Semester 3 · Kelompok 2 TI-2D

Versi ini adalah hasil **integrasi** Frontend (Najwa), Backend (Fawas & Daniel/Rama), dan database PostgreSQL tim
menjadi satu aplikasi yang berjalan penuh — sesuai arsitektur SOP *pblguide*:

```
Browser ──► Frontend Native PHP  (http://127.0.0.1:3000)   tanpa koneksi database
                 │  cURL (api_client.php) + fetch() via api-proxy.php
                 ▼
            Backend REST API      (http://127.0.0.1:8000)   JSON murni
                 │  PDO (prepared statement)
                 ▼
            PostgreSQL            easyprint_db
```

Laporan analisis lengkap (temuan bug, kepatuhan requirement, daftar perubahan): **[docs/ANALISIS_INTEGRASI.md](docs/ANALISIS_INTEGRASI.md)**
Referensi endpoint: **[docs/API.md](docs/API.md)**

---

## 1. Kebutuhan

| Komponen | Versi | Catatan |
|---|---|---|
| PHP | 8.1+ (diuji 8.3) | ekstensi `pdo_pgsql`, `curl`, `fileinfo`, `mbstring` aktif |
| PostgreSQL | 14+ (dump tim dari 18.6, diuji juga di 16) | pgAdmin / Laragon / psql |
| Browser | Chrome / Edge / Firefox terbaru | |

> **Windows (XAMPP/Laragon):** buka `php.ini`, pastikan baris `extension=pdo_pgsql`, `extension=pgsql`,
> `extension=curl`, `extension=fileinfo` tidak diawali `;`.

## 2. Siapkan database

**Cara cepat (disarankan)** — satu file berisi struktur + migrasi + data uji:

```bash
createdb -U postgres easyprint_db
psql -U postgres -d easyprint_db -f database/easyprint_db_lengkap.sql
```

Di pgAdmin: klik kanan *Databases* → *Create* → `easyprint_db`, lalu buka *Query Tool*, buka file
`database/easyprint_db_lengkap.sql`, tekan **F5**.

**Cara bertahap** (untuk melihat perubahan apa saja yang ditambahkan ke dump asli):

```bash
psql -U postgres -d easyprint_db -f database/easy_print.sql                       # dump asli tim (tidak diubah)
psql -U postgres -d easyprint_db -f database/migrations/001_integrasi_fe_be.sql   # perubahan skema untuk integrasi
psql -U postgres -d easyprint_db -f database/seed/002_data_uji.sql                # data uji realistis (opsional)
```

> Dump asli dibuat dengan pg_dump 18 dan berisi perintah `\restrict` serta `SET transaction_timeout`.
> Jika PostgreSQL Anda versi < 17, hapus tiga baris tersebut atau gunakan `easyprint_db_lengkap.sql`.

## 3. Jalankan backend (port 8000)

```bash
cd backend
# isi password PostgreSQL laptop Anda (pilih salah satu):
#   a) PowerShell :  $env:DB_PASS="password_anda"
#   b) Git Bash   :  export DB_PASS=password_anda
#   c) salin config/env.example.php -> config/env.php lalu isi DB_PASS
php -S 127.0.0.1:8000 -t public
```

Cek: buka <http://127.0.0.1:8000/api/health> → `{"status":"success", ... "database":"easyprint_db"}`

## 4. Jalankan frontend (port 3000) — terminal baru

```bash
cd frontend
php -S 127.0.0.1:3000 -t public
```

Buka <http://127.0.0.1:3000>. Jika backend tidak di `127.0.0.1:8000`, set `API_BASE_URL`
(mis. `$env:API_BASE_URL="http://192.168.1.10:8000/api"`).

## 5. Akun uji

Semua akun memakai password **`EasyPrintTest2026!`**

| Peran | Email | Halaman awal |
|---|---|---|
| Owner | `owner@easyprint.com` | Dashboard Eksekutif |
| Admin / Operator | `operator@easyprint.com` | Dashboard Operasional |
| Pelanggan | `ahmad@example.com` (punya banyak pesanan) | Dashboard Pelanggan |
| Pelanggan | `sinta.maharani@example.com` · `rizky.pratama@example.com` · dll. | |

Cek pesanan tanpa login (halaman *Cek Pesanan*): nomor `RI-20261108-934` + telepon `081234567890`.

## 6. Skenario demo (± 5 menit, cocok untuk UAT / Expo)

1. **Pelanggan** `ahmad@example.com` → *Buat Pesanan* → Print Dokumen → pilih *Print A4 Warna*, 20 lembar × 2 eks,
   Jilid Spiral, unggah PDF → *Selanjutnya* → centang → *Kirim Pesanan*. Estimasi harga dihitung otomatis; total final
   dihitung ulang oleh backend.
2. **Admin** `operator@easyprint.com` → *Antrean Pesanan* → klik pesanan tadi: terlihat item, **Preview berkas**,
   dan **kebutuhan bahan vs stok**. Klik *Verifikasi* → *Proses* (stok terpotong otomatis, tercatat di log stok) → *Selesai*.
3. Masih di admin → *Kasir & Pengambilan* → pilih pesanan di "Siap diambil" → metode QRIS → *Konfirmasi & Ambil* → struk.
4. **DEC-02 (stok habis):** pesanan `RI-20261109-777` (hard cover) berstatus *Tertunda – Stok Tidak Tersedia*.
   Di *Pemantauan Stok* → *Restock* Hard Cover A4 10 pcs → kembali ke antrean → *Coba proses* → berhasil.
5. **Tolak:** pada pesanan Pending klik *Tolak*, isi alasan → pelanggan melihat alasan di halaman tracking.
6. **Owner** `owner@easyprint.com` → Dashboard (KPI, tren 7 hari, peringatan reorder point, layanan populer) →
   *Laporan & Analitik* (filter periode, sirkulasi bahan masuk/keluar, ekspor CSV/PDF) → *Master Layanan* (CRUD layanan &
   konfigurasi bahan) → *Manajemen Bahan* (CRUD bahan, reorder point, pasokan masuk).
7. Kembali sebagai pelanggan: lonceng notifikasi berisi setiap perubahan status; halaman tracking menampilkan
   timeline lengkap dan tombol nota.

## 7. Struktur folder

```
easyprint/
├── backend/                     REST API (JSON murni)
│   ├── public/index.php         front controller: CORS + tabel rute + penanganan error
│   ├── config/database.php      koneksi PDO (env DB_*), env.example.php
│   ├── core/http.php, auth.php  helper respons/validasi & autentikasi Bearer multi-role
│   ├── controllers/             Auth, Layanan(+BOM), Order, Stok, Notifikasi, Dashboard(+Laporan)
│   ├── models/StokModel.php     potong stok berbasis Bill of Materials (FOR UPDATE)
│   └── uploads/                 berkas PDF/DOCX pelanggan
├── frontend/                    Native PHP, tidak mengakses database
│   ├── public/                  entry point tiap halaman + api-proxy.php, file.php, logout.php, assets/
│   ├── pages/                   isi halaman (16+ layar)
│   ├── components/              navbar, sidebar, topbar notifikasi, stepper status
│   └── includes/                config, api_client.php (cURL), auth.php (sesi), helpers.php
├── database/
│   ├── easy_print.sql           dump asli tim (tidak diubah)
│   ├── migrations/001_integrasi_fe_be.sql
│   ├── seed/002_data_uji.sql + generate_seed.py
│   └── easyprint_db_lengkap.sql gabungan siap restore
└── docs/                        ANALISIS_INTEGRASI.md, API.md
```

## 8. Masalah umum

| Gejala | Penyebab & solusi |
|---|---|
| Halaman frontend: "Server backend tidak dapat dihubungi" | Backend belum jalan di port 8000, atau `API_BASE_URL` salah. |
| `/api/health` → "Koneksi database gagal" | `DB_PASS` belum di-set / salah, atau database belum dibuat. |
| `could not find driver` | Ekstensi `pdo_pgsql` belum aktif di `php.ini`. |
| Upload gagal untuk berkas besar | Naikkan `upload_max_filesize` & `post_max_size` di `php.ini` (≥ 12M). Batas aplikasi 10 MB. |
| Login berhasil tapi langsung keluar lagi | Token kedaluwarsa 8 jam — login ulang. Pastikan jam laptop benar. |
