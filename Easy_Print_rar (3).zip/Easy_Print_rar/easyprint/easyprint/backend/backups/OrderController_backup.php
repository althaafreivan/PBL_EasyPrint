<?php
// backend/controllers/OrderController.php
// CP-2: Pengajuan pesanan + upload, riwayat, detail/tracking, invoice
// CP-3: Verifikasi admin, perubahan 6 status (+ Ditolak), potong stok otomatis

const STATUS_PESANAN = [
    'Pending', 'Diverifikasi', 'Diproses', 'Tertunda',
    'Tertunda - Stok Tidak Tersedia', 'Selesai', 'Diambil', 'Ditolak',
];

// Alur status yang diizinkan (state machine). Pending -> Diproses diizinkan
// agar admin bisa memverifikasi sekaligus memproses dalam satu langkah.
const TRANSISI_STATUS = [
    'Pending' => ['Diverifikasi', 'Diproses', 'Ditolak'],
    'Diverifikasi' => ['Diproses', 'Tertunda', 'Ditolak'],
    'Tertunda' => ['Diproses', 'Ditolak'],
    'Tertunda - Stok Tidak Tersedia' => ['Diproses', 'Ditolak'],
    'Diproses' => ['Selesai', 'Tertunda'],
    'Selesai' => ['Diambil'],
    'Diambil' => [],
    'Ditolak' => [],
];

const UPLOAD_MAKS = 10 * 1024 * 1024; // 10 MB

function upload_dir(): string
{
    return __DIR__ . '/../uploads/';
}

/** Ambil pesanan yang boleh dilihat aktor (pelanggan: miliknya saja). */
function order_find_for(array $aktor, int $id): array
{
    $sql = 'SELECT p.id, p.kode_pesanan, p.user_id, p.total_harga, p.status, p.catatan,
                   p.alasan_tolak, p.metode_bayar, p.dibayar_at, p.stok_dikurangi,
                   p.created_at, p.updated_at,
                   u.nama, u.email, u.no_telepon
            FROM public.pesanan p
            JOIN public.users u ON u.id = p.user_id
            WHERE p.id = :id';
    $params = ['id' => $id];
    if (!is_staff($aktor)) {
        $sql .= ' AND p.user_id = :uid';
        $params['uid'] = $aktor['id'];
    }
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetch() ?: fail('Pesanan tidak ditemukan.', 404);
}

function order_items(int $id): array
{
    $stmt = db()->prepare(
        'SELECT dp.id, dp.layanan_id, l.nama_layanan, l.kategori, l.satuan, l.harga AS harga_satuan,
                dp.jumlah, dp.subtotal, dp.file_dokumen, dp.spesifikasi
         FROM public.detail_pesanan dp
         JOIN public.layanan l ON l.id = dp.layanan_id
         WHERE dp.pesanan_id = :id ORDER BY dp.id'
    );
    $stmt->execute(['id' => $id]);
    return $stmt->fetchAll();
}

function order_riwayat(int $id): array
{
    $stmt = db()->prepare(
        'SELECT r.status_lama, r.status_baru, r.keterangan, r.created_at, u.nama AS oleh, u.role AS peran
         FROM public.riwayat_status r
         LEFT JOIN public.users u ON u.id = r.diubah_oleh
         WHERE r.pesanan_id = :id
         ORDER BY r.created_at, r.id'
    );
    $stmt->execute(['id' => $id]);
    return $stmt->fetchAll();
}

// ------------------------------------------------------------ POST /api/orders
function order_store(): void
{
    $user = require_user();
    $pdo = db();

    $isMultipart = stripos($_SERVER['CONTENT_TYPE'] ?? '', 'multipart/form-data') === 0;
    if ($isMultipart) {
        $data = $_POST;
        $items = json_decode((string) ($data['items'] ?? ''), true);
    } else {
        $data = body();
        $items = $data['items'] ?? null;
    }

    if (!is_array($items) || count($items) < 1 || count($items) > 50) {
        fail('Pesanan harus memiliki 1 sampai 50 item layanan.');
    }
    $catatan = str_input($data, 'catatan', 500);
}