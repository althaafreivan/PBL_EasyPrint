<?php
// backend/config/database.php
// Koneksi PDO ke PostgreSQL EasyPrint (konfigurasi lewat environment variable,
// sesuai SOP pblguide). Contoh di Windows (PowerShell):
//   $env:DB_PASS="password_postgres_kamu"; php -S 127.0.0.1:8000 -t public
// atau salin config/env.example.php menjadi config/env.php lalu isi nilainya.

if (is_file(__DIR__ . '/env.php')) {
    require_once __DIR__ . '/env.php';   // file lokal, tidak di-commit (.gitignore)
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $driver = getenv('DB_DRIVER') ?: 'pgsql';
    $host   = getenv('DB_HOST')   ?: '127.0.0.1';
    $port   = getenv('DB_PORT')   ?: '5432';
    $name   = getenv('DB_NAME')   ?: 'easyprint_db';
    $user   = getenv('DB_USER')   ?: 'postgres';
    $pass   = getenv('DB_PASS')   ?: 'EasyPrintTest2026!';

    $dsn = "$driver:host=$host;port=$port;dbname=$name";

    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $pdo = new PDO($dsn, $user, $pass, $options);
        // Samakan zona waktu database dengan outlet (WIB).
        $pdo->exec("SET TIME ZONE 'Asia/Jakarta'");
    } catch (PDOException $e) {
        error_log('Koneksi PostgreSQL gagal: ' . $e->getMessage());
        json_error('Koneksi database gagal. Periksa konfigurasi PostgreSQL.', 500);
    }

    return $pdo;
}
