<?php
// Dibuat oleh setup.php — kredensial PostgreSQL lokal laptop ini (jangan di-commit).
putenv('DB_HOST=127.0.0.1');
putenv('DB_PORT=5432');
putenv('DB_NAME=easyprint_db');
putenv('DB_USER=postgres');
putenv('DB_PASS=postgres');
