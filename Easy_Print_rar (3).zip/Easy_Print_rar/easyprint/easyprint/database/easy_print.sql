--
-- PostgreSQL database dump
--

\restrict LEAZB5cXNOTCxLcgGhzR8RSU9KSXSH1MIWulwjNew9wPbyd9X6MZ04v0HdVkSGf

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

-- Started on 2026-11-09 00:27:29

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 5 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- TOC entry 5147 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- TOC entry 244 (class 1255 OID 33643)
-- Name: fn_cek_harga_layanan(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_cek_harga_layanan() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.harga < 0 THEN
        RAISE EXCEPTION
            'Harga layanan tidak boleh negatif.';
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_cek_harga_layanan() OWNER TO postgres;

--
-- TOC entry 243 (class 1255 OID 33641)
-- Name: fn_cek_jumlah_detail(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_cek_jumlah_detail() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.jumlah <= 0 THEN
        RAISE EXCEPTION
            'Jumlah layanan harus lebih besar dari 0.';
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_cek_jumlah_detail() OWNER TO postgres;

--
-- TOC entry 241 (class 1255 OID 33637)
-- Name: fn_cek_stok_bahan(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_cek_stok_bahan() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.stok < 0 THEN
        RAISE EXCEPTION
            'Stok bahan tidak boleh negatif. Stok yang dimasukkan: %',
            NEW.stok;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_cek_stok_bahan() OWNER TO postgres;

--
-- TOC entry 240 (class 1255 OID 33635)
-- Name: fn_notifikasi_status_pesanan(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_notifikasi_status_pesanan() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF OLD.status IS DISTINCT FROM NEW.status THEN
        INSERT INTO notifikasi (pesanan_id, judul, pesan)
        VALUES (
            NEW.id,
            'Perubahan Status Pesanan',
            'Pesanan ' || NEW.kode_pesanan ||
            ' berubah status dari ' || OLD.status ||
            ' menjadi ' || NEW.status
        );
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_notifikasi_status_pesanan() OWNER TO postgres;

--
-- TOC entry 238 (class 1255 OID 33608)
-- Name: fn_ringkasan_pesanan(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_ringkasan_pesanan(p_tanggal_awal date, p_tanggal_akhir date) RETURNS TABLE(jumlah_pesanan bigint, total_nilai_pesanan numeric)
    LANGUAGE sql
    AS $$
    SELECT
        COUNT(*) AS jumlah_pesanan,
        COALESCE(SUM(p.total_harga), 0) AS total_nilai_pesanan
    FROM pesanan AS p
    WHERE p.created_at >= p_tanggal_awal
      AND p.created_at < p_tanggal_akhir + INTERVAL '1 day';
$$;


ALTER FUNCTION public.fn_ringkasan_pesanan(p_tanggal_awal date, p_tanggal_akhir date) OWNER TO postgres;

--
-- TOC entry 242 (class 1255 OID 33639)
-- Name: fn_update_status_bahan(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_update_status_bahan() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.stok <= 0 THEN
        NEW.status := 'habis';
    ELSIF NEW.stok <= NEW.reorder_point THEN
        NEW.status := 'kritis';
    ELSE
        NEW.status := 'tersedia';
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_update_status_bahan() OWNER TO postgres;

--
-- TOC entry 239 (class 1255 OID 33631)
-- Name: fn_update_total_pesanan(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_update_total_pesanan() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        UPDATE pesanan
        SET total_harga = COALESCE(
            (
                SELECT SUM(subtotal)
                FROM detail_pesanan
                WHERE pesanan_id = OLD.pesanan_id
            ), 0
        )
        WHERE id = OLD.pesanan_id;

        RETURN OLD;
    ELSE
        UPDATE pesanan
        SET total_harga = COALESCE(
            (
                SELECT SUM(subtotal)
                FROM detail_pesanan
                WHERE pesanan_id = NEW.pesanan_id
            ), 0
        )
        WHERE id = NEW.pesanan_id;

        IF TG_OP = 'UPDATE'
           AND OLD.pesanan_id <> NEW.pesanan_id THEN
            UPDATE pesanan
            SET total_harga = COALESCE(
                (
                    SELECT SUM(subtotal)
                    FROM detail_pesanan
                    WHERE pesanan_id = OLD.pesanan_id
                ), 0
            )
            WHERE id = OLD.pesanan_id;
        END IF;

        RETURN NEW;
    END IF;
END;
$$;


ALTER FUNCTION public.fn_update_total_pesanan() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 237 (class 1259 OID 33611)
-- Name: auth_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.auth_tokens OWNER TO postgres;

--
-- TOC entry 236 (class 1259 OID 33610)
-- Name: auth_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_tokens ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.auth_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 224 (class 1259 OID 33463)
-- Name: bahan_baku; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bahan_baku (
    id integer NOT NULL,
    nama_bahan character varying(100) NOT NULL,
    stok numeric(12,4) DEFAULT 0 NOT NULL,
    satuan character varying(20) NOT NULL,
    reorder_point numeric(10,2) DEFAULT 5 NOT NULL,
    status character varying(20) DEFAULT 'tersedia'::character varying NOT NULL,
    harga_satuan numeric(10,2) DEFAULT 0 NOT NULL,
    CONSTRAINT bahan_baku_harga_satuan_check CHECK ((harga_satuan >= (0)::numeric)),
    CONSTRAINT bahan_baku_reorder_point_check CHECK ((reorder_point >= (0)::numeric)),
    CONSTRAINT bahan_baku_status_check CHECK (((status)::text = ANY ((ARRAY['tersedia'::character varying, 'kritis'::character varying, 'habis'::character varying])::text[]))),
    CONSTRAINT bahan_baku_stok_check CHECK ((stok >= (0)::numeric))
);


ALTER TABLE public.bahan_baku OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 33462)
-- Name: bahan_baku_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.bahan_baku ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.bahan_baku_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 226 (class 1259 OID 33484)
-- Name: bahan_layanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bahan_layanan (
    id integer NOT NULL,
    layanan_id integer NOT NULL,
    bahan_baku_id integer NOT NULL,
    jumlah_kebutuhan numeric(10,4) NOT NULL,
    CONSTRAINT bahan_layanan_jumlah_kebutuhan_check CHECK ((jumlah_kebutuhan > (0)::numeric))
);


ALTER TABLE public.bahan_layanan OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 33483)
-- Name: bahan_layanan_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.bahan_layanan ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.bahan_layanan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 230 (class 1259 OID 33533)
-- Name: detail_pesanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detail_pesanan (
    id integer NOT NULL,
    pesanan_id integer NOT NULL,
    layanan_id integer NOT NULL,
    jumlah integer NOT NULL,
    subtotal numeric(12,2) NOT NULL,
    file_dokumen character varying(255),
    CONSTRAINT detail_pesanan_jumlah_check CHECK ((jumlah > 0)),
    CONSTRAINT detail_pesanan_subtotal_check CHECK ((subtotal >= (0)::numeric))
);


ALTER TABLE public.detail_pesanan OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 33532)
-- Name: detail_pesanan_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.detail_pesanan ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.detail_pesanan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 222 (class 1259 OID 33450)
-- Name: layanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.layanan (
    id integer NOT NULL,
    nama_layanan character varying(100) NOT NULL,
    harga numeric(10,2) NOT NULL,
    satuan character varying(20) NOT NULL,
    deskripsi text,
    CONSTRAINT layanan_harga_check CHECK ((harga >= (0)::numeric))
);


ALTER TABLE public.layanan OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 33449)
-- Name: layanan_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.layanan ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.layanan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 232 (class 1259 OID 33556)
-- Name: notifikasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifikasi (
    id integer NOT NULL,
    pesanan_id integer,
    judul character varying(100) NOT NULL,
    pesan text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notifikasi OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 33555)
-- Name: notifikasi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.notifikasi ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.notifikasi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 234 (class 1259 OID 33574)
-- Name: notifikasi_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifikasi_users (
    id integer NOT NULL,
    notifikasi_id integer NOT NULL,
    user_id integer NOT NULL,
    is_read boolean DEFAULT false NOT NULL
);


ALTER TABLE public.notifikasi_users OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 33573)
-- Name: notifikasi_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.notifikasi_users ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.notifikasi_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 228 (class 1259 OID 33507)
-- Name: pesanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pesanan (
    id integer NOT NULL,
    kode_pesanan character varying(50) NOT NULL,
    user_id integer NOT NULL,
    total_harga numeric(12,2) DEFAULT 0 NOT NULL,
    status character varying(40) DEFAULT 'Pending'::character varying NOT NULL,
    catatan text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    stok_dikurangi boolean DEFAULT false NOT NULL,
    CONSTRAINT pesanan_status_check CHECK (((status)::text = ANY ((ARRAY['Pending'::character varying, 'Diverifikasi'::character varying, 'Diproses'::character varying, 'Tertunda'::character varying, 'Tertunda - Stok Tidak Tersedia'::character varying, 'Selesai'::character varying, 'Diambil'::character varying])::text[]))),
    CONSTRAINT pesanan_total_harga_check CHECK ((total_harga >= (0)::numeric))
);


ALTER TABLE public.pesanan OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 33506)
-- Name: pesanan_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.pesanan ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.pesanan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 220 (class 1259 OID 33431)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    nama character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(255) NOT NULL,
    no_telepon character varying(20),
    role character varying(20) DEFAULT 'pelanggan'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['pelanggan'::character varying, 'admin'::character varying, 'owner'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 33430)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 235 (class 1259 OID 33603)
-- Name: v_detail_pesanan; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_detail_pesanan AS
 SELECT p.id AS pesanan_id,
    p.kode_pesanan,
    u.id AS pelanggan_id,
    u.nama AS nama_pelanggan,
    u.email,
    l.id AS layanan_id,
    l.nama_layanan,
    l.satuan,
    l.harga AS harga_satuan,
    dp.jumlah,
    dp.subtotal,
    p.total_harga,
    p.status,
    p.catatan,
    p.created_at
   FROM (((public.pesanan p
     JOIN public.users u ON ((p.user_id = u.id)))
     JOIN public.detail_pesanan dp ON ((dp.pesanan_id = p.id)))
     JOIN public.layanan l ON ((dp.layanan_id = l.id)));


ALTER VIEW public.v_detail_pesanan OWNER TO postgres;

--
-- TOC entry 5141 (class 0 OID 33611)
-- Dependencies: 237
-- Data for Name: auth_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_tokens (id, user_id, token_hash, expires_at, created_at) FROM stdin;
1	4	432e8d90709494f14351a475b19eb3ad12b689bd303b4c3d1cc8ba7d4ae72174	2026-10-21 01:50:48	2026-10-21 00:50:48.081301
2	4	57787811784c42fee71c0967e381cd07f139fd7086cf3f4d1a7f9677b33643b6	2026-10-21 01:59:28	2026-10-21 00:59:28.365351
3	4	defeaaf7259edd2ad4cab81f8943a9ff68be24f0314de24a88775731b195511e	2026-10-21 02:12:24	2026-10-21 01:12:24.397487
4	4	35025146db214bb7eccea23023ea424d8d0afa215d7e1b38143922740fbad54d	2026-10-21 08:19:59	2026-10-21 07:19:59.277697
5	2	c02ee3f03cdfbd1904c152714caf6d201ced3ca2326d19c7d2d6698d9a6cefe9	2026-10-21 08:32:17	2026-10-21 07:32:17.762511
6	3	c54b2f0e8a9f7d4459761118b823933b748b51d081cca1cf8a5c38ce298d6f2b	2026-10-21 08:42:19	2026-10-21 07:42:19.738936
7	2	042a179d103ddd1f3e2ffe62dba49e5b759dc3afdf381574b2b5767a33158909	2026-10-21 09:06:06	2026-10-21 08:06:06.275258
8	5	0010dbb50e9593ab156fa39127bfe41586f193b91f1bacbabbe339bbf103e332	2026-10-29 09:29:04.981861	2026-10-29 01:29:04.981861
9	2	db1cdf0cc842647c08ea8d6b99ffb2908ca4c6b2722aea2d17700400d342cbcc	2026-10-29 10:26:15.434344	2026-10-29 02:26:15.434344
10	2	9b51a07081cf25e25eb806ca93ec06d8ca66514f894b244753b0b20829b5001e	2026-10-29 11:45:24.852635	2026-10-29 03:45:24.852635
11	2	09c4574974a7dbc7b0861e1d4747990cec205c13ee22f5583224b0d1a3022295	2026-10-29 12:41:32.454909	2026-10-29 04:41:32.454909
12	2	c9ee1fcca784b0d768de28839fe39274b391f27377e760ebf63cec04f50c5820	2026-10-29 12:45:33.974639	2026-10-29 04:45:33.974639
13	2	ae54e92f34803907dc30019d9ce3e8f37b0b315a8df59a5b50a6564db139eb9c	2026-11-08 03:26:53.306189	2026-11-07 19:26:53.306189
14	3	d7fa044ac698d66033cdde31fbaa75e460451e8356316f80e0add70b5eabbb2f	2026-11-09 00:19:09.862887	2026-11-08 16:19:09.862887
15	1	8e724b759c8353f533a7dec1732dc3e860ea947dd2ec9c861ad389a13753e297	2026-11-09 00:19:33.660474	2026-11-08 16:19:33.660474
16	2	8f16d452896209117e736c55b2090ccc2cbfbc43134940ccfe98ae9a444fae4f	2026-11-09 00:50:18.859026	2026-11-08 16:50:18.859026
17	2	4ca4982b16fb7da569ad8e2cb316c3de067b8ba71153db13bb11a83a0260db2c	2026-11-09 03:07:16.678945	2026-11-08 19:07:16.678945
18	2	0410fd8bb4178da76950acc222c241a5cdef89b4f68c3cdf9282471a32ecb91e	2026-11-09 07:18:27.085652	2026-11-08 23:18:27.085652
\.


--
-- TOC entry 5129 (class 0 OID 33463)
-- Dependencies: 224
-- Data for Name: bahan_baku; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bahan_baku (id, nama_bahan, stok, satuan, reorder_point, status, harga_satuan) FROM stdin;
2	Tinta Hitam Epson 003	2.0000	botol	3.00	kritis	85000.00
3	Mika Bening A4	50.0000	lembar	10.00	tersedia	500.00
1	Kertas HVS A4 70gr	14.9900	rim	5.00	tersedia	48000.00
\.


--
-- TOC entry 5131 (class 0 OID 33484)
-- Dependencies: 226
-- Data for Name: bahan_layanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bahan_layanan (id, layanan_id, bahan_baku_id, jumlah_kebutuhan) FROM stdin;
1	1	1	0.0020
2	2	3	2.0000
\.


--
-- TOC entry 5135 (class 0 OID 33533)
-- Dependencies: 230
-- Data for Name: detail_pesanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detail_pesanan (id, pesanan_id, layanan_id, jumlah, subtotal, file_dokumen) FROM stdin;
1	1	1	20	10000.00	dokumen_skripsi.pdf
2	1	2	1	5000.00	\N
3	3	1	2	1000.00	storage/uploads/42c7d93c93494bb41c576b79c1083e3e.docx
4	4	1	2	1000.00	\N
5	5	1	1	500.00	829c8ff856956f1fe841f06272488de9.pdf
6	6	1	2	1000.00	\N
7	7	1	2	1000.00	\N
8	8	2	26	130000.00	\N
9	9	1	1	500.00	1ed50a01248e60a0df50364b0eb33185.pdf
\.


--
-- TOC entry 5127 (class 0 OID 33450)
-- Dependencies: 222
-- Data for Name: layanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.layanan (id, nama_layanan, harga, satuan, deskripsi) FROM stdin;
1	Print HVS A4 Hitam Putih	500.00	lembar	Cetak hitam putih kertas HVS A4 70gr
2	Jilid Lakban	5000.00	buku	Jilid lakban hitam dengan mika bening
3	Cetak Brosur Glossy A4	2500.00	lembar	Cetak full color kertas Art Paper 150gr
\.


--
-- TOC entry 5137 (class 0 OID 33556)
-- Dependencies: 232
-- Data for Name: notifikasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifikasi (id, pesanan_id, judul, pesan, created_at) FROM stdin;
1	1	Pesanan Dibuat	Pesanan ORD-20261002-001 berhasil dibuat dan menunggu verifikasi.	2026-10-14 21:08:21.663971
3	4	Perubahan Status Pesanan	Pesanan RI-20261028-017 berubah status dari Pending menjadi Diproses	2026-10-29 02:52:36.690098
4	4	Update Status Pesanan	Pesanan Anda sedang diproses cetak oleh operator.	2026-10-29 02:52:36.690098
5	5	Perubahan Status Pesanan	Pesanan RI-20261028-976 berubah status dari Pending menjadi Diproses	2026-10-29 04:01:13.314779
6	7	Pesanan Dibuat	Pesanan RI-20261108-538 berhasil dibuat dan menunggu verifikasi.	2026-11-08 16:41:43.507018
7	7	Perubahan Status Pesanan	Pesanan RI-20261108-538 berubah status dari Pending menjadi Diverifikasi	2026-11-08 16:51:15.353999
8	7	Perubahan Status Pesanan	Pesanan RI-20261108-538 berubah status dari Diverifikasi menjadi Diproses	2026-11-08 17:20:25.498882
9	8	Pesanan Dibuat	Pesanan RI-20261108-445 berhasil dibuat dan menunggu verifikasi.	2026-11-08 17:27:33.480681
10	8	Perubahan Status Pesanan	Pesanan RI-20261108-445 berubah status dari Pending menjadi Tertunda - Stok Tidak Tersedia	2026-11-08 17:28:49.840544
11	9	Pesanan Dibuat	Pesanan RI-20261108-934 berhasil dibuat dan menunggu verifikasi.	2026-11-08 18:17:00.044272
12	9	Perubahan Status Pesanan	Pesanan RI-20261108-934 berubah status dari Pending menjadi Diverifikasi	2026-11-08 23:54:57.598049
\.


--
-- TOC entry 5139 (class 0 OID 33574)
-- Dependencies: 234
-- Data for Name: notifikasi_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifikasi_users (id, notifikasi_id, user_id, is_read) FROM stdin;
1	1	1	f
2	4	5	f
3	5	2	f
4	6	1	f
5	7	1	f
6	8	1	f
7	9	1	f
8	10	1	f
9	11	1	f
10	12	1	f
\.


--
-- TOC entry 5133 (class 0 OID 33507)
-- Dependencies: 228
-- Data for Name: pesanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pesanan (id, kode_pesanan, user_id, total_harga, status, catatan, created_at, stok_dikurangi) FROM stdin;
3	EP-20261020181710-18615b	4	1000.00	Diproses	Pesanan pengujian EasyPrint	2026-10-21 01:17:10.784144	f
1	ORD-20261002-001	1	15000.00	Pending	Tolong jilid lakban hitam, bagian depan mika bening	2026-10-14 21:08:21.663971	f
4	RI-20261028-017	5	1000.00	Diproses	Tes pengajuan pesanan CP-2	2026-10-29 01:35:50.899895	t
5	RI-20261028-976	2	500.00	Diproses	Test upload	2026-10-29 03:51:57.525154	t
6	RI-20261108-531	1	1000.00	Pending	Pengujian pesanan EasyPrint	2026-11-08 16:20:54.717101	f
7	RI-20261108-538	1	1000.00	Diproses	Tes notifikasi setelah perbaikan	2026-11-08 16:41:43.507018	t
8	RI-20261108-445	1	130000.00	Tertunda - Stok Tidak Tersedia	TEST CP3 - stok tidak mencukupi	2026-11-08 17:27:33.480681	f
9	RI-20261108-934	1	500.00	Diverifikasi	\N	2026-11-08 18:17:00.044272	f
\.


--
-- TOC entry 5125 (class 0 OID 33431)
-- Dependencies: 220
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, nama, email, password, no_telepon, role, created_at) FROM stdin;
1	Ahmad Fauzi	ahmad@example.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	081234567890	pelanggan	2026-10-14 21:08:21.663971
4	Uji Pelanggan	uji.pelanggan@example.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	081234567890	pelanggan	2026-10-21 00:06:38.105855
3	Pemilik Restu Ibu	owner@easyprint.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	081122334455	owner	2026-10-14 21:08:21.663971
5	Tes CP2	tes.cp2@example.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	081234567890	pelanggan	2026-10-29 01:28:55.405456
2	Operator Restu Ibu	operator@easyprint.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	089876543210	admin	2026-10-14 21:08:21.663971
\.


--
-- TOC entry 5168 (class 0 OID 0)
-- Dependencies: 236
-- Name: auth_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_tokens_id_seq', 18, true);


--
-- TOC entry 5169 (class 0 OID 0)
-- Dependencies: 223
-- Name: bahan_baku_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bahan_baku_id_seq', 3, true);


--
-- TOC entry 5170 (class 0 OID 0)
-- Dependencies: 225
-- Name: bahan_layanan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bahan_layanan_id_seq', 2, true);


--
-- TOC entry 5171 (class 0 OID 0)
-- Dependencies: 229
-- Name: detail_pesanan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.detail_pesanan_id_seq', 9, true);


--
-- TOC entry 5172 (class 0 OID 0)
-- Dependencies: 221
-- Name: layanan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.layanan_id_seq', 3, true);


--
-- TOC entry 5173 (class 0 OID 0)
-- Dependencies: 231
-- Name: notifikasi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifikasi_id_seq', 12, true);


--
-- TOC entry 5174 (class 0 OID 0)
-- Dependencies: 233
-- Name: notifikasi_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifikasi_users_id_seq', 10, true);


--
-- TOC entry 5175 (class 0 OID 0)
-- Dependencies: 227
-- Name: pesanan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pesanan_id_seq', 9, true);


--
-- TOC entry 5176 (class 0 OID 0)
-- Dependencies: 219
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- TOC entry 4956 (class 2606 OID 33621)
-- Name: auth_tokens auth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 4958 (class 2606 OID 33623)
-- Name: auth_tokens auth_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_token_hash_key UNIQUE (token_hash);


--
-- TOC entry 4938 (class 2606 OID 33482)
-- Name: bahan_baku bahan_baku_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bahan_baku
    ADD CONSTRAINT bahan_baku_pkey PRIMARY KEY (id);


--
-- TOC entry 4940 (class 2606 OID 33493)
-- Name: bahan_layanan bahan_layanan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bahan_layanan
    ADD CONSTRAINT bahan_layanan_pkey PRIMARY KEY (id);


--
-- TOC entry 4948 (class 2606 OID 33544)
-- Name: detail_pesanan detail_pesanan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_pesanan
    ADD CONSTRAINT detail_pesanan_pkey PRIMARY KEY (id);


--
-- TOC entry 4936 (class 2606 OID 33461)
-- Name: layanan layanan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.layanan
    ADD CONSTRAINT layanan_pkey PRIMARY KEY (id);


--
-- TOC entry 4950 (class 2606 OID 33567)
-- Name: notifikasi notifikasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifikasi
    ADD CONSTRAINT notifikasi_pkey PRIMARY KEY (id);


--
-- TOC entry 4952 (class 2606 OID 33583)
-- Name: notifikasi_users notifikasi_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifikasi_users
    ADD CONSTRAINT notifikasi_users_pkey PRIMARY KEY (id);


--
-- TOC entry 4944 (class 2606 OID 33526)
-- Name: pesanan pesanan_kode_pesanan_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pesanan
    ADD CONSTRAINT pesanan_kode_pesanan_key UNIQUE (kode_pesanan);


--
-- TOC entry 4946 (class 2606 OID 33524)
-- Name: pesanan pesanan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pesanan
    ADD CONSTRAINT pesanan_pkey PRIMARY KEY (id);


--
-- TOC entry 4942 (class 2606 OID 33495)
-- Name: bahan_layanan uq_bahan_layanan; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bahan_layanan
    ADD CONSTRAINT uq_bahan_layanan UNIQUE (layanan_id, bahan_baku_id);


--
-- TOC entry 4954 (class 2606 OID 33585)
-- Name: notifikasi_users uq_notifikasi_user; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifikasi_users
    ADD CONSTRAINT uq_notifikasi_user UNIQUE (notifikasi_id, user_id);


--
-- TOC entry 4932 (class 2606 OID 33448)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 4934 (class 2606 OID 33446)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4959 (class 1259 OID 33630)
-- Name: idx_auth_tokens_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_auth_tokens_expires_at ON public.auth_tokens USING btree (expires_at);


--
-- TOC entry 4960 (class 1259 OID 33629)
-- Name: idx_auth_tokens_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_auth_tokens_user_id ON public.auth_tokens USING btree (user_id);


--
-- TOC entry 4970 (class 2620 OID 33644)
-- Name: layanan trg_cek_harga_layanan; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_cek_harga_layanan BEFORE INSERT OR UPDATE OF harga ON public.layanan FOR EACH ROW EXECUTE FUNCTION public.fn_cek_harga_layanan();


--
-- TOC entry 4974 (class 2620 OID 33642)
-- Name: detail_pesanan trg_cek_jumlah_detail; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_cek_jumlah_detail BEFORE INSERT OR UPDATE OF jumlah ON public.detail_pesanan FOR EACH ROW EXECUTE FUNCTION public.fn_cek_jumlah_detail();


--
-- TOC entry 4971 (class 2620 OID 33654)
-- Name: bahan_baku trg_cek_stok_bahan; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_cek_stok_bahan BEFORE INSERT OR UPDATE OF stok ON public.bahan_baku FOR EACH ROW EXECUTE FUNCTION public.fn_cek_stok_bahan();


--
-- TOC entry 4973 (class 2620 OID 33636)
-- Name: pesanan trg_notifikasi_status_pesanan; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_notifikasi_status_pesanan AFTER UPDATE OF status ON public.pesanan FOR EACH ROW EXECUTE FUNCTION public.fn_notifikasi_status_pesanan();


--
-- TOC entry 4972 (class 2620 OID 33655)
-- Name: bahan_baku trg_update_status_bahan; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_update_status_bahan BEFORE INSERT OR UPDATE OF stok, reorder_point ON public.bahan_baku FOR EACH ROW EXECUTE FUNCTION public.fn_update_status_bahan();


--
-- TOC entry 4975 (class 2620 OID 33632)
-- Name: detail_pesanan trg_update_total_pesanan; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_update_total_pesanan AFTER INSERT OR DELETE OR UPDATE ON public.detail_pesanan FOR EACH ROW EXECUTE FUNCTION public.fn_update_total_pesanan();


--
-- TOC entry 4969 (class 2606 OID 33624)
-- Name: auth_tokens auth_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4961 (class 2606 OID 33501)
-- Name: bahan_layanan fk_bahan_layanan_bahan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bahan_layanan
    ADD CONSTRAINT fk_bahan_layanan_bahan FOREIGN KEY (bahan_baku_id) REFERENCES public.bahan_baku(id) ON DELETE CASCADE;


--
-- TOC entry 4962 (class 2606 OID 33496)
-- Name: bahan_layanan fk_bahan_layanan_layanan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bahan_layanan
    ADD CONSTRAINT fk_bahan_layanan_layanan FOREIGN KEY (layanan_id) REFERENCES public.layanan(id) ON DELETE CASCADE;


--
-- TOC entry 4964 (class 2606 OID 33550)
-- Name: detail_pesanan fk_detail_layanan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_pesanan
    ADD CONSTRAINT fk_detail_layanan FOREIGN KEY (layanan_id) REFERENCES public.layanan(id) ON DELETE RESTRICT;


--
-- TOC entry 4965 (class 2606 OID 33545)
-- Name: detail_pesanan fk_detail_pesanan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_pesanan
    ADD CONSTRAINT fk_detail_pesanan FOREIGN KEY (pesanan_id) REFERENCES public.pesanan(id) ON DELETE CASCADE;


--
-- TOC entry 4966 (class 2606 OID 33568)
-- Name: notifikasi fk_notifikasi_pesanan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifikasi
    ADD CONSTRAINT fk_notifikasi_pesanan FOREIGN KEY (pesanan_id) REFERENCES public.pesanan(id) ON DELETE SET NULL;


--
-- TOC entry 4967 (class 2606 OID 33586)
-- Name: notifikasi_users fk_notifikasi_users_notifikasi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifikasi_users
    ADD CONSTRAINT fk_notifikasi_users_notifikasi FOREIGN KEY (notifikasi_id) REFERENCES public.notifikasi(id) ON DELETE CASCADE;


--
-- TOC entry 4968 (class 2606 OID 33591)
-- Name: notifikasi_users fk_notifikasi_users_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifikasi_users
    ADD CONSTRAINT fk_notifikasi_users_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4963 (class 2606 OID 33527)
-- Name: pesanan fk_pesanan_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pesanan
    ADD CONSTRAINT fk_pesanan_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- TOC entry 5148 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO easyprint_app;


--
-- TOC entry 5149 (class 0 OID 0)
-- Dependencies: 237
-- Name: TABLE auth_tokens; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.auth_tokens TO easyprint_app;


--
-- TOC entry 5150 (class 0 OID 0)
-- Dependencies: 236
-- Name: SEQUENCE auth_tokens_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.auth_tokens_id_seq TO easyprint_app;


--
-- TOC entry 5151 (class 0 OID 0)
-- Dependencies: 224
-- Name: TABLE bahan_baku; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.bahan_baku TO easyprint_app;


--
-- TOC entry 5152 (class 0 OID 0)
-- Dependencies: 223
-- Name: SEQUENCE bahan_baku_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.bahan_baku_id_seq TO easyprint_app;


--
-- TOC entry 5153 (class 0 OID 0)
-- Dependencies: 226
-- Name: TABLE bahan_layanan; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.bahan_layanan TO easyprint_app;


--
-- TOC entry 5154 (class 0 OID 0)
-- Dependencies: 225
-- Name: SEQUENCE bahan_layanan_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.bahan_layanan_id_seq TO easyprint_app;


--
-- TOC entry 5155 (class 0 OID 0)
-- Dependencies: 230
-- Name: TABLE detail_pesanan; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.detail_pesanan TO easyprint_app;


--
-- TOC entry 5156 (class 0 OID 0)
-- Dependencies: 229
-- Name: SEQUENCE detail_pesanan_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.detail_pesanan_id_seq TO easyprint_app;


--
-- TOC entry 5157 (class 0 OID 0)
-- Dependencies: 222
-- Name: TABLE layanan; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.layanan TO easyprint_app;


--
-- TOC entry 5158 (class 0 OID 0)
-- Dependencies: 221
-- Name: SEQUENCE layanan_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.layanan_id_seq TO easyprint_app;


--
-- TOC entry 5159 (class 0 OID 0)
-- Dependencies: 232
-- Name: TABLE notifikasi; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.notifikasi TO easyprint_app;


--
-- TOC entry 5160 (class 0 OID 0)
-- Dependencies: 231
-- Name: SEQUENCE notifikasi_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.notifikasi_id_seq TO easyprint_app;


--
-- TOC entry 5161 (class 0 OID 0)
-- Dependencies: 234
-- Name: TABLE notifikasi_users; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.notifikasi_users TO easyprint_app;


--
-- TOC entry 5162 (class 0 OID 0)
-- Dependencies: 233
-- Name: SEQUENCE notifikasi_users_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.notifikasi_users_id_seq TO easyprint_app;


--
-- TOC entry 5163 (class 0 OID 0)
-- Dependencies: 228
-- Name: TABLE pesanan; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pesanan TO easyprint_app;


--
-- TOC entry 5164 (class 0 OID 0)
-- Dependencies: 227
-- Name: SEQUENCE pesanan_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.pesanan_id_seq TO easyprint_app;


--
-- TOC entry 5165 (class 0 OID 0)
-- Dependencies: 220
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.users TO easyprint_app;


--
-- TOC entry 5166 (class 0 OID 0)
-- Dependencies: 219
-- Name: SEQUENCE users_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.users_id_seq TO easyprint_app;


--
-- TOC entry 5167 (class 0 OID 0)
-- Dependencies: 235
-- Name: TABLE v_detail_pesanan; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.v_detail_pesanan TO easyprint_app;


-- Completed on 2026-11-09 00:27:30

--
-- PostgreSQL database dump complete
--

\unrestrict LEAZB5cXNOTCxLcgGhzR8RSU9KSXSH1MIWulwjNew9wPbyd9X6MZ04v0HdVkSGf

