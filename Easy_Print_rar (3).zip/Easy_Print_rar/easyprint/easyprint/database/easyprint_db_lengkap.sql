-- EasyPrint - database LENGKAP (dump asli tim + migrasi 001 + data uji 002).
-- Cara pakai: buat database kosong easyprint_db lalu jalankan file ini (psql / pgAdmin Query Tool).
-- Password semua akun: EasyPrintTest2026!

--
-- PostgreSQL database dump
--

\restrict hkAwllfPRJUgCi9SRPIZNUclIbQBs9flZDbyycGa6SJ4y4TSuif9jE8N43oFyQD

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: fn_cek_harga_layanan(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_cek_harga_layanan() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.harga < 0 THEN
        RAISE EXCEPTION
            'Harga layanan tidak boleh negatif.';
    END IF;

    RETURN NEW;
END;
$$;


--
-- Name: fn_cek_jumlah_detail(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_cek_jumlah_detail() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.jumlah <= 0 THEN
        RAISE EXCEPTION
            'Jumlah layanan harus lebih besar dari 0.';
    END IF;

    RETURN NEW;
END;
$$;


--
-- Name: fn_cek_stok_bahan(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_cek_stok_bahan() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.stok < 0 THEN
        RAISE EXCEPTION
            'Stok bahan tidak boleh negatif. Stok yang dimasukkan: %',
            NEW.stok;
    END IF;

    RETURN NEW;
END;
$$;


--
-- Name: fn_konteks(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_konteks(p_kunci text) RETURNS text
    LANGUAGE sql STABLE
    AS $$
    SELECT NULLIF(current_setting('easyprint.' || p_kunci, true), '');
$$;


--
-- Name: fn_log_mutasi_stok(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_log_mutasi_stok() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_lama  numeric := CASE WHEN TG_OP = 'INSERT' THEN 0 ELSE OLD.stok END;
    v_jenis text;
BEGIN
    IF NEW.stok = v_lama THEN
        RETURN NEW;
    END IF;

    v_jenis := COALESCE(fn_konteks('jenis_stok'),
                        CASE WHEN NEW.stok > v_lama THEN 'masuk' ELSE 'keluar' END);

    INSERT INTO riwayat_stok
        (bahan_baku_id, pesanan_id, jenis, jumlah, stok_sebelum, stok_sesudah,
         keterangan, user_id, created_at)
    VALUES
        (NEW.id,
         fn_konteks('pesanan_id')::integer,
         v_jenis,
         NEW.stok - v_lama,
         v_lama,
         NEW.stok,
         COALESCE(fn_konteks('keterangan_stok'),
                  CASE WHEN TG_OP = 'INSERT' THEN 'Stok awal' END),
         fn_konteks('user_id')::integer,
         COALESCE(fn_konteks('tanggal_stok')::timestamp, CURRENT_TIMESTAMP));

    RETURN NEW;
END;
$$;


--
-- Name: fn_log_status_pesanan(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_log_status_pesanan() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO riwayat_status (pesanan_id, status_lama, status_baru, keterangan, diubah_oleh)
        VALUES (NEW.id, NULL, NEW.status, 'Pesanan dibuat', NEW.user_id);
    ELSIF OLD.status IS DISTINCT FROM NEW.status THEN
        INSERT INTO riwayat_status (pesanan_id, status_lama, status_baru, keterangan, diubah_oleh)
        VALUES (NEW.id, OLD.status, NEW.status,
                fn_konteks('keterangan'),
                fn_konteks('user_id')::integer);
    END IF;
    RETURN NEW;
END;
$$;


--
-- Name: fn_notifikasi_status_pesanan(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_notifikasi_status_pesanan() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_id    integer;
    v_pesan text;
BEGIN
    IF OLD.status IS DISTINCT FROM NEW.status THEN
        v_pesan := 'Pesanan ' || NEW.kode_pesanan ||
                   ' berubah status dari ' || OLD.status ||
                   ' menjadi ' || NEW.status;

        IF fn_konteks('keterangan') IS NOT NULL THEN
            v_pesan := v_pesan || '. ' || fn_konteks('keterangan');
        END IF;

        INSERT INTO notifikasi (pesanan_id, judul, pesan)
        VALUES (NEW.id, 'Perubahan Status Pesanan', v_pesan)
        RETURNING id INTO v_id;

        INSERT INTO notifikasi_users (notifikasi_id, user_id)
        VALUES (v_id, NEW.user_id)
        ON CONFLICT DO NOTHING;
    END IF;

    RETURN NEW;
END;
$$;


--
-- Name: fn_peringatan_stok_kritis(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_peringatan_stok_kritis() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_id integer;
BEGIN
    -- Hanya saat status memburuk (tersedia -> kritis/habis, kritis -> habis).
    IF NEW.status IN ('kritis', 'habis')
       AND (TG_OP = 'INSERT' OR OLD.status IS DISTINCT FROM NEW.status)
       AND NOT (TG_OP = 'UPDATE' AND OLD.status = 'habis') THEN

        INSERT INTO notifikasi (pesanan_id, judul, pesan)
        VALUES (NULL,
                CASE WHEN NEW.status = 'habis' THEN 'Stok Habis' ELSE 'Stok Kritis' END,
                NEW.nama_bahan || ' tersisa ' || rtrim(rtrim(NEW.stok::text, '0'), '.')
                    || ' ' || NEW.satuan || ' (reorder point '
                    || rtrim(rtrim(NEW.reorder_point::text, '0'), '.') || ').')
        RETURNING id INTO v_id;

        INSERT INTO notifikasi_users (notifikasi_id, user_id)
        SELECT v_id, u.id FROM users u WHERE u.role IN ('admin', 'owner')
        ON CONFLICT DO NOTHING;
    END IF;

    RETURN NEW;
END;
$$;


--
-- Name: fn_ringkasan_pesanan(date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_ringkasan_pesanan(p_tanggal_awal date, p_tanggal_akhir date) RETURNS TABLE(jumlah_pesanan bigint, total_nilai_pesanan numeric)
    LANGUAGE sql
    AS $$
    SELECT
        COUNT(*) AS jumlah_pesanan,
        COALESCE(SUM(p.total_harga), 0) AS total_nilai_pesanan
    FROM pesanan AS p
    WHERE p.created_at >= p_tanggal_awal
      AND p.created_at < p_tanggal_akhir + INTERVAL '1 day';
$$;


--
-- Name: fn_set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- Name: fn_update_status_bahan(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_update_status_bahan() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.stok <= 0 THEN
        NEW.status := 'habis';
    ELSIF NEW.stok <= NEW.reorder_point THEN
        NEW.status := 'kritis';
    ELSE
        NEW.status := 'tersedia';
    END IF;

    RETURN NEW;
END;
$$;


--
-- Name: fn_update_total_pesanan(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_update_total_pesanan() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        UPDATE pesanan
        SET total_harga = COALESCE(
            (
                SELECT SUM(subtotal)
                FROM detail_pesanan
                WHERE pesanan_id = OLD.pesanan_id
            ), 0
        )
        WHERE id = OLD.pesanan_id;

        RETURN OLD;
    ELSE
        UPDATE pesanan
        SET total_harga = COALESCE(
            (
                SELECT SUM(subtotal)
                FROM detail_pesanan
                WHERE pesanan_id = NEW.pesanan_id
            ), 0
        )
        WHERE id = NEW.pesanan_id;

        IF TG_OP = 'UPDATE'
           AND OLD.pesanan_id <> NEW.pesanan_id THEN
            UPDATE pesanan
            SET total_harga = COALESCE(
                (
                    SELECT SUM(subtotal)
                    FROM detail_pesanan
                    WHERE pesanan_id = OLD.pesanan_id
                ), 0
            )
            WHERE id = OLD.pesanan_id;
        END IF;

        RETURN NEW;
    END IF;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: auth_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_tokens ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.auth_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bahan_baku; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bahan_baku (
    id integer NOT NULL,
    nama_bahan character varying(100) NOT NULL,
    stok numeric(12,4) DEFAULT 0 NOT NULL,
    satuan character varying(20) NOT NULL,
    reorder_point numeric(10,2) DEFAULT 5 NOT NULL,
    status character varying(20) DEFAULT 'tersedia'::character varying NOT NULL,
    harga_satuan numeric(10,2) DEFAULT 0 NOT NULL,
    CONSTRAINT bahan_baku_harga_satuan_check CHECK ((harga_satuan >= (0)::numeric)),
    CONSTRAINT bahan_baku_reorder_point_check CHECK ((reorder_point >= (0)::numeric)),
    CONSTRAINT bahan_baku_status_check CHECK (((status)::text = ANY (ARRAY[('tersedia'::character varying)::text, ('kritis'::character varying)::text, ('habis'::character varying)::text]))),
    CONSTRAINT bahan_baku_stok_check CHECK ((stok >= (0)::numeric))
);


--
-- Name: bahan_baku_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.bahan_baku ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.bahan_baku_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bahan_layanan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bahan_layanan (
    id integer NOT NULL,
    layanan_id integer NOT NULL,
    bahan_baku_id integer NOT NULL,
    jumlah_kebutuhan numeric(10,4) NOT NULL,
    CONSTRAINT bahan_layanan_jumlah_kebutuhan_check CHECK ((jumlah_kebutuhan > (0)::numeric))
);


--
-- Name: bahan_layanan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.bahan_layanan ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.bahan_layanan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: detail_pesanan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.detail_pesanan (
    id integer NOT NULL,
    pesanan_id integer NOT NULL,
    layanan_id integer NOT NULL,
    jumlah integer NOT NULL,
    subtotal numeric(12,2) NOT NULL,
    file_dokumen character varying(255),
    spesifikasi character varying(255),
    CONSTRAINT detail_pesanan_jumlah_check CHECK ((jumlah > 0)),
    CONSTRAINT detail_pesanan_subtotal_check CHECK ((subtotal >= (0)::numeric))
);


--
-- Name: detail_pesanan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.detail_pesanan ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.detail_pesanan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: layanan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.layanan (
    id integer NOT NULL,
    nama_layanan character varying(100) NOT NULL,
    harga numeric(10,2) NOT NULL,
    satuan character varying(20) NOT NULL,
    deskripsi text,
    kategori character varying(20) DEFAULT 'cetak'::character varying NOT NULL,
    aktif boolean DEFAULT true NOT NULL,
    CONSTRAINT layanan_harga_check CHECK ((harga >= (0)::numeric)),
    CONSTRAINT layanan_kategori_check CHECK (((kategori)::text = ANY ((ARRAY['cetak'::character varying, 'fotokopi'::character varying, 'finishing'::character varying])::text[])))
);


--
-- Name: layanan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.layanan ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.layanan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notifikasi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifikasi (
    id integer NOT NULL,
    pesanan_id integer,
    judul character varying(100) NOT NULL,
    pesan text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: notifikasi_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.notifikasi ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.notifikasi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notifikasi_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifikasi_users (
    id integer NOT NULL,
    notifikasi_id integer NOT NULL,
    user_id integer NOT NULL,
    is_read boolean DEFAULT false NOT NULL
);


--
-- Name: notifikasi_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.notifikasi_users ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.notifikasi_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pesanan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pesanan (
    id integer NOT NULL,
    kode_pesanan character varying(50) NOT NULL,
    user_id integer NOT NULL,
    total_harga numeric(12,2) DEFAULT 0 NOT NULL,
    status character varying(40) DEFAULT 'Pending'::character varying NOT NULL,
    catatan text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    stok_dikurangi boolean DEFAULT false NOT NULL,
    alasan_tolak text,
    metode_bayar character varying(20),
    dibayar_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pesanan_alasan_tolak_check CHECK ((((status)::text <> 'Ditolak'::text) OR ((alasan_tolak IS NOT NULL) AND (length(TRIM(BOTH FROM alasan_tolak)) > 0)))),
    CONSTRAINT pesanan_metode_bayar_check CHECK (((metode_bayar IS NULL) OR ((metode_bayar)::text = ANY ((ARRAY['Tunai'::character varying, 'QRIS'::character varying, 'Transfer'::character varying])::text[])))),
    CONSTRAINT pesanan_status_check CHECK (((status)::text = ANY (ARRAY['Pending'::text, 'Diverifikasi'::text, 'Diproses'::text, 'Tertunda'::text, 'Tertunda - Stok Tidak Tersedia'::text, 'Selesai'::text, 'Diambil'::text, 'Ditolak'::text]))),
    CONSTRAINT pesanan_total_harga_check CHECK ((total_harga >= (0)::numeric))
);


--
-- Name: pesanan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.pesanan ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.pesanan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: riwayat_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.riwayat_status (
    id integer NOT NULL,
    pesanan_id integer NOT NULL,
    status_lama character varying(40),
    status_baru character varying(40) NOT NULL,
    keterangan text,
    diubah_oleh integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: riwayat_status_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.riwayat_status ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.riwayat_status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: riwayat_stok; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.riwayat_stok (
    id integer NOT NULL,
    bahan_baku_id integer NOT NULL,
    pesanan_id integer,
    jenis character varying(10) NOT NULL,
    jumlah numeric(12,4) NOT NULL,
    stok_sebelum numeric(12,4) NOT NULL,
    stok_sesudah numeric(12,4) NOT NULL,
    keterangan character varying(255),
    user_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT riwayat_stok_jenis_check CHECK (((jenis)::text = ANY ((ARRAY['masuk'::character varying, 'keluar'::character varying, 'koreksi'::character varying])::text[]))),
    CONSTRAINT riwayat_stok_jumlah_check CHECK ((jumlah <> (0)::numeric))
);


--
-- Name: riwayat_stok_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.riwayat_stok ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.riwayat_stok_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    nama character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(255) NOT NULL,
    no_telepon character varying(20),
    role character varying(20) DEFAULT 'pelanggan'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY (ARRAY[('pelanggan'::character varying)::text, ('admin'::character varying)::text, ('owner'::character varying)::text])))
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: v_detail_pesanan; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_detail_pesanan AS
 SELECT p.id AS pesanan_id,
    p.kode_pesanan,
    u.id AS pelanggan_id,
    u.nama AS nama_pelanggan,
    u.email,
    l.id AS layanan_id,
    l.nama_layanan,
    l.satuan,
    l.harga AS harga_satuan,
    dp.jumlah,
    dp.subtotal,
    p.total_harga,
    p.status,
    p.catatan,
    p.created_at
   FROM (((public.pesanan p
     JOIN public.users u ON ((p.user_id = u.id)))
     JOIN public.detail_pesanan dp ON ((dp.pesanan_id = p.id)))
     JOIN public.layanan l ON ((dp.layanan_id = l.id)));


--
-- Name: v_kebutuhan_bahan_pesanan; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_kebutuhan_bahan_pesanan AS
 SELECT dp.pesanan_id,
    bb.id AS bahan_baku_id,
    bb.nama_bahan,
    bb.satuan,
    sum((bl.jumlah_kebutuhan * (dp.jumlah)::numeric)) AS dibutuhkan,
    bb.stok AS stok_tersedia,
    (bb.stok >= sum((bl.jumlah_kebutuhan * (dp.jumlah)::numeric))) AS cukup
   FROM ((public.detail_pesanan dp
     JOIN public.bahan_layanan bl ON ((bl.layanan_id = dp.layanan_id)))
     JOIN public.bahan_baku bb ON ((bb.id = bl.bahan_baku_id)))
  GROUP BY dp.pesanan_id, bb.id, bb.nama_bahan, bb.satuan, bb.stok;


--
-- Data for Name: auth_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_tokens (id, user_id, token_hash, expires_at, created_at) FROM stdin;
1	4	432e8d90709494f14351a475b19eb3ad12b689bd303b4c3d1cc8ba7d4ae72174	2026-10-21 01:50:48	2026-10-21 00:50:48.081301
2	4	57787811784c42fee71c0967e381cd07f139fd7086cf3f4d1a7f9677b33643b6	2026-10-21 01:59:28	2026-10-21 00:59:28.365351
3	4	defeaaf7259edd2ad4cab81f8943a9ff68be24f0314de24a88775731b195511e	2026-10-21 02:12:24	2026-10-21 01:12:24.397487
4	4	35025146db214bb7eccea23023ea424d8d0afa215d7e1b38143922740fbad54d	2026-10-21 08:19:59	2026-10-21 07:19:59.277697
5	2	c02ee3f03cdfbd1904c152714caf6d201ced3ca2326d19c7d2d6698d9a6cefe9	2026-10-21 08:32:17	2026-10-21 07:32:17.762511
6	3	c54b2f0e8a9f7d4459761118b823933b748b51d081cca1cf8a5c38ce298d6f2b	2026-10-21 08:42:19	2026-10-21 07:42:19.738936
7	2	042a179d103ddd1f3e2ffe62dba49e5b759dc3afdf381574b2b5767a33158909	2026-10-21 09:06:06	2026-10-21 08:06:06.275258
8	5	0010dbb50e9593ab156fa39127bfe41586f193b91f1bacbabbe339bbf103e332	2026-10-29 09:29:04.981861	2026-10-29 01:29:04.981861
9	2	db1cdf0cc842647c08ea8d6b99ffb2908ca4c6b2722aea2d17700400d342cbcc	2026-10-29 10:26:15.434344	2026-10-29 02:26:15.434344
10	2	9b51a07081cf25e25eb806ca93ec06d8ca66514f894b244753b0b20829b5001e	2026-10-29 11:45:24.852635	2026-10-29 03:45:24.852635
11	2	09c4574974a7dbc7b0861e1d4747990cec205c13ee22f5583224b0d1a3022295	2026-10-29 12:41:32.454909	2026-10-29 04:41:32.454909
12	2	c9ee1fcca784b0d768de28839fe39274b391f27377e760ebf63cec04f50c5820	2026-10-29 12:45:33.974639	2026-10-29 04:45:33.974639
13	2	ae54e92f34803907dc30019d9ce3e8f37b0b315a8df59a5b50a6564db139eb9c	2026-11-08 03:26:53.306189	2026-11-07 19:26:53.306189
14	3	d7fa044ac698d66033cdde31fbaa75e460451e8356316f80e0add70b5eabbb2f	2026-11-09 00:19:09.862887	2026-11-08 16:19:09.862887
15	1	8e724b759c8353f533a7dec1732dc3e860ea947dd2ec9c861ad389a13753e297	2026-11-09 00:19:33.660474	2026-11-08 16:19:33.660474
16	2	8f16d452896209117e736c55b2090ccc2cbfbc43134940ccfe98ae9a444fae4f	2026-11-09 00:50:18.859026	2026-11-08 16:50:18.859026
17	2	4ca4982b16fb7da569ad8e2cb316c3de067b8ba71153db13bb11a83a0260db2c	2026-11-09 03:07:16.678945	2026-11-08 19:07:16.678945
18	2	0410fd8bb4178da76950acc222c241a5cdef89b4f68c3cdf9282471a32ecb91e	2026-11-09 07:18:27.085652	2026-11-08 23:18:27.085652
\.


--
-- Data for Name: bahan_baku; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bahan_baku (id, nama_bahan, stok, satuan, reorder_point, status, harga_satuan) FROM stdin;
1	Kertas HVS A4 70gr	15.8620	rim	5.00	tersedia	48000.00
2	Tinta Hitam Epson 003	2.8118	botol	3.00	kritis	85000.00
3	Mika Bening A4	86.0000	lembar	10.00	tersedia	500.00
4	Kertas HVS F4 70gr	7.9240	rim	3.00	tersedia	52000.00
5	Tinta Warna Epson 003 (CMY)	5.4600	botol	3.00	tersedia	85000.00
6	Kertas Art Paper A4 150gr	3.7500	pak	2.00	tersedia	65000.00
7	Ring Spiral	92.0000	pcs	20.00	tersedia	1500.00
8	Hard Cover A4	0.0000	pcs	5.00	habis	9000.00
9	Lakban Hitam	5.1000	roll	2.00	tersedia	12000.00
\.


--
-- Data for Name: bahan_layanan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bahan_layanan (id, layanan_id, bahan_baku_id, jumlah_kebutuhan) FROM stdin;
1	1	1	0.0020
2	2	3	2.0000
3	1	2	0.0003
4	2	9	0.0500
5	3	6	0.0100
6	3	5	0.0020
7	4	1	0.0020
8	4	5	0.0010
9	5	4	0.0020
10	5	2	0.0003
11	6	1	0.0020
12	7	4	0.0020
13	8	7	1.0000
14	8	3	1.0000
15	9	8	1.0000
\.


--
-- Data for Name: detail_pesanan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.detail_pesanan (id, pesanan_id, layanan_id, jumlah, subtotal, file_dokumen, spesifikasi) FROM stdin;
1	1	1	20	10000.00	dokumen_skripsi.pdf	\N
2	1	2	1	5000.00	\N	\N
3	3	1	2	1000.00	storage/uploads/42c7d93c93494bb41c576b79c1083e3e.docx	\N
4	4	1	2	1000.00	\N	\N
5	5	1	1	500.00	829c8ff856956f1fe841f06272488de9.pdf	\N
6	6	1	2	1000.00	\N	\N
7	7	1	2	1000.00	\N	\N
8	8	2	26	130000.00	\N	\N
9	9	1	1	500.00	1ed50a01248e60a0df50364b0eb33185.pdf	\N
10	100	1	10	5000.00	contoh_dokumen_seed.pdf	10 lembar x 1 eks
11	100	9	1	25000.00	\N	1 buku
12	101	6	72	21600.00	contoh_dokumen_seed.pdf	24 lembar x 3 eks
13	101	8	3	21000.00	\N	3 buku
14	102	1	10	5000.00	\N	10 lembar x 1 eks | dua sisi
15	103	1	180	90000.00	contoh_dokumen_seed.pdf	36 lembar x 5 eks
16	104	6	8	2400.00	contoh_dokumen_seed.pdf	8 lembar x 1 eks
17	104	9	1	25000.00	\N	1 buku
18	105	5	50	30000.00	contoh_dokumen_seed.pdf	50 lembar x 1 eks
19	106	7	20	7000.00	contoh_dokumen_seed.pdf	10 lembar x 2 eks
20	106	2	2	10000.00	\N	2 buku
21	107	4	100	150000.00	contoh_dokumen_seed.pdf	100 lembar x 1 eks | dua sisi
22	108	1	100	50000.00	contoh_dokumen_seed.pdf	100 lembar x 1 eks
23	108	8	1	7000.00	\N	1 buku
24	109	4	600	900000.00	contoh_dokumen_seed.pdf	120 lembar x 5 eks | dua sisi
25	109	2	5	25000.00	\N	5 buku
26	110	5	24	14400.00	contoh_dokumen_seed.pdf	24 lembar x 1 eks
27	111	5	16	9600.00	contoh_dokumen_seed.pdf	8 lembar x 2 eks
28	112	1	4	2000.00	contoh_dokumen_seed.pdf	4 lembar x 1 eks
29	113	5	10	6000.00	contoh_dokumen_seed.pdf	10 lembar x 1 eks
30	113	8	1	7000.00	\N	1 buku
31	114	6	30	9000.00	contoh_dokumen_seed.pdf	10 lembar x 3 eks
32	114	8	3	21000.00	\N	3 buku
33	115	6	80	24000.00	contoh_dokumen_seed.pdf	80 lembar x 1 eks
34	116	1	10	5000.00	contoh_dokumen_seed.pdf	10 lembar x 1 eks
35	117	7	24	8400.00	contoh_dokumen_seed.pdf	12 lembar x 2 eks
36	118	6	4	1200.00	contoh_dokumen_seed.pdf	4 lembar x 1 eks
37	118	2	1	5000.00	\N	1 buku
38	119	6	12	3600.00	contoh_dokumen_seed.pdf	12 lembar x 1 eks | dua sisi
39	119	8	1	7000.00	\N	1 buku
40	120	4	12	18000.00	\N	12 lembar x 1 eks
41	121	1	20	10000.00	\N	20 lembar x 1 eks
42	121	8	1	7000.00	\N	1 buku
43	122	1	80	40000.00	contoh_dokumen_seed.pdf	40 lembar x 2 eks
44	122	2	2	10000.00	\N	2 buku
45	123	6	90	27000.00	contoh_dokumen_seed.pdf	30 lembar x 3 eks
46	124	5	100	60000.00	contoh_dokumen_seed.pdf	100 lembar x 1 eks
47	125	1	200	100000.00	contoh_dokumen_seed.pdf	100 lembar x 2 eks
48	126	5	30	18000.00	contoh_dokumen_seed.pdf	30 lembar x 1 eks | dua sisi
49	127	6	10	3000.00	contoh_dokumen_seed.pdf	10 lembar x 1 eks | dua sisi
50	127	8	1	7000.00	\N	1 buku
51	128	4	100	150000.00	contoh_dokumen_seed.pdf	50 lembar x 2 eks | dua sisi
52	129	7	40	14000.00	contoh_dokumen_seed.pdf	40 lembar x 1 eks
53	129	8	1	7000.00	\N	1 buku
54	130	4	200	300000.00	contoh_dokumen_seed.pdf	40 lembar x 5 eks
55	131	1	24	12000.00	contoh_dokumen_seed.pdf	12 lembar x 2 eks
56	132	1	48	24000.00	contoh_dokumen_seed.pdf	24 lembar x 2 eks
57	133	1	20	10000.00	contoh_dokumen_seed.pdf	10 lembar x 2 eks
58	133	8	2	14000.00	\N	2 buku
59	134	3	250	625000.00	contoh_dokumen_seed.pdf	50 lembar x 5 eks
60	135	1	36	18000.00	contoh_dokumen_seed.pdf	36 lembar x 1 eks
61	135	8	1	7000.00	\N	1 buku
62	136	7	8	2800.00	contoh_dokumen_seed.pdf	8 lembar x 1 eks | dua sisi
63	137	1	40	20000.00	contoh_dokumen_seed.pdf	20 lembar x 2 eks | dua sisi
64	137	8	2	14000.00	\N	2 buku
65	138	6	40	12000.00	contoh_dokumen_seed.pdf	40 lembar x 1 eks
66	139	6	50	15000.00	\N	50 lembar x 1 eks
67	139	8	1	7000.00	\N	1 buku
68	140	4	160	240000.00	contoh_dokumen_seed.pdf	80 lembar x 2 eks | dua sisi
69	140	8	2	14000.00	\N	2 buku
70	141	6	24	7200.00	\N	24 lembar x 1 eks | dua sisi
71	141	9	1	25000.00	\N	1 buku
72	142	7	60	21000.00	\N	60 lembar x 1 eks
73	143	6	200	60000.00	contoh_dokumen_seed.pdf	100 lembar x 2 eks
74	144	1	100	50000.00	contoh_dokumen_seed.pdf	100 lembar x 1 eks
75	144	2	1	5000.00	\N	1 buku
76	145	1	160	80000.00	contoh_dokumen_seed.pdf	80 lembar x 2 eks
77	146	1	30	15000.00	contoh_dokumen_seed.pdf	10 lembar x 3 eks
78	147	1	40	20000.00	\N	20 lembar x 2 eks
79	147	8	2	14000.00	\N	2 buku
80	148	3	100	250000.00	\N	100 lembar x 1 eks
81	149	3	100	250000.00	contoh_dokumen_seed.pdf	50 lembar x 2 eks
82	150	1	100	50000.00	contoh_dokumen_seed.pdf	100 lembar x 1 eks | dua sisi
83	150	9	1	25000.00	\N	1 buku
84	151	1	24	12000.00	\N	24 lembar x 1 eks
85	151	8	1	7000.00	\N	1 buku
86	152	1	40	20000.00	contoh_dokumen_seed.pdf	8 lembar x 5 eks
87	153	7	36	12600.00	contoh_dokumen_seed.pdf	12 lembar x 3 eks
88	153	2	3	15000.00	\N	3 buku
89	154	7	24	8400.00	\N	24 lembar x 1 eks
90	155	6	12	3600.00	contoh_dokumen_seed.pdf	12 lembar x 1 eks | dua sisi
91	155	8	1	7000.00	\N	1 buku
92	156	4	100	150000.00	\N	100 lembar x 1 eks
93	157	6	36	10800.00	\N	36 lembar x 1 eks
94	157	8	1	7000.00	\N	1 buku
95	158	1	20	10000.00	contoh_dokumen_seed.pdf	20 lembar x 1 eks
96	159	1	120	60000.00	contoh_dokumen_seed.pdf	120 lembar x 1 eks | dua sisi
97	160	5	4	2400.00	contoh_dokumen_seed.pdf	4 lembar x 1 eks | dua sisi
98	160	8	1	7000.00	\N	1 buku
99	161	1	4	2000.00	contoh_dokumen_seed.pdf	4 lembar x 1 eks
100	162	6	15	4500.00	\N	15 lembar x 1 eks
101	163	6	48	14400.00	contoh_dokumen_seed.pdf	24 lembar x 2 eks
102	163	8	2	14000.00	\N	2 buku
103	164	1	40	20000.00	contoh_dokumen_seed.pdf	40 lembar x 1 eks | dua sisi
104	164	2	1	5000.00	\N	1 buku
105	165	6	30	9000.00	contoh_dokumen_seed.pdf	30 lembar x 1 eks
106	165	2	1	5000.00	\N	1 buku
107	166	5	4	2400.00	contoh_dokumen_seed.pdf	4 lembar x 1 eks
108	167	6	100	30000.00	contoh_dokumen_seed.pdf	100 lembar x 1 eks | dua sisi
109	167	8	1	7000.00	\N	1 buku
110	168	3	75	187500.00	contoh_dokumen_seed.pdf	25 lembar x 3 eks | dua sisi
111	169	1	24	12000.00	contoh_dokumen_seed.pdf	24 lembar x 1 eks | dua sisi
112	169	8	1	7000.00	\N	1 buku
113	170	6	100	30000.00	\N	50 lembar x 2 eks
114	170	9	2	50000.00	\N	2 buku
115	171	1	90	45000.00	contoh_dokumen_seed.pdf	30 lembar x 3 eks
116	172	6	120	36000.00	contoh_dokumen_seed.pdf	60 lembar x 2 eks | dua sisi
117	172	2	2	10000.00	\N	2 buku
118	173	4	100	150000.00	contoh_dokumen_seed.pdf	100 lembar x 1 eks
119	174	5	50	30000.00	contoh_dokumen_seed.pdf	10 lembar x 5 eks
120	175	6	120	36000.00	contoh_dokumen_seed.pdf	60 lembar x 2 eks
121	176	1	80	40000.00	\N	80 lembar x 1 eks | dua sisi
122	176	8	1	7000.00	\N	1 buku
123	177	1	50	25000.00	\N	50 lembar x 1 eks
124	178	5	120	72000.00	contoh_dokumen_seed.pdf	120 lembar x 1 eks
125	178	2	1	5000.00	\N	1 buku
126	179	6	160	48000.00	contoh_dokumen_seed.pdf	80 lembar x 2 eks
127	179	2	2	10000.00	\N	2 buku
128	180	6	40	12000.00	\N	40 lembar x 1 eks
129	181	6	60	18000.00	contoh_dokumen_seed.pdf	60 lembar x 1 eks
130	182	1	30	15000.00	\N	30 lembar x 1 eks
131	182	9	1	25000.00	\N	1 buku
132	183	1	15	7500.00	\N	15 lembar x 1 eks | dua sisi
133	184	4	20	30000.00	contoh_dokumen_seed.pdf	20 lembar x 1 eks
134	185	4	100	150000.00	contoh_dokumen_seed.pdf	100 lembar x 1 eks | dua sisi
135	186	1	60	30000.00	contoh_dokumen_seed.pdf	60 lembar x 1 eks
136	187	5	72	43200.00	contoh_dokumen_seed.pdf	36 lembar x 2 eks
137	188	7	60	21000.00	contoh_dokumen_seed.pdf	60 lembar x 1 eks
138	189	1	4	2000.00	contoh_dokumen_seed.pdf	4 lembar x 1 eks
139	189	8	1	7000.00	\N	1 buku
140	190	5	36	21600.00	contoh_dokumen_seed.pdf	36 lembar x 1 eks
141	190	2	1	5000.00	\N	1 buku
142	191	1	80	40000.00	contoh_dokumen_seed.pdf	40 lembar x 2 eks
143	192	4	10	15000.00	contoh_dokumen_seed.pdf	10 lembar x 1 eks
144	193	6	36	10800.00	contoh_dokumen_seed.pdf	36 lembar x 1 eks | dua sisi
145	194	6	100	30000.00	contoh_dokumen_seed.pdf	50 lembar x 2 eks
146	195	1	90	45000.00	\N	30 lembar x 3 eks
147	195	2	3	15000.00	\N	3 buku
148	196	3	75	187500.00	contoh_dokumen_seed.pdf	25 lembar x 3 eks | dua sisi
149	197	1	120	60000.00	contoh_dokumen_seed.pdf	120 lembar x 1 eks
150	197	9	1	25000.00	\N	1 buku
\.


--
-- Data for Name: layanan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.layanan (id, nama_layanan, harga, satuan, deskripsi, kategori, aktif) FROM stdin;
1	Print HVS A4 Hitam Putih	500.00	lembar	Cetak hitam putih kertas HVS A4 70gr	cetak	t
3	Cetak Brosur Glossy A4	2500.00	lembar	Cetak full color kertas Art Paper 150gr	cetak	t
2	Jilid Lakban	5000.00	buku	Jilid lakban hitam dengan mika bening	finishing	t
4	Print A4 Warna	1500.00	lembar	Cetak full color kertas HVS A4 80gr	cetak	t
5	Print F4 Hitam Putih	600.00	lembar	Cetak hitam putih kertas HVS F4 70gr	cetak	t
6	Fotokopi A4 Hitam Putih	300.00	lembar	Fotokopi hitam putih kertas A4 70gr	fotokopi	t
7	Fotokopi F4 Hitam Putih	350.00	lembar	Fotokopi hitam putih kertas F4 70gr	fotokopi	t
8	Jilid Spiral	7000.00	buku	Jilid ring spiral dengan cover mika bening	finishing	t
9	Jilid Hard Cover	25000.00	buku	Jilid hard cover untuk skripsi/laporan	finishing	t
\.


--
-- Data for Name: notifikasi; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifikasi (id, pesanan_id, judul, pesan, created_at) FROM stdin;
1	1	Pesanan Dibuat	Pesanan ORD-20261002-001 berhasil dibuat dan menunggu verifikasi.	2026-10-14 21:08:21.663971
3	4	Perubahan Status Pesanan	Pesanan RI-20261028-017 berubah status dari Pending menjadi Diproses	2026-10-29 02:52:36.690098
4	4	Update Status Pesanan	Pesanan Anda sedang diproses cetak oleh operator.	2026-10-29 02:52:36.690098
5	5	Perubahan Status Pesanan	Pesanan RI-20261028-976 berubah status dari Pending menjadi Diproses	2026-10-29 04:01:13.314779
6	7	Pesanan Dibuat	Pesanan RI-20261108-538 berhasil dibuat dan menunggu verifikasi.	2026-11-08 16:41:43.507018
7	7	Perubahan Status Pesanan	Pesanan RI-20261108-538 berubah status dari Pending menjadi Diverifikasi	2026-11-08 16:51:15.353999
8	7	Perubahan Status Pesanan	Pesanan RI-20261108-538 berubah status dari Diverifikasi menjadi Diproses	2026-11-08 17:20:25.498882
9	8	Pesanan Dibuat	Pesanan RI-20261108-445 berhasil dibuat dan menunggu verifikasi.	2026-11-08 17:27:33.480681
10	8	Perubahan Status Pesanan	Pesanan RI-20261108-445 berubah status dari Pending menjadi Tertunda - Stok Tidak Tersedia	2026-11-08 17:28:49.840544
11	9	Pesanan Dibuat	Pesanan RI-20261108-934 berhasil dibuat dan menunggu verifikasi.	2026-11-08 18:17:00.044272
12	9	Perubahan Status Pesanan	Pesanan RI-20261108-934 berubah status dari Pending menjadi Diverifikasi	2026-11-08 23:54:57.598049
13	188	Pesanan Dibuat	Pesanan RI-20261105-077 berhasil dibuat dan menunggu verifikasi.	2026-11-05 18:04:47
14	188	Perubahan Status Pesanan	Pesanan RI-20261105-077 berubah status dari Pending menjadi Diverifikasi	2026-11-05 18:43:47
15	188	Perubahan Status Pesanan	Pesanan RI-20261105-077 berubah status dari Diverifikasi menjadi Diproses	2026-11-05 18:57:47
16	188	Perubahan Status Pesanan	Pesanan RI-20261105-077 berubah status dari Diproses menjadi Selesai	2026-11-05 20:24:47
17	188	Perubahan Status Pesanan	Pesanan RI-20261105-077 berubah status dari Selesai menjadi Diambil	2026-11-06 09:59:47
18	189	Pesanan Dibuat	Pesanan RI-20261106-633 berhasil dibuat dan menunggu verifikasi.	2026-11-06 14:51:54
19	189	Perubahan Status Pesanan	Pesanan RI-20261106-633 berubah status dari Pending menjadi Diverifikasi	2026-11-06 15:24:54
20	189	Perubahan Status Pesanan	Pesanan RI-20261106-633 berubah status dari Diverifikasi menjadi Diproses	2026-11-06 15:48:54
21	189	Perubahan Status Pesanan	Pesanan RI-20261106-633 berubah status dari Diproses menjadi Selesai	2026-11-06 17:08:54
22	189	Perubahan Status Pesanan	Pesanan RI-20261106-633 berubah status dari Selesai menjadi Diambil	2026-11-07 08:54:54
23	190	Pesanan Dibuat	Pesanan RI-20261107-164 berhasil dibuat dan menunggu verifikasi.	2026-11-07 09:48:53
24	190	Perubahan Status Pesanan	Pesanan RI-20261107-164 berubah status dari Pending menjadi Diverifikasi	2026-11-07 10:04:53
25	190	Perubahan Status Pesanan	Pesanan RI-20261107-164 berubah status dari Diverifikasi menjadi Diproses	2026-11-07 10:19:53
26	190	Perubahan Status Pesanan	Pesanan RI-20261107-164 berubah status dari Diproses menjadi Selesai	2026-11-07 12:19:53
27	190	Perubahan Status Pesanan	Pesanan RI-20261107-164 berubah status dari Selesai menjadi Diambil	2026-11-07 23:19:53
28	191	Pesanan Dibuat	Pesanan RI-20261107-162 berhasil dibuat dan menunggu verifikasi.	2026-11-07 14:34:47
29	191	Perubahan Status Pesanan	Pesanan RI-20261107-162 berubah status dari Pending menjadi Diverifikasi	2026-11-07 14:48:47
30	191	Perubahan Status Pesanan	Pesanan RI-20261107-162 berubah status dari Diverifikasi menjadi Diproses	2026-11-07 15:06:47
31	191	Perubahan Status Pesanan	Pesanan RI-20261107-162 berubah status dari Diproses menjadi Selesai	2026-11-07 17:29:47
32	191	Perubahan Status Pesanan	Pesanan RI-20261107-162 berubah status dari Selesai menjadi Diambil	2026-11-08 01:29:47
33	192	Pesanan Dibuat	Pesanan RI-20261109-835 berhasil dibuat dan menunggu verifikasi.	2026-11-09 13:48:42
34	192	Perubahan Status Pesanan	Pesanan RI-20261109-835 berubah status dari Pending menjadi Diverifikasi	2026-11-09 14:21:42
35	192	Perubahan Status Pesanan	Pesanan RI-20261109-835 berubah status dari Diverifikasi menjadi Diproses	2026-11-09 14:25:42
36	193	Pesanan Dibuat	Pesanan RI-20261109-402 berhasil dibuat dan menunggu verifikasi.	2026-11-09 14:53:35
37	193	Perubahan Status Pesanan	Pesanan RI-20261109-402 berubah status dari Pending menjadi Diverifikasi	2026-11-09 15:31:35
38	194	Pesanan Dibuat	Pesanan RI-20261109-206 berhasil dibuat dan menunggu verifikasi.	2026-11-09 10:15:42
39	194	Perubahan Status Pesanan	Pesanan RI-20261109-206 berubah status dari Pending menjadi Diverifikasi	2026-11-09 10:50:42
40	194	Perubahan Status Pesanan	Pesanan RI-20261109-206 berubah status dari Diverifikasi menjadi Diproses	2026-11-09 11:08:42
41	195	Pesanan Dibuat	Pesanan RI-20261109-428 berhasil dibuat dan menunggu verifikasi.	2026-11-09 10:40:58
42	196	Pesanan Dibuat	Pesanan RI-20261109-049 berhasil dibuat dan menunggu verifikasi.	2026-11-09 14:59:55
43	196	Perubahan Status Pesanan	Pesanan RI-20261109-049 berubah status dari Pending menjadi Diverifikasi	2026-11-09 15:04:55
44	197	Pesanan Dibuat	Pesanan RI-20261109-777 berhasil dibuat dan menunggu verifikasi.	2026-11-09 09:12:05
45	197	Perubahan Status Pesanan	Pesanan RI-20261109-777 berubah status dari Pending menjadi Diverifikasi	2026-11-09 09:34:05
46	197	Perubahan Status Pesanan	Pesanan RI-20261109-777 berubah status dari Diverifikasi menjadi Tertunda - Stok Tidak Tersedia. Stok Hard Cover A4 tidak mencukupi	2026-11-09 09:43:05
47	\N	Stok Kritis	Tinta Hitam Epson 003 tersisa 2.8118 botol (reorder point 3).	2026-11-09 07:30:00
48	\N	Stok Habis	Hard Cover A4 tersisa 0 pcs (reorder point 5).	2026-11-09 07:30:00
\.


--
-- Data for Name: notifikasi_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifikasi_users (id, notifikasi_id, user_id, is_read) FROM stdin;
1	1	1	f
2	4	5	f
3	5	2	f
4	6	1	f
5	7	1	f
6	8	1	f
7	9	1	f
8	10	1	f
9	11	1	f
10	12	1	f
11	13	7	t
12	13	2	t
13	14	7	t
14	15	7	t
15	16	7	t
16	17	7	t
17	18	10	t
18	18	2	t
19	19	10	t
20	20	10	t
21	21	10	t
22	22	10	t
23	23	1	t
24	23	2	t
25	24	1	t
26	25	1	t
27	26	1	t
28	27	1	t
29	28	6	t
30	28	2	t
31	29	6	t
32	30	6	t
33	31	6	t
34	32	6	t
35	33	8	f
36	33	2	f
37	34	8	f
38	35	8	f
39	36	10	f
40	36	2	f
41	37	10	f
42	38	10	f
43	38	2	f
44	39	10	f
45	40	10	f
46	41	4	f
47	41	2	f
48	42	8	f
49	42	2	f
50	43	8	f
51	44	6	f
52	44	2	f
53	45	6	f
54	46	6	f
55	47	2	f
56	47	3	f
57	48	2	f
58	48	3	f
\.


--
-- Data for Name: pesanan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pesanan (id, kode_pesanan, user_id, total_harga, status, catatan, created_at, stok_dikurangi, alasan_tolak, metode_bayar, dibayar_at, updated_at) FROM stdin;
3	EP-20261020181710-18615b	4	1000.00	Diproses	Pesanan pengujian EasyPrint	2026-10-21 01:17:10.784144	f	\N	\N	\N	2026-11-09 17:39:13.309524
1	ORD-20261002-001	1	15000.00	Pending	Tolong jilid lakban hitam, bagian depan mika bening	2026-10-14 21:08:21.663971	f	\N	\N	\N	2026-11-09 17:39:13.309524
4	RI-20261028-017	5	1000.00	Diproses	Tes pengajuan pesanan CP-2	2026-10-29 01:35:50.899895	t	\N	\N	\N	2026-11-09 17:39:13.309524
5	RI-20261028-976	2	500.00	Diproses	Test upload	2026-10-29 03:51:57.525154	t	\N	\N	\N	2026-11-09 17:39:13.309524
6	RI-20261108-531	1	1000.00	Pending	Pengujian pesanan EasyPrint	2026-11-08 16:20:54.717101	f	\N	\N	\N	2026-11-09 17:39:13.309524
7	RI-20261108-538	1	1000.00	Diproses	Tes notifikasi setelah perbaikan	2026-11-08 16:41:43.507018	t	\N	\N	\N	2026-11-09 17:39:13.309524
8	RI-20261108-445	1	130000.00	Tertunda - Stok Tidak Tersedia	TEST CP3 - stok tidak mencukupi	2026-11-08 17:27:33.480681	f	\N	\N	\N	2026-11-09 17:39:13.309524
9	RI-20261108-934	1	500.00	Diverifikasi	\N	2026-11-08 18:17:00.044272	f	\N	\N	\N	2026-11-09 17:39:13.309524
100	RI-20260914-505	9	30000.00	Diambil	\N	2026-09-14 08:31:18	t	\N	QRIS	2026-09-15 10:44:18	2026-09-15 10:44:18
101	RI-20260915-260	7	42600.00	Diambil	Untuk tugas kuliah, mohon cepat	2026-09-15 10:23:27	t	\N	Tunai	2026-09-16 04:51:27	2026-09-16 04:51:27
102	RI-20260915-082	8	5000.00	Selesai	Fotokopi 2 rangkap	2026-09-15 13:22:40	t	\N	\N	\N	2026-09-15 15:08:40
103	RI-20260916-701	6	90000.00	Diambil	Untuk tugas kuliah, mohon cepat	2026-09-16 08:24:16	t	\N	Tunai	2026-09-16 22:16:16	2026-09-16 22:16:16
104	RI-20260917-120	1	27400.00	Ditolak	\N	2026-09-17 15:50:58	f	Berkas tidak terbaca / buram. Mohon scan ulang dengan resolusi lebih tinggi.	\N	\N	2026-09-17 16:07:58
105	RI-20260917-672	1	30000.00	Diambil	Fotokopi 2 rangkap	2026-09-17 09:44:12	t	\N	QRIS	2026-09-18 02:26:12	2026-09-18 02:26:12
106	RI-20260917-684	9	17000.00	Diambil	Ambil sore hari	2026-09-17 12:32:13	t	\N	Tunai	2026-09-18 18:20:13	2026-09-18 18:20:13
107	RI-20260918-894	7	150000.00	Diambil	Mohon dijilid rapi	2026-09-18 11:41:53	t	\N	Tunai	2026-09-19 08:09:53	2026-09-19 08:09:53
108	RI-20260918-542	13	57000.00	Diambil	Fotokopi 2 rangkap	2026-09-18 14:30:18	t	\N	Tunai	2026-09-19 21:53:18	2026-09-19 21:53:18
109	RI-20260919-249	6	925000.00	Diambil	Cover warna biru	2026-09-19 14:35:22	t	\N	Tunai	2026-09-20 06:38:22	2026-09-20 06:38:22
110	RI-20260919-328	12	14400.00	Diambil	Untuk tugas kuliah, mohon cepat	2026-09-19 15:37:48	t	\N	Tunai	2026-09-20 06:31:48	2026-09-20 06:31:48
111	RI-20260919-967	10	9600.00	Diambil	\N	2026-09-19 15:40:58	t	\N	Tunai	2026-09-20 08:50:58	2026-09-20 08:50:58
112	RI-20260920-448	7	2000.00	Diambil	\N	2026-09-20 14:02:43	t	\N	Tunai	2026-09-21 04:24:43	2026-09-21 04:24:43
113	RI-20260921-295	12	13000.00	Diambil	Ambil sore hari	2026-09-21 10:52:56	t	\N	Tunai	2026-09-22 14:26:56	2026-09-22 14:26:56
114	RI-20260921-918	8	30000.00	Diambil	Mohon dijilid rapi	2026-09-21 08:46:50	t	\N	Tunai	2026-09-22 01:38:50	2026-09-22 01:38:50
115	RI-20260922-268	8	24000.00	Diambil	Untuk tugas kuliah, mohon cepat	2026-09-22 11:08:11	t	\N	Tunai	2026-09-23 18:06:11	2026-09-23 18:06:11
116	RI-20260922-625	6	5000.00	Diambil	Untuk tugas kuliah, mohon cepat	2026-09-22 11:58:01	t	\N	Tunai	2026-09-22 23:01:01	2026-09-22 23:01:01
117	RI-20260923-973	10	8400.00	Diambil	\N	2026-09-23 14:24:55	t	\N	QRIS	2026-09-24 00:30:55	2026-09-24 00:30:55
118	RI-20260923-663	13	6200.00	Diambil	Untuk tugas kuliah, mohon cepat	2026-09-23 14:36:39	t	\N	QRIS	2026-09-24 11:22:39	2026-09-24 11:22:39
119	RI-20260924-924	7	10600.00	Diambil	\N	2026-09-24 12:51:41	t	\N	Tunai	2026-09-24 22:32:41	2026-09-24 22:32:41
120	RI-20260925-863	6	18000.00	Ditolak	\N	2026-09-25 08:06:44	f	Jumlah halaman berkas tidak sesuai dengan jumlah lembar yang dipesan.	\N	\N	2026-09-25 08:51:44
121	RI-20260925-215	1	17000.00	Diambil	Mohon dijilid rapi	2026-09-25 14:34:20	t	\N	Tunai	2026-09-26 04:13:20	2026-09-26 04:13:20
122	RI-20260926-605	1	50000.00	Ditolak	Halaman 1-3 berwarna	2026-09-26 17:14:43	f	Berkas terkunci password sehingga tidak dapat dicetak.	\N	\N	2026-09-26 17:50:43
123	RI-20260926-652	11	27000.00	Diambil	\N	2026-09-26 10:13:48	t	\N	Tunai	2026-09-27 16:38:48	2026-09-27 16:38:48
124	RI-20260926-601	8	60000.00	Diambil	Margin kiri lebih lebar	2026-09-26 13:37:50	t	\N	QRIS	2026-09-27 01:32:50	2026-09-27 01:32:50
125	RI-20260927-214	13	100000.00	Diambil	Fotokopi 2 rangkap	2026-09-27 14:54:34	t	\N	Tunai	2026-09-28 18:52:34	2026-09-28 18:52:34
126	RI-20260928-405	1	18000.00	Diambil	Cetak bolak-balik	2026-09-28 09:24:09	t	\N	QRIS	2026-09-29 06:53:09	2026-09-29 06:53:09
127	RI-20260928-617	8	10000.00	Diambil	Cetak bolak-balik	2026-09-28 18:46:45	t	\N	Tunai	2026-09-30 01:43:45	2026-09-30 01:43:45
128	RI-20260929-744	7	150000.00	Diambil	\N	2026-09-29 16:01:08	t	\N	Tunai	2026-10-01 01:24:08	2026-10-01 01:24:08
129	RI-20260930-549	11	21000.00	Diambil	Fotokopi 2 rangkap	2026-09-30 13:28:03	t	\N	Tunai	2026-10-01 02:21:03	2026-10-01 02:21:03
130	RI-20260930-634	11	300000.00	Diambil	Cover warna biru	2026-09-30 16:17:17	t	\N	Tunai	2026-10-01 11:21:17	2026-10-01 11:21:17
131	RI-20261001-174	11	12000.00	Diambil	\N	2026-10-01 15:57:34	t	\N	QRIS	2026-10-01 22:31:34	2026-10-01 22:31:34
132	RI-20261002-271	6	24000.00	Diambil	Cover warna biru	2026-10-02 10:28:59	t	\N	Tunai	2026-10-03 20:10:59	2026-10-03 20:10:59
133	RI-20261003-345	6	24000.00	Diambil	Halaman 1-3 berwarna	2026-10-03 08:09:31	t	\N	Tunai	2026-10-03 10:45:31	2026-10-03 10:45:31
134	RI-20261003-344	8	625000.00	Diambil	Fotokopi 2 rangkap	2026-10-03 12:47:30	t	\N	QRIS	2026-10-04 13:21:30	2026-10-04 13:21:30
135	RI-20261003-001	4	25000.00	Selesai	\N	2026-10-03 16:59:41	t	\N	\N	\N	2026-10-03 19:05:41
136	RI-20261005-090	11	2800.00	Diambil	\N	2026-10-05 17:06:32	t	\N	Tunai	2026-10-06 09:48:32	2026-10-06 09:48:32
137	RI-20261005-890	13	34000.00	Diambil	Halaman 1-3 berwarna	2026-10-05 12:49:49	t	\N	QRIS	2026-10-05 21:15:49	2026-10-05 21:15:49
138	RI-20261006-295	10	12000.00	Diambil	\N	2026-10-06 09:23:00	t	\N	Tunai	2026-10-07 02:11:00	2026-10-07 02:11:00
139	RI-20261006-929	6	22000.00	Selesai	Untuk tugas kuliah, mohon cepat	2026-10-06 15:12:50	t	\N	\N	\N	2026-10-06 17:09:50
140	RI-20261006-174	8	254000.00	Diambil	Halaman 1-3 berwarna	2026-10-06 17:54:44	t	\N	Tunai	2026-10-07 12:36:44	2026-10-07 12:36:44
141	RI-20261007-103	13	32200.00	Ditolak	\N	2026-10-07 17:49:16	f	Berkas terkunci password sehingga tidak dapat dicetak.	\N	\N	2026-10-07 18:26:16
142	RI-20261007-832	12	21000.00	Diambil	\N	2026-10-07 18:11:08	t	\N	Tunai	2026-10-08 20:37:08	2026-10-08 20:37:08
143	RI-20261008-221	6	60000.00	Diambil	\N	2026-10-08 18:26:17	t	\N	QRIS	2026-10-09 02:24:17	2026-10-09 02:24:17
144	RI-20261009-574	11	55000.00	Diambil	\N	2026-10-09 18:56:36	t	\N	Tunai	2026-10-10 04:08:36	2026-10-10 04:08:36
145	RI-20261009-764	12	80000.00	Diambil	Cover warna biru	2026-10-09 16:34:10	t	\N	QRIS	2026-10-09 20:23:10	2026-10-09 20:23:10
146	RI-20261010-799	6	15000.00	Diambil	Cetak bolak-balik	2026-10-10 14:11:04	t	\N	QRIS	2026-10-11 20:04:04	2026-10-11 20:04:04
147	RI-20261010-051	6	34000.00	Ditolak	Halaman 1-3 berwarna	2026-10-10 14:46:28	f	Berkas terkunci password sehingga tidak dapat dicetak.	\N	\N	2026-10-10 15:14:28
148	RI-20261011-509	4	250000.00	Diambil	\N	2026-10-11 14:55:30	t	\N	Tunai	2026-10-11 18:36:30	2026-10-11 18:36:30
149	RI-20261012-669	4	250000.00	Diambil	\N	2026-10-12 11:59:04	t	\N	Tunai	2026-10-12 23:21:04	2026-10-12 23:21:04
150	RI-20261012-971	13	75000.00	Diambil	Cover warna biru	2026-10-12 08:00:47	t	\N	QRIS	2026-10-12 17:43:47	2026-10-12 17:43:47
151	RI-20261013-583	10	19000.00	Diambil	\N	2026-10-13 10:03:37	t	\N	Tunai	2026-10-13 19:11:37	2026-10-13 19:11:37
152	RI-20261013-097	11	20000.00	Diambil	\N	2026-10-13 10:01:39	t	\N	Tunai	2026-10-14 17:18:39	2026-10-14 17:18:39
153	RI-20261013-105	7	27600.00	Diambil	Ambil sore hari	2026-10-13 15:33:18	t	\N	Tunai	2026-10-13 22:33:18	2026-10-13 22:33:18
154	RI-20261014-987	10	8400.00	Diambil	\N	2026-10-14 11:13:02	t	\N	Tunai	2026-10-15 05:54:02	2026-10-15 05:54:02
155	RI-20261014-817	9	10600.00	Diambil	Margin kiri lebih lebar	2026-10-14 12:49:57	t	\N	QRIS	2026-10-14 16:41:57	2026-10-14 16:41:57
156	RI-20261014-815	11	150000.00	Diambil	Mohon dijilid rapi	2026-10-14 13:10:50	t	\N	Tunai	2026-10-15 04:32:50	2026-10-15 04:32:50
157	RI-20261015-063	7	17800.00	Diambil	\N	2026-10-15 16:12:34	t	\N	Tunai	2026-10-16 09:43:34	2026-10-16 09:43:34
158	RI-20261015-860	7	10000.00	Diambil	Fotokopi 2 rangkap	2026-10-15 16:17:04	t	\N	QRIS	2026-10-16 23:47:04	2026-10-16 23:47:04
159	RI-20261016-753	6	60000.00	Diambil	Untuk tugas kuliah, mohon cepat	2026-10-16 12:09:50	t	\N	QRIS	2026-10-17 11:14:50	2026-10-17 11:14:50
160	RI-20261017-456	8	9400.00	Diambil	Mohon dijilid rapi	2026-10-17 14:49:05	t	\N	Tunai	2026-10-17 18:09:05	2026-10-17 18:09:05
161	RI-20261017-129	1	2000.00	Diambil	Mohon dijilid rapi	2026-10-17 08:04:35	t	\N	QRIS	2026-10-18 09:41:35	2026-10-18 09:41:35
162	RI-20261019-638	8	4500.00	Diambil	Margin kiri lebih lebar	2026-10-19 15:16:42	t	\N	Tunai	2026-10-20 07:39:42	2026-10-20 07:39:42
163	RI-20261020-623	6	28400.00	Ditolak	Fotokopi 2 rangkap	2026-10-20 09:50:32	f	Jumlah halaman berkas tidak sesuai dengan jumlah lembar yang dipesan.	\N	\N	2026-10-20 10:21:32
164	RI-20261020-888	6	25000.00	Diambil	Mohon dijilid rapi	2026-10-20 12:45:54	t	\N	Tunai	2026-10-20 16:52:54	2026-10-20 16:52:54
165	RI-20261021-896	1	14000.00	Diambil	Mohon dijilid rapi	2026-10-21 13:31:33	t	\N	Tunai	2026-10-21 18:50:33	2026-10-21 18:50:33
166	RI-20261021-993	11	2400.00	Diambil	Untuk tugas kuliah, mohon cepat	2026-10-21 18:03:58	t	\N	QRIS	2026-10-22 03:45:58	2026-10-22 03:45:58
167	RI-20261021-858	6	37000.00	Diambil	Halaman 1-3 berwarna	2026-10-21 09:42:04	t	\N	QRIS	2026-10-21 20:07:04	2026-10-21 20:07:04
168	RI-20261022-466	7	187500.00	Diambil	\N	2026-10-22 18:04:04	t	\N	QRIS	2026-10-23 14:41:04	2026-10-23 14:41:04
169	RI-20261023-219	13	19000.00	Diambil	\N	2026-10-23 08:50:22	t	\N	QRIS	2026-10-23 20:54:22	2026-10-23 20:54:22
170	RI-20261024-493	1	80000.00	Diambil	Cetak bolak-balik	2026-10-24 14:46:13	t	\N	Tunai	2026-10-25 22:42:13	2026-10-25 22:42:13
171	RI-20261024-390	5	45000.00	Diambil	\N	2026-10-24 10:51:24	t	\N	Tunai	2026-10-25 02:19:24	2026-10-25 02:19:24
172	RI-20261024-813	9	46000.00	Ditolak	Margin kiri lebih lebar	2026-10-24 15:46:26	f	Berkas terkunci password sehingga tidak dapat dicetak.	\N	\N	2026-10-24 16:10:26
173	RI-20261025-531	11	150000.00	Selesai	\N	2026-10-25 12:58:03	t	\N	\N	\N	2026-10-25 16:36:03
174	RI-20261026-720	1	30000.00	Diambil	\N	2026-10-26 12:26:37	t	\N	Tunai	2026-10-27 10:32:37	2026-10-27 10:32:37
175	RI-20261027-014	11	36000.00	Diambil	Untuk tugas kuliah, mohon cepat	2026-10-27 18:38:00	t	\N	Tunai	2026-10-28 20:27:00	2026-10-28 20:27:00
176	RI-20261027-010	4	47000.00	Diambil	Halaman 1-3 berwarna	2026-10-27 08:17:21	t	\N	Tunai	2026-10-27 22:34:21	2026-10-27 22:34:21
177	RI-20261028-607	9	25000.00	Diambil	Cover warna biru	2026-10-28 08:09:08	t	\N	QRIS	2026-10-29 13:29:08	2026-10-29 13:29:08
178	RI-20261029-293	8	77000.00	Diambil	Cetak bolak-balik	2026-10-29 18:47:02	t	\N	Tunai	2026-10-31 01:26:02	2026-10-31 01:26:02
179	RI-20261030-693	13	58000.00	Selesai	Margin kiri lebih lebar	2026-10-30 18:41:37	t	\N	\N	\N	2026-10-30 20:18:37
180	RI-20261030-593	7	12000.00	Diambil	Halaman 1-3 berwarna	2026-10-30 16:25:56	t	\N	Tunai	2026-10-31 23:50:56	2026-10-31 23:50:56
181	RI-20261031-856	6	18000.00	Ditolak	Cover warna biru	2026-10-31 18:06:49	f	Jumlah halaman berkas tidak sesuai dengan jumlah lembar yang dipesan.	\N	\N	2026-10-31 18:30:49
182	RI-20261031-762	6	40000.00	Diambil	Untuk tugas kuliah, mohon cepat	2026-10-31 15:06:21	t	\N	Tunai	2026-10-31 22:25:21	2026-10-31 22:25:21
183	RI-20261101-892	13	7500.00	Diambil	\N	2026-11-01 15:38:43	t	\N	Tunai	2026-11-02 00:18:43	2026-11-02 00:18:43
184	RI-20261102-750	4	30000.00	Diambil	\N	2026-11-02 11:55:31	t	\N	Tunai	2026-11-02 18:18:31	2026-11-02 18:18:31
185	RI-20261103-420	8	150000.00	Diambil	Ambil sore hari	2026-11-03 15:15:03	t	\N	Tunai	2026-11-03 21:02:03	2026-11-03 21:02:03
186	RI-20261104-632	7	30000.00	Diambil	Cover warna biru	2026-11-04 16:00:46	t	\N	Tunai	2026-11-05 11:32:46	2026-11-05 11:32:46
187	RI-20261104-887	12	43200.00	Diambil	Ambil sore hari	2026-11-04 09:25:58	t	\N	QRIS	2026-11-04 23:04:58	2026-11-04 23:04:58
188	RI-20261105-077	7	21000.00	Diambil	\N	2026-11-05 18:04:47	t	\N	Tunai	2026-11-06 09:59:47	2026-11-06 09:59:47
189	RI-20261106-633	10	9000.00	Diambil	\N	2026-11-06 14:51:54	t	\N	Tunai	2026-11-07 08:54:54	2026-11-07 08:54:54
190	RI-20261107-164	1	26600.00	Diambil	\N	2026-11-07 09:48:53	t	\N	Tunai	2026-11-07 23:19:53	2026-11-07 23:19:53
191	RI-20261107-162	6	40000.00	Diambil	\N	2026-11-07 14:34:47	t	\N	Tunai	2026-11-08 01:29:47	2026-11-08 01:29:47
192	RI-20261109-835	8	15000.00	Diproses	Ambil sore hari	2026-11-09 13:48:42	t	\N	\N	\N	2026-11-09 14:25:42
193	RI-20261109-402	10	10800.00	Diverifikasi	Ambil sore hari	2026-11-09 14:53:35	f	\N	\N	\N	2026-11-09 15:31:35
194	RI-20261109-206	10	30000.00	Diproses	\N	2026-11-09 10:15:42	t	\N	\N	\N	2026-11-09 11:08:42
195	RI-20261109-428	4	60000.00	Pending	Cetak bolak-balik	2026-11-09 10:40:58	f	\N	\N	\N	2026-11-09 10:40:58
196	RI-20261109-049	8	187500.00	Diverifikasi	Untuk tugas kuliah, mohon cepat	2026-11-09 14:59:55	f	\N	\N	\N	2026-11-09 15:04:55
197	RI-20261109-777	6	85000.00	Tertunda - Stok Tidak Tersedia	Skripsi, jilid hard cover warna biru dongker	2026-11-09 09:12:05	f	\N	\N	\N	2026-11-09 09:43:05
\.


--
-- Data for Name: riwayat_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.riwayat_status (id, pesanan_id, status_lama, status_baru, keterangan, diubah_oleh, created_at) FROM stdin;
1	5	\N	Pending	Pesanan dibuat	\N	2026-10-29 03:51:57.525154
2	8	\N	Pending	Pesanan dibuat	\N	2026-11-08 17:27:33.480681
3	6	\N	Pending	Pesanan dibuat	\N	2026-11-08 16:20:54.717101
4	4	\N	Pending	Pesanan dibuat	\N	2026-10-29 01:35:50.899895
5	1	\N	Pending	Pesanan dibuat	\N	2026-10-14 21:08:21.663971
6	3	\N	Pending	Pesanan dibuat	\N	2026-10-21 01:17:10.784144
7	9	\N	Pending	Pesanan dibuat	\N	2026-11-08 18:17:00.044272
8	7	\N	Pending	Pesanan dibuat	\N	2026-11-08 16:41:43.507018
9	4	Pending	Diproses	Dipulihkan dari notifikasi	\N	2026-10-29 02:52:36.690098
10	5	Pending	Diproses	Dipulihkan dari notifikasi	\N	2026-10-29 04:01:13.314779
11	7	Pending	Diverifikasi	Dipulihkan dari notifikasi	\N	2026-11-08 16:51:15.353999
12	7	Diverifikasi	Diproses	Dipulihkan dari notifikasi	\N	2026-11-08 17:20:25.498882
13	8	Pending	Tertunda - Stok Tidak Tersedia	Dipulihkan dari notifikasi	\N	2026-11-08 17:28:49.840544
14	9	Pending	Diverifikasi	Dipulihkan dari notifikasi	\N	2026-11-08 23:54:57.598049
15	100	\N	Pending	Pesanan dibuat	9	2026-09-14 08:31:18
16	100	Pending	Diverifikasi	\N	2	2026-09-14 08:52:18
17	100	Diverifikasi	Diproses	\N	2	2026-09-14 08:56:18
18	100	Diproses	Selesai	\N	2	2026-09-14 11:33:18
19	100	Selesai	Diambil	\N	2	2026-09-15 10:44:18
20	101	\N	Pending	Pesanan dibuat	7	2026-09-15 10:23:27
21	101	Pending	Diverifikasi	\N	2	2026-09-15 10:30:27
22	101	Diverifikasi	Diproses	\N	2	2026-09-15 10:39:27
23	101	Diproses	Selesai	\N	2	2026-09-15 13:52:27
24	101	Selesai	Diambil	\N	2	2026-09-16 04:51:27
25	102	\N	Pending	Pesanan dibuat	8	2026-09-15 13:22:40
26	102	Pending	Diverifikasi	\N	2	2026-09-15 13:54:40
27	102	Diverifikasi	Diproses	\N	2	2026-09-15 14:20:40
28	102	Diproses	Selesai	\N	2	2026-09-15 15:08:40
29	103	\N	Pending	Pesanan dibuat	6	2026-09-16 08:24:16
30	103	Pending	Diverifikasi	\N	2	2026-09-16 08:31:16
31	103	Diverifikasi	Diproses	\N	2	2026-09-16 09:01:16
32	103	Diproses	Selesai	\N	2	2026-09-16 12:19:16
33	103	Selesai	Diambil	\N	2	2026-09-16 22:16:16
34	104	\N	Pending	Pesanan dibuat	1	2026-09-17 15:50:58
35	104	Pending	Ditolak	Berkas tidak terbaca / buram. Mohon scan ulang dengan resolusi lebih tinggi.	2	2026-09-17 16:07:58
36	105	\N	Pending	Pesanan dibuat	1	2026-09-17 09:44:12
37	105	Pending	Diverifikasi	\N	2	2026-09-17 10:23:12
38	105	Diverifikasi	Diproses	\N	2	2026-09-17 10:53:12
39	105	Diproses	Selesai	\N	2	2026-09-17 12:41:12
40	105	Selesai	Diambil	\N	2	2026-09-18 02:26:12
41	106	\N	Pending	Pesanan dibuat	9	2026-09-17 12:32:13
42	106	Pending	Diverifikasi	\N	2	2026-09-17 12:47:13
43	106	Diverifikasi	Diproses	\N	2	2026-09-17 13:05:13
44	106	Diproses	Selesai	\N	2	2026-09-17 15:11:13
45	106	Selesai	Diambil	\N	2	2026-09-18 18:20:13
46	107	\N	Pending	Pesanan dibuat	7	2026-09-18 11:41:53
47	107	Pending	Diverifikasi	\N	2	2026-09-18 11:59:53
48	107	Diverifikasi	Diproses	\N	2	2026-09-18 12:26:53
49	107	Diproses	Selesai	\N	2	2026-09-18 13:24:53
50	107	Selesai	Diambil	\N	2	2026-09-19 08:09:53
51	108	\N	Pending	Pesanan dibuat	13	2026-09-18 14:30:18
52	108	Pending	Diverifikasi	\N	2	2026-09-18 14:46:18
53	108	Diverifikasi	Diproses	\N	2	2026-09-18 15:15:18
54	108	Diproses	Selesai	\N	2	2026-09-18 17:51:18
55	108	Selesai	Diambil	\N	2	2026-09-19 21:53:18
56	109	\N	Pending	Pesanan dibuat	6	2026-09-19 14:35:22
57	109	Pending	Diverifikasi	\N	2	2026-09-19 14:59:22
58	109	Diverifikasi	Diproses	\N	2	2026-09-19 15:22:22
59	109	Diproses	Selesai	\N	2	2026-09-19 17:43:22
60	109	Selesai	Diambil	\N	2	2026-09-20 06:38:22
61	110	\N	Pending	Pesanan dibuat	12	2026-09-19 15:37:48
62	110	Pending	Diverifikasi	\N	2	2026-09-19 15:55:48
63	110	Diverifikasi	Diproses	\N	2	2026-09-19 15:58:48
64	110	Diproses	Selesai	\N	2	2026-09-19 17:12:48
65	110	Selesai	Diambil	\N	2	2026-09-20 06:31:48
66	111	\N	Pending	Pesanan dibuat	10	2026-09-19 15:40:58
67	111	Pending	Diverifikasi	\N	2	2026-09-19 16:05:58
68	111	Diverifikasi	Diproses	\N	2	2026-09-19 16:34:58
69	111	Diproses	Selesai	\N	2	2026-09-19 18:40:58
70	111	Selesai	Diambil	\N	2	2026-09-20 08:50:58
71	112	\N	Pending	Pesanan dibuat	7	2026-09-20 14:02:43
72	112	Pending	Diverifikasi	\N	2	2026-09-20 14:08:43
73	112	Diverifikasi	Diproses	\N	2	2026-09-20 14:36:43
74	112	Diproses	Selesai	\N	2	2026-09-20 16:33:43
75	112	Selesai	Diambil	\N	2	2026-09-21 04:24:43
76	113	\N	Pending	Pesanan dibuat	12	2026-09-21 10:52:56
77	113	Pending	Diverifikasi	\N	2	2026-09-21 11:06:56
78	113	Diverifikasi	Diproses	\N	2	2026-09-21 11:30:56
79	113	Diproses	Selesai	\N	2	2026-09-21 14:17:56
80	113	Selesai	Diambil	\N	2	2026-09-22 14:26:56
81	114	\N	Pending	Pesanan dibuat	8	2026-09-21 08:46:50
82	114	Pending	Diverifikasi	\N	2	2026-09-21 09:15:50
83	114	Diverifikasi	Diproses	\N	2	2026-09-21 09:44:50
84	114	Diproses	Selesai	\N	2	2026-09-21 10:18:50
85	114	Selesai	Diambil	\N	2	2026-09-22 01:38:50
86	115	\N	Pending	Pesanan dibuat	8	2026-09-22 11:08:11
87	115	Pending	Diverifikasi	\N	2	2026-09-22 11:39:11
88	115	Diverifikasi	Diproses	\N	2	2026-09-22 11:56:11
89	115	Diproses	Selesai	\N	2	2026-09-22 15:08:11
90	115	Selesai	Diambil	\N	2	2026-09-23 18:06:11
91	116	\N	Pending	Pesanan dibuat	6	2026-09-22 11:58:01
92	116	Pending	Diverifikasi	\N	2	2026-09-22 12:18:01
93	116	Diverifikasi	Diproses	\N	2	2026-09-22 12:43:01
94	116	Diproses	Selesai	\N	2	2026-09-22 13:53:01
95	116	Selesai	Diambil	\N	2	2026-09-22 23:01:01
96	117	\N	Pending	Pesanan dibuat	10	2026-09-23 14:24:55
97	117	Pending	Diverifikasi	\N	2	2026-09-23 14:33:55
98	117	Diverifikasi	Diproses	\N	2	2026-09-23 15:01:55
99	117	Diproses	Selesai	\N	2	2026-09-23 17:16:55
100	117	Selesai	Diambil	\N	2	2026-09-24 00:30:55
101	118	\N	Pending	Pesanan dibuat	13	2026-09-23 14:36:39
102	118	Pending	Diverifikasi	\N	2	2026-09-23 15:09:39
103	118	Diverifikasi	Diproses	\N	2	2026-09-23 15:22:39
104	118	Diproses	Selesai	\N	2	2026-09-23 16:59:39
105	118	Selesai	Diambil	\N	2	2026-09-24 11:22:39
106	119	\N	Pending	Pesanan dibuat	7	2026-09-24 12:51:41
107	119	Pending	Diverifikasi	\N	2	2026-09-24 13:02:41
108	119	Diverifikasi	Diproses	\N	2	2026-09-24 13:17:41
109	119	Diproses	Selesai	\N	2	2026-09-24 14:15:41
110	119	Selesai	Diambil	\N	2	2026-09-24 22:32:41
111	120	\N	Pending	Pesanan dibuat	6	2026-09-25 08:06:44
112	120	Pending	Ditolak	Jumlah halaman berkas tidak sesuai dengan jumlah lembar yang dipesan.	2	2026-09-25 08:51:44
113	121	\N	Pending	Pesanan dibuat	1	2026-09-25 14:34:20
114	121	Pending	Diverifikasi	\N	2	2026-09-25 14:48:20
115	121	Diverifikasi	Diproses	\N	2	2026-09-25 15:07:20
116	121	Diproses	Selesai	\N	2	2026-09-25 16:49:20
117	121	Selesai	Diambil	\N	2	2026-09-26 04:13:20
118	122	\N	Pending	Pesanan dibuat	1	2026-09-26 17:14:43
119	122	Pending	Ditolak	Berkas terkunci password sehingga tidak dapat dicetak.	2	2026-09-26 17:50:43
120	123	\N	Pending	Pesanan dibuat	11	2026-09-26 10:13:48
121	123	Pending	Diverifikasi	\N	2	2026-09-26 10:37:48
122	123	Diverifikasi	Diproses	\N	2	2026-09-26 11:02:48
123	123	Diproses	Selesai	\N	2	2026-09-26 13:29:48
124	123	Selesai	Diambil	\N	2	2026-09-27 16:38:48
125	124	\N	Pending	Pesanan dibuat	8	2026-09-26 13:37:50
126	124	Pending	Diverifikasi	\N	2	2026-09-26 14:14:50
127	124	Diverifikasi	Diproses	\N	2	2026-09-26 14:39:50
128	124	Diproses	Selesai	\N	2	2026-09-26 15:33:50
129	124	Selesai	Diambil	\N	2	2026-09-27 01:32:50
130	125	\N	Pending	Pesanan dibuat	13	2026-09-27 14:54:34
131	125	Pending	Diverifikasi	\N	2	2026-09-27 15:33:34
132	125	Diverifikasi	Diproses	\N	2	2026-09-27 15:51:34
133	125	Diproses	Selesai	\N	2	2026-09-27 17:35:34
134	125	Selesai	Diambil	\N	2	2026-09-28 18:52:34
135	126	\N	Pending	Pesanan dibuat	1	2026-09-28 09:24:09
136	126	Pending	Diverifikasi	\N	2	2026-09-28 09:32:09
137	126	Diverifikasi	Diproses	\N	2	2026-09-28 09:40:09
138	126	Diproses	Selesai	\N	2	2026-09-28 11:54:09
139	126	Selesai	Diambil	\N	2	2026-09-29 06:53:09
140	127	\N	Pending	Pesanan dibuat	8	2026-09-28 18:46:45
141	127	Pending	Diverifikasi	\N	2	2026-09-28 19:07:45
142	127	Diverifikasi	Diproses	\N	2	2026-09-28 19:10:45
143	127	Diproses	Selesai	\N	2	2026-09-28 21:02:45
144	127	Selesai	Diambil	\N	2	2026-09-30 01:43:45
145	128	\N	Pending	Pesanan dibuat	7	2026-09-29 16:01:08
146	128	Pending	Diverifikasi	\N	2	2026-09-29 16:23:08
147	128	Diverifikasi	Diproses	\N	2	2026-09-29 16:52:08
148	128	Diproses	Selesai	\N	2	2026-09-29 19:36:08
149	128	Selesai	Diambil	\N	2	2026-10-01 01:24:08
150	129	\N	Pending	Pesanan dibuat	11	2026-09-30 13:28:03
151	129	Pending	Diverifikasi	\N	2	2026-09-30 13:38:03
152	129	Diverifikasi	Diproses	\N	2	2026-09-30 13:55:03
153	129	Diproses	Selesai	\N	2	2026-09-30 16:48:03
154	129	Selesai	Diambil	\N	2	2026-10-01 02:21:03
155	130	\N	Pending	Pesanan dibuat	11	2026-09-30 16:17:17
156	130	Pending	Diverifikasi	\N	2	2026-09-30 16:30:17
157	130	Diverifikasi	Diproses	\N	2	2026-09-30 16:36:17
158	130	Diproses	Selesai	\N	2	2026-09-30 19:16:17
159	130	Selesai	Diambil	\N	2	2026-10-01 11:21:17
160	131	\N	Pending	Pesanan dibuat	11	2026-10-01 15:57:34
161	131	Pending	Diverifikasi	\N	2	2026-10-01 16:20:34
162	131	Diverifikasi	Diproses	\N	2	2026-10-01 16:26:34
163	131	Diproses	Selesai	\N	2	2026-10-01 19:40:34
164	131	Selesai	Diambil	\N	2	2026-10-01 22:31:34
165	132	\N	Pending	Pesanan dibuat	6	2026-10-02 10:28:59
166	132	Pending	Diverifikasi	\N	2	2026-10-02 11:07:59
167	132	Diverifikasi	Diproses	\N	2	2026-10-02 11:17:59
168	132	Diproses	Selesai	\N	2	2026-10-02 14:14:59
169	132	Selesai	Diambil	\N	2	2026-10-03 20:10:59
170	133	\N	Pending	Pesanan dibuat	6	2026-10-03 08:09:31
171	133	Pending	Diverifikasi	\N	2	2026-10-03 08:27:31
172	133	Diverifikasi	Diproses	\N	2	2026-10-03 08:30:31
173	133	Diproses	Selesai	\N	2	2026-10-03 08:58:31
174	133	Selesai	Diambil	\N	2	2026-10-03 10:45:31
175	134	\N	Pending	Pesanan dibuat	8	2026-10-03 12:47:30
176	134	Pending	Diverifikasi	\N	2	2026-10-03 13:22:30
177	134	Diverifikasi	Diproses	\N	2	2026-10-03 13:48:30
178	134	Diproses	Selesai	\N	2	2026-10-03 16:04:30
179	134	Selesai	Diambil	\N	2	2026-10-04 13:21:30
180	135	\N	Pending	Pesanan dibuat	4	2026-10-03 16:59:41
181	135	Pending	Diverifikasi	\N	2	2026-10-03 17:31:41
182	135	Diverifikasi	Diproses	\N	2	2026-10-03 17:54:41
183	135	Diproses	Selesai	\N	2	2026-10-03 19:05:41
184	136	\N	Pending	Pesanan dibuat	11	2026-10-05 17:06:32
185	136	Pending	Diverifikasi	\N	2	2026-10-05 17:24:32
186	136	Diverifikasi	Diproses	\N	2	2026-10-05 17:41:32
187	136	Diproses	Selesai	\N	2	2026-10-05 20:37:32
188	136	Selesai	Diambil	\N	2	2026-10-06 09:48:32
189	137	\N	Pending	Pesanan dibuat	13	2026-10-05 12:49:49
190	137	Pending	Diverifikasi	\N	2	2026-10-05 13:21:49
191	137	Diverifikasi	Diproses	\N	2	2026-10-05 13:32:49
192	137	Diproses	Selesai	\N	2	2026-10-05 16:17:49
193	137	Selesai	Diambil	\N	2	2026-10-05 21:15:49
194	138	\N	Pending	Pesanan dibuat	10	2026-10-06 09:23:00
195	138	Pending	Diverifikasi	\N	2	2026-10-06 09:51:00
196	138	Diverifikasi	Diproses	\N	2	2026-10-06 10:20:00
197	138	Diproses	Selesai	\N	2	2026-10-06 11:32:00
198	138	Selesai	Diambil	\N	2	2026-10-07 02:11:00
199	139	\N	Pending	Pesanan dibuat	6	2026-10-06 15:12:50
200	139	Pending	Diverifikasi	\N	2	2026-10-06 15:31:50
201	139	Diverifikasi	Diproses	\N	2	2026-10-06 15:47:50
202	139	Diproses	Selesai	\N	2	2026-10-06 17:09:50
203	140	\N	Pending	Pesanan dibuat	8	2026-10-06 17:54:44
204	140	Pending	Diverifikasi	\N	2	2026-10-06 18:27:44
205	140	Diverifikasi	Diproses	\N	2	2026-10-06 18:55:44
206	140	Diproses	Selesai	\N	2	2026-10-06 22:11:44
207	140	Selesai	Diambil	\N	2	2026-10-07 12:36:44
208	141	\N	Pending	Pesanan dibuat	13	2026-10-07 17:49:16
209	141	Pending	Ditolak	Berkas terkunci password sehingga tidak dapat dicetak.	2	2026-10-07 18:26:16
210	142	\N	Pending	Pesanan dibuat	12	2026-10-07 18:11:08
211	142	Pending	Diverifikasi	\N	2	2026-10-07 18:24:08
212	142	Diverifikasi	Diproses	\N	2	2026-10-07 18:45:08
213	142	Diproses	Selesai	\N	2	2026-10-07 19:51:08
214	142	Selesai	Diambil	\N	2	2026-10-08 20:37:08
215	143	\N	Pending	Pesanan dibuat	6	2026-10-08 18:26:17
216	143	Pending	Diverifikasi	\N	2	2026-10-08 18:51:17
217	143	Diverifikasi	Diproses	\N	2	2026-10-08 19:21:17
218	143	Diproses	Selesai	\N	2	2026-10-08 20:09:17
219	143	Selesai	Diambil	\N	2	2026-10-09 02:24:17
220	144	\N	Pending	Pesanan dibuat	11	2026-10-09 18:56:36
221	144	Pending	Diverifikasi	\N	2	2026-10-09 19:16:36
222	144	Diverifikasi	Diproses	\N	2	2026-10-09 19:39:36
223	144	Diproses	Selesai	\N	2	2026-10-09 22:59:36
224	144	Selesai	Diambil	\N	2	2026-10-10 04:08:36
225	145	\N	Pending	Pesanan dibuat	12	2026-10-09 16:34:10
226	145	Pending	Diverifikasi	\N	2	2026-10-09 17:03:10
227	145	Diverifikasi	Diproses	\N	2	2026-10-09 17:32:10
228	145	Diproses	Selesai	\N	2	2026-10-09 18:45:10
229	145	Selesai	Diambil	\N	2	2026-10-09 20:23:10
230	146	\N	Pending	Pesanan dibuat	6	2026-10-10 14:11:04
231	146	Pending	Diverifikasi	\N	2	2026-10-10 14:42:04
232	146	Diverifikasi	Diproses	\N	2	2026-10-10 14:55:04
233	146	Diproses	Selesai	\N	2	2026-10-10 16:48:04
234	146	Selesai	Diambil	\N	2	2026-10-11 20:04:04
235	147	\N	Pending	Pesanan dibuat	6	2026-10-10 14:46:28
236	147	Pending	Ditolak	Berkas terkunci password sehingga tidak dapat dicetak.	2	2026-10-10 15:14:28
237	148	\N	Pending	Pesanan dibuat	4	2026-10-11 14:55:30
238	148	Pending	Diverifikasi	\N	2	2026-10-11 15:12:30
239	148	Diverifikasi	Diproses	\N	2	2026-10-11 15:30:30
240	148	Diproses	Selesai	\N	2	2026-10-11 16:55:30
241	148	Selesai	Diambil	\N	2	2026-10-11 18:36:30
242	149	\N	Pending	Pesanan dibuat	4	2026-10-12 11:59:04
243	149	Pending	Diverifikasi	\N	2	2026-10-12 12:30:04
244	149	Diverifikasi	Diproses	\N	2	2026-10-12 12:33:04
245	149	Diproses	Selesai	\N	2	2026-10-12 15:20:04
246	149	Selesai	Diambil	\N	2	2026-10-12 23:21:04
247	150	\N	Pending	Pesanan dibuat	13	2026-10-12 08:00:47
248	150	Pending	Diverifikasi	\N	2	2026-10-12 08:23:47
249	150	Diverifikasi	Diproses	\N	2	2026-10-12 08:51:47
250	150	Diproses	Selesai	\N	2	2026-10-12 11:53:47
251	150	Selesai	Diambil	\N	2	2026-10-12 17:43:47
252	151	\N	Pending	Pesanan dibuat	10	2026-10-13 10:03:37
253	151	Pending	Diverifikasi	\N	2	2026-10-13 10:18:37
254	151	Diverifikasi	Diproses	\N	2	2026-10-13 10:24:37
255	151	Diproses	Selesai	\N	2	2026-10-13 12:16:37
256	151	Selesai	Diambil	\N	2	2026-10-13 19:11:37
257	152	\N	Pending	Pesanan dibuat	11	2026-10-13 10:01:39
258	152	Pending	Diverifikasi	\N	2	2026-10-13 10:24:39
259	152	Diverifikasi	Diproses	\N	2	2026-10-13 10:41:39
260	152	Diproses	Selesai	\N	2	2026-10-13 12:44:39
261	152	Selesai	Diambil	\N	2	2026-10-14 17:18:39
262	153	\N	Pending	Pesanan dibuat	7	2026-10-13 15:33:18
263	153	Pending	Diverifikasi	\N	2	2026-10-13 15:50:18
264	153	Diverifikasi	Diproses	\N	2	2026-10-13 16:17:18
265	153	Diproses	Selesai	\N	2	2026-10-13 18:58:18
266	153	Selesai	Diambil	\N	2	2026-10-13 22:33:18
267	154	\N	Pending	Pesanan dibuat	10	2026-10-14 11:13:02
268	154	Pending	Diverifikasi	\N	2	2026-10-14 11:51:02
269	154	Diverifikasi	Diproses	\N	2	2026-10-14 12:14:02
270	154	Diproses	Selesai	\N	2	2026-10-14 13:54:02
271	154	Selesai	Diambil	\N	2	2026-10-15 05:54:02
272	155	\N	Pending	Pesanan dibuat	9	2026-10-14 12:49:57
273	155	Pending	Diverifikasi	\N	2	2026-10-14 13:05:57
274	155	Diverifikasi	Diproses	\N	2	2026-10-14 13:19:57
275	155	Diproses	Selesai	\N	2	2026-10-14 15:12:57
276	155	Selesai	Diambil	\N	2	2026-10-14 16:41:57
277	156	\N	Pending	Pesanan dibuat	11	2026-10-14 13:10:50
278	156	Pending	Diverifikasi	\N	2	2026-10-14 13:38:50
279	156	Diverifikasi	Diproses	\N	2	2026-10-14 14:07:50
280	156	Diproses	Selesai	\N	2	2026-10-14 14:51:50
281	156	Selesai	Diambil	\N	2	2026-10-15 04:32:50
282	157	\N	Pending	Pesanan dibuat	7	2026-10-15 16:12:34
283	157	Pending	Diverifikasi	\N	2	2026-10-15 16:44:34
284	157	Diverifikasi	Diproses	\N	2	2026-10-15 16:54:34
285	157	Diproses	Selesai	\N	2	2026-10-15 19:49:34
286	157	Selesai	Diambil	\N	2	2026-10-16 09:43:34
287	158	\N	Pending	Pesanan dibuat	7	2026-10-15 16:17:04
288	158	Pending	Diverifikasi	\N	2	2026-10-15 16:56:04
289	158	Diverifikasi	Diproses	\N	2	2026-10-15 17:26:04
290	158	Diproses	Selesai	\N	2	2026-10-15 20:24:04
291	158	Selesai	Diambil	\N	2	2026-10-16 23:47:04
292	159	\N	Pending	Pesanan dibuat	6	2026-10-16 12:09:50
293	159	Pending	Diverifikasi	\N	2	2026-10-16 12:34:50
294	159	Diverifikasi	Diproses	\N	2	2026-10-16 12:51:50
295	159	Diproses	Selesai	\N	2	2026-10-16 13:35:50
296	159	Selesai	Diambil	\N	2	2026-10-17 11:14:50
297	160	\N	Pending	Pesanan dibuat	8	2026-10-17 14:49:05
298	160	Pending	Diverifikasi	\N	2	2026-10-17 15:15:05
299	160	Diverifikasi	Diproses	\N	2	2026-10-17 15:20:05
300	160	Diproses	Selesai	\N	2	2026-10-17 17:05:05
301	160	Selesai	Diambil	\N	2	2026-10-17 18:09:05
302	161	\N	Pending	Pesanan dibuat	1	2026-10-17 08:04:35
303	161	Pending	Diverifikasi	\N	2	2026-10-17 08:37:35
304	161	Diverifikasi	Diproses	\N	2	2026-10-17 09:04:35
305	161	Diproses	Selesai	\N	2	2026-10-17 11:13:35
306	161	Selesai	Diambil	\N	2	2026-10-18 09:41:35
307	162	\N	Pending	Pesanan dibuat	8	2026-10-19 15:16:42
308	162	Pending	Diverifikasi	\N	2	2026-10-19 15:34:42
309	162	Diverifikasi	Diproses	\N	2	2026-10-19 16:03:42
310	162	Diproses	Selesai	\N	2	2026-10-19 19:15:42
311	162	Selesai	Diambil	\N	2	2026-10-20 07:39:42
312	163	\N	Pending	Pesanan dibuat	6	2026-10-20 09:50:32
313	163	Pending	Ditolak	Jumlah halaman berkas tidak sesuai dengan jumlah lembar yang dipesan.	2	2026-10-20 10:21:32
314	164	\N	Pending	Pesanan dibuat	6	2026-10-20 12:45:54
315	164	Pending	Diverifikasi	\N	2	2026-10-20 13:12:54
316	164	Diverifikasi	Diproses	\N	2	2026-10-20 13:23:54
317	164	Diproses	Selesai	\N	2	2026-10-20 15:02:54
318	164	Selesai	Diambil	\N	2	2026-10-20 16:52:54
319	165	\N	Pending	Pesanan dibuat	1	2026-10-21 13:31:33
320	165	Pending	Diverifikasi	\N	2	2026-10-21 14:00:33
321	165	Diverifikasi	Diproses	\N	2	2026-10-21 14:26:33
322	165	Diproses	Selesai	\N	2	2026-10-21 17:35:33
323	165	Selesai	Diambil	\N	2	2026-10-21 18:50:33
324	166	\N	Pending	Pesanan dibuat	11	2026-10-21 18:03:58
325	166	Pending	Diverifikasi	\N	2	2026-10-21 18:14:58
326	166	Diverifikasi	Diproses	\N	2	2026-10-21 18:20:58
327	166	Diproses	Selesai	\N	2	2026-10-21 21:23:58
328	166	Selesai	Diambil	\N	2	2026-10-22 03:45:58
329	167	\N	Pending	Pesanan dibuat	6	2026-10-21 09:42:04
330	167	Pending	Diverifikasi	\N	2	2026-10-21 09:48:04
331	167	Diverifikasi	Diproses	\N	2	2026-10-21 10:14:04
332	167	Diproses	Selesai	\N	2	2026-10-21 11:15:04
333	167	Selesai	Diambil	\N	2	2026-10-21 20:07:04
334	168	\N	Pending	Pesanan dibuat	7	2026-10-22 18:04:04
335	168	Pending	Diverifikasi	\N	2	2026-10-22 18:38:04
336	168	Diverifikasi	Diproses	\N	2	2026-10-22 18:54:04
337	168	Diproses	Selesai	\N	2	2026-10-22 20:12:04
338	168	Selesai	Diambil	\N	2	2026-10-23 14:41:04
339	169	\N	Pending	Pesanan dibuat	13	2026-10-23 08:50:22
340	169	Pending	Diverifikasi	\N	2	2026-10-23 08:58:22
341	169	Diverifikasi	Diproses	\N	2	2026-10-23 09:08:22
342	169	Diproses	Selesai	\N	2	2026-10-23 10:32:22
343	169	Selesai	Diambil	\N	2	2026-10-23 20:54:22
344	170	\N	Pending	Pesanan dibuat	1	2026-10-24 14:46:13
345	170	Pending	Diverifikasi	\N	2	2026-10-24 15:20:13
346	170	Diverifikasi	Diproses	\N	2	2026-10-24 15:34:13
347	170	Diproses	Selesai	\N	2	2026-10-24 17:44:13
348	170	Selesai	Diambil	\N	2	2026-10-25 22:42:13
349	171	\N	Pending	Pesanan dibuat	5	2026-10-24 10:51:24
350	171	Pending	Diverifikasi	\N	2	2026-10-24 11:00:24
351	171	Diverifikasi	Diproses	\N	2	2026-10-24 11:05:24
352	171	Diproses	Selesai	\N	2	2026-10-24 12:38:24
353	171	Selesai	Diambil	\N	2	2026-10-25 02:19:24
354	172	\N	Pending	Pesanan dibuat	9	2026-10-24 15:46:26
355	172	Pending	Ditolak	Berkas terkunci password sehingga tidak dapat dicetak.	2	2026-10-24 16:10:26
356	173	\N	Pending	Pesanan dibuat	11	2026-10-25 12:58:03
357	173	Pending	Diverifikasi	\N	2	2026-10-25 13:11:03
358	173	Diverifikasi	Diproses	\N	2	2026-10-25 13:38:03
359	173	Diproses	Selesai	\N	2	2026-10-25 16:36:03
360	174	\N	Pending	Pesanan dibuat	1	2026-10-26 12:26:37
361	174	Pending	Diverifikasi	\N	2	2026-10-26 13:05:37
362	174	Diverifikasi	Diproses	\N	2	2026-10-26 13:26:37
363	174	Diproses	Selesai	\N	2	2026-10-26 14:42:37
364	174	Selesai	Diambil	\N	2	2026-10-27 10:32:37
365	175	\N	Pending	Pesanan dibuat	11	2026-10-27 18:38:00
366	175	Pending	Diverifikasi	\N	2	2026-10-27 19:07:00
367	175	Diverifikasi	Diproses	\N	2	2026-10-27 19:15:00
368	175	Diproses	Selesai	\N	2	2026-10-27 21:33:00
369	175	Selesai	Diambil	\N	2	2026-10-28 20:27:00
370	176	\N	Pending	Pesanan dibuat	4	2026-10-27 08:17:21
371	176	Pending	Diverifikasi	\N	2	2026-10-27 08:43:21
372	176	Diverifikasi	Diproses	\N	2	2026-10-27 09:11:21
373	176	Diproses	Selesai	\N	2	2026-10-27 12:24:21
374	176	Selesai	Diambil	\N	2	2026-10-27 22:34:21
375	177	\N	Pending	Pesanan dibuat	9	2026-10-28 08:09:08
376	177	Pending	Diverifikasi	\N	2	2026-10-28 08:37:08
377	177	Diverifikasi	Diproses	\N	2	2026-10-28 09:00:08
378	177	Diproses	Selesai	\N	2	2026-10-28 11:06:08
379	177	Selesai	Diambil	\N	2	2026-10-29 13:29:08
380	178	\N	Pending	Pesanan dibuat	8	2026-10-29 18:47:02
381	178	Pending	Diverifikasi	\N	2	2026-10-29 19:22:02
382	178	Diverifikasi	Diproses	\N	2	2026-10-29 19:39:02
383	178	Diproses	Selesai	\N	2	2026-10-29 21:45:02
384	178	Selesai	Diambil	\N	2	2026-10-31 01:26:02
385	179	\N	Pending	Pesanan dibuat	13	2026-10-30 18:41:37
386	179	Pending	Diverifikasi	\N	2	2026-10-30 19:05:37
387	179	Diverifikasi	Diproses	\N	2	2026-10-30 19:34:37
388	179	Diproses	Selesai	\N	2	2026-10-30 20:18:37
389	180	\N	Pending	Pesanan dibuat	7	2026-10-30 16:25:56
390	180	Pending	Diverifikasi	\N	2	2026-10-30 17:03:56
391	180	Diverifikasi	Diproses	\N	2	2026-10-30 17:07:56
392	180	Diproses	Selesai	\N	2	2026-10-30 18:25:56
393	180	Selesai	Diambil	\N	2	2026-10-31 23:50:56
394	181	\N	Pending	Pesanan dibuat	6	2026-10-31 18:06:49
395	181	Pending	Ditolak	Jumlah halaman berkas tidak sesuai dengan jumlah lembar yang dipesan.	2	2026-10-31 18:30:49
396	182	\N	Pending	Pesanan dibuat	6	2026-10-31 15:06:21
397	182	Pending	Diverifikasi	\N	2	2026-10-31 15:26:21
398	182	Diverifikasi	Diproses	\N	2	2026-10-31 15:33:21
399	182	Diproses	Selesai	\N	2	2026-10-31 17:41:21
400	182	Selesai	Diambil	\N	2	2026-10-31 22:25:21
401	183	\N	Pending	Pesanan dibuat	13	2026-11-01 15:38:43
402	183	Pending	Diverifikasi	\N	2	2026-11-01 16:12:43
403	183	Diverifikasi	Diproses	\N	2	2026-11-01 16:20:43
404	183	Diproses	Selesai	\N	2	2026-11-01 18:59:43
405	183	Selesai	Diambil	\N	2	2026-11-02 00:18:43
406	184	\N	Pending	Pesanan dibuat	4	2026-11-02 11:55:31
407	184	Pending	Diverifikasi	\N	2	2026-11-02 12:00:31
408	184	Diverifikasi	Diproses	\N	2	2026-11-02 12:10:31
409	184	Diproses	Selesai	\N	2	2026-11-02 13:08:31
410	184	Selesai	Diambil	\N	2	2026-11-02 18:18:31
411	185	\N	Pending	Pesanan dibuat	8	2026-11-03 15:15:03
412	185	Pending	Diverifikasi	\N	2	2026-11-03 15:44:03
413	185	Diverifikasi	Diproses	\N	2	2026-11-03 15:57:03
414	185	Diproses	Selesai	\N	2	2026-11-03 18:33:03
415	185	Selesai	Diambil	\N	2	2026-11-03 21:02:03
416	186	\N	Pending	Pesanan dibuat	7	2026-11-04 16:00:46
417	186	Pending	Diverifikasi	\N	2	2026-11-04 16:29:46
418	186	Diverifikasi	Diproses	\N	2	2026-11-04 16:54:46
419	186	Diproses	Selesai	\N	2	2026-11-04 19:20:46
420	186	Selesai	Diambil	\N	2	2026-11-05 11:32:46
421	187	\N	Pending	Pesanan dibuat	12	2026-11-04 09:25:58
422	187	Pending	Diverifikasi	\N	2	2026-11-04 10:00:58
423	187	Diverifikasi	Diproses	\N	2	2026-11-04 10:20:58
424	187	Diproses	Selesai	\N	2	2026-11-04 11:33:58
425	187	Selesai	Diambil	\N	2	2026-11-04 23:04:58
426	188	\N	Pending	Pesanan dibuat	7	2026-11-05 18:04:47
427	188	Pending	Diverifikasi	\N	2	2026-11-05 18:43:47
428	188	Diverifikasi	Diproses	\N	2	2026-11-05 18:57:47
429	188	Diproses	Selesai	\N	2	2026-11-05 20:24:47
430	188	Selesai	Diambil	\N	2	2026-11-06 09:59:47
431	189	\N	Pending	Pesanan dibuat	10	2026-11-06 14:51:54
432	189	Pending	Diverifikasi	\N	2	2026-11-06 15:24:54
433	189	Diverifikasi	Diproses	\N	2	2026-11-06 15:48:54
434	189	Diproses	Selesai	\N	2	2026-11-06 17:08:54
435	189	Selesai	Diambil	\N	2	2026-11-07 08:54:54
436	190	\N	Pending	Pesanan dibuat	1	2026-11-07 09:48:53
437	190	Pending	Diverifikasi	\N	2	2026-11-07 10:04:53
438	190	Diverifikasi	Diproses	\N	2	2026-11-07 10:19:53
439	190	Diproses	Selesai	\N	2	2026-11-07 12:19:53
440	190	Selesai	Diambil	\N	2	2026-11-07 23:19:53
441	191	\N	Pending	Pesanan dibuat	6	2026-11-07 14:34:47
442	191	Pending	Diverifikasi	\N	2	2026-11-07 14:48:47
443	191	Diverifikasi	Diproses	\N	2	2026-11-07 15:06:47
444	191	Diproses	Selesai	\N	2	2026-11-07 17:29:47
445	191	Selesai	Diambil	\N	2	2026-11-08 01:29:47
446	192	\N	Pending	Pesanan dibuat	8	2026-11-09 13:48:42
447	192	Pending	Diverifikasi	\N	2	2026-11-09 14:21:42
448	192	Diverifikasi	Diproses	\N	2	2026-11-09 14:25:42
449	193	\N	Pending	Pesanan dibuat	10	2026-11-09 14:53:35
450	193	Pending	Diverifikasi	\N	2	2026-11-09 15:31:35
451	194	\N	Pending	Pesanan dibuat	10	2026-11-09 10:15:42
452	194	Pending	Diverifikasi	\N	2	2026-11-09 10:50:42
453	194	Diverifikasi	Diproses	\N	2	2026-11-09 11:08:42
454	195	\N	Pending	Pesanan dibuat	4	2026-11-09 10:40:58
455	196	\N	Pending	Pesanan dibuat	8	2026-11-09 14:59:55
456	196	Pending	Diverifikasi	\N	2	2026-11-09 15:04:55
457	197	\N	Pending	Pesanan dibuat	6	2026-11-09 09:12:05
458	197	Pending	Diverifikasi	\N	2	2026-11-09 09:34:05
459	197	Diverifikasi	Tertunda - Stok Tidak Tersedia	Stok Hard Cover A4 tidak mencukupi	2	2026-11-09 09:43:05
\.


--
-- Data for Name: riwayat_stok; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.riwayat_stok (id, bahan_baku_id, pesanan_id, jenis, jumlah, stok_sebelum, stok_sesudah, keterangan, user_id, created_at) FROM stdin;
4	1	\N	masuk	25.0000	0.0000	25.0000	Stok awal	3	2026-09-14 07:00:00
5	2	\N	masuk	3.5000	0.0000	3.5000	Stok awal	3	2026-09-14 07:00:00
6	3	\N	masuk	150.0000	0.0000	150.0000	Stok awal	3	2026-09-14 07:00:00
7	4	\N	masuk	4.5000	0.0000	4.5000	Stok awal	3	2026-09-14 07:00:00
8	5	\N	masuk	5.0000	0.0000	5.0000	Stok awal	3	2026-09-14 07:00:00
9	6	\N	masuk	6.0000	0.0000	6.0000	Stok awal	3	2026-09-14 07:00:00
10	7	\N	masuk	120.0000	0.0000	120.0000	Stok awal	3	2026-09-14 07:00:00
11	8	\N	masuk	20.0000	0.0000	20.0000	Stok awal	3	2026-09-14 07:00:00
12	9	\N	masuk	6.0000	0.0000	6.0000	Stok awal	3	2026-09-14 07:00:00
13	1	100	keluar	-0.0200	25.0000	24.9800	Pemakaian pesanan RI-20260914-505	2	2026-09-14 08:56:18
14	2	100	keluar	-0.0030	3.5000	3.4970	Pemakaian pesanan RI-20260914-505	2	2026-09-14 08:56:18
15	8	100	keluar	-1.0000	20.0000	19.0000	Pemakaian pesanan RI-20260914-505	2	2026-09-14 08:56:18
16	1	101	keluar	-0.1440	24.9800	24.8360	Pemakaian pesanan RI-20260915-260	2	2026-09-15 10:39:27
17	7	101	keluar	-3.0000	120.0000	117.0000	Pemakaian pesanan RI-20260915-260	2	2026-09-15 10:39:27
18	3	101	keluar	-3.0000	150.0000	147.0000	Pemakaian pesanan RI-20260915-260	2	2026-09-15 10:39:27
19	1	102	keluar	-0.0200	24.8360	24.8160	Pemakaian pesanan RI-20260915-082	2	2026-09-15 14:20:40
20	2	102	keluar	-0.0030	3.4970	3.4940	Pemakaian pesanan RI-20260915-082	2	2026-09-15 14:20:40
21	1	103	keluar	-0.3600	24.8160	24.4560	Pemakaian pesanan RI-20260916-701	2	2026-09-16 09:01:16
22	2	103	keluar	-0.0540	3.4940	3.4400	Pemakaian pesanan RI-20260916-701	2	2026-09-16 09:01:16
23	4	105	keluar	-0.1000	4.5000	4.4000	Pemakaian pesanan RI-20260917-672	2	2026-09-17 10:53:12
24	2	105	keluar	-0.0150	3.4400	3.4250	Pemakaian pesanan RI-20260917-672	2	2026-09-17 10:53:12
25	4	106	keluar	-0.0400	4.4000	4.3600	Pemakaian pesanan RI-20260917-684	2	2026-09-17 13:05:13
26	3	106	keluar	-4.0000	147.0000	143.0000	Pemakaian pesanan RI-20260917-684	2	2026-09-17 13:05:13
27	9	106	keluar	-0.1000	6.0000	5.9000	Pemakaian pesanan RI-20260917-684	2	2026-09-17 13:05:13
28	1	107	keluar	-0.2000	24.4560	24.2560	Pemakaian pesanan RI-20260918-894	2	2026-09-18 12:26:53
29	5	107	keluar	-0.1000	5.0000	4.9000	Pemakaian pesanan RI-20260918-894	2	2026-09-18 12:26:53
30	1	108	keluar	-0.2000	24.2560	24.0560	Pemakaian pesanan RI-20260918-542	2	2026-09-18 15:15:18
31	2	108	keluar	-0.0300	3.4250	3.3950	Pemakaian pesanan RI-20260918-542	2	2026-09-18 15:15:18
32	7	108	keluar	-1.0000	117.0000	116.0000	Pemakaian pesanan RI-20260918-542	2	2026-09-18 15:15:18
33	3	108	keluar	-1.0000	143.0000	142.0000	Pemakaian pesanan RI-20260918-542	2	2026-09-18 15:15:18
34	1	109	keluar	-1.2000	24.0560	22.8560	Pemakaian pesanan RI-20260919-249	2	2026-09-19 15:22:22
35	5	109	keluar	-0.6000	4.9000	4.3000	Pemakaian pesanan RI-20260919-249	2	2026-09-19 15:22:22
36	3	109	keluar	-10.0000	142.0000	132.0000	Pemakaian pesanan RI-20260919-249	2	2026-09-19 15:22:22
37	9	109	keluar	-0.2500	5.9000	5.6500	Pemakaian pesanan RI-20260919-249	2	2026-09-19 15:22:22
38	4	110	keluar	-0.0480	4.3600	4.3120	Pemakaian pesanan RI-20260919-328	2	2026-09-19 15:58:48
39	2	110	keluar	-0.0072	3.3950	3.3878	Pemakaian pesanan RI-20260919-328	2	2026-09-19 15:58:48
40	4	111	keluar	-0.0320	4.3120	4.2800	Pemakaian pesanan RI-20260919-967	2	2026-09-19 16:34:58
41	2	111	keluar	-0.0048	3.3878	3.3830	Pemakaian pesanan RI-20260919-967	2	2026-09-19 16:34:58
42	1	112	keluar	-0.0080	22.8560	22.8480	Pemakaian pesanan RI-20260920-448	2	2026-09-20 14:36:43
43	2	112	keluar	-0.0012	3.3830	3.3818	Pemakaian pesanan RI-20260920-448	2	2026-09-20 14:36:43
44	1	114	keluar	-0.0600	22.8480	22.7880	Pemakaian pesanan RI-20260921-918	2	2026-09-21 09:44:50
45	7	114	keluar	-3.0000	116.0000	113.0000	Pemakaian pesanan RI-20260921-918	2	2026-09-21 09:44:50
46	3	114	keluar	-3.0000	132.0000	129.0000	Pemakaian pesanan RI-20260921-918	2	2026-09-21 09:44:50
47	4	113	keluar	-0.0200	4.2800	4.2600	Pemakaian pesanan RI-20260921-295	2	2026-09-21 11:30:56
48	2	113	keluar	-0.0030	3.3818	3.3788	Pemakaian pesanan RI-20260921-295	2	2026-09-21 11:30:56
49	7	113	keluar	-1.0000	113.0000	112.0000	Pemakaian pesanan RI-20260921-295	2	2026-09-21 11:30:56
50	3	113	keluar	-1.0000	129.0000	128.0000	Pemakaian pesanan RI-20260921-295	2	2026-09-21 11:30:56
51	1	115	keluar	-0.1600	22.7880	22.6280	Pemakaian pesanan RI-20260922-268	2	2026-09-22 11:56:11
52	1	116	keluar	-0.0200	22.6280	22.6080	Pemakaian pesanan RI-20260922-625	2	2026-09-22 12:43:01
53	2	116	keluar	-0.0030	3.3788	3.3758	Pemakaian pesanan RI-20260922-625	2	2026-09-22 12:43:01
54	4	117	keluar	-0.0480	4.2600	4.2120	Pemakaian pesanan RI-20260923-973	2	2026-09-23 15:01:55
55	1	118	keluar	-0.0080	22.6080	22.6000	Pemakaian pesanan RI-20260923-663	2	2026-09-23 15:22:39
56	3	118	keluar	-2.0000	128.0000	126.0000	Pemakaian pesanan RI-20260923-663	2	2026-09-23 15:22:39
57	9	118	keluar	-0.0500	5.6500	5.6000	Pemakaian pesanan RI-20260923-663	2	2026-09-23 15:22:39
58	1	119	keluar	-0.0240	22.6000	22.5760	Pemakaian pesanan RI-20260924-924	2	2026-09-24 13:17:41
59	7	119	keluar	-1.0000	112.0000	111.0000	Pemakaian pesanan RI-20260924-924	2	2026-09-24 13:17:41
60	3	119	keluar	-1.0000	126.0000	125.0000	Pemakaian pesanan RI-20260924-924	2	2026-09-24 13:17:41
61	1	121	keluar	-0.0400	22.5760	22.5360	Pemakaian pesanan RI-20260925-215	2	2026-09-25 15:07:20
62	2	121	keluar	-0.0060	3.3758	3.3698	Pemakaian pesanan RI-20260925-215	2	2026-09-25 15:07:20
63	7	121	keluar	-1.0000	111.0000	110.0000	Pemakaian pesanan RI-20260925-215	2	2026-09-25 15:07:20
64	3	121	keluar	-1.0000	125.0000	124.0000	Pemakaian pesanan RI-20260925-215	2	2026-09-25 15:07:20
65	1	123	keluar	-0.1800	22.5360	22.3560	Pemakaian pesanan RI-20260926-652	2	2026-09-26 11:02:48
66	4	124	keluar	-0.2000	4.2120	4.0120	Pemakaian pesanan RI-20260926-601	2	2026-09-26 14:39:50
67	2	124	keluar	-0.0300	3.3698	3.3398	Pemakaian pesanan RI-20260926-601	2	2026-09-26 14:39:50
68	1	125	keluar	-0.4000	22.3560	21.9560	Pemakaian pesanan RI-20260927-214	2	2026-09-27 15:51:34
69	2	125	keluar	-0.0600	3.3398	3.2798	Pemakaian pesanan RI-20260927-214	2	2026-09-27 15:51:34
70	4	126	keluar	-0.0600	4.0120	3.9520	Pemakaian pesanan RI-20260928-405	2	2026-09-28 09:40:09
71	2	126	keluar	-0.0090	3.2798	3.2708	Pemakaian pesanan RI-20260928-405	2	2026-09-28 09:40:09
72	1	127	keluar	-0.0200	21.9560	21.9360	Pemakaian pesanan RI-20260928-617	2	2026-09-28 19:10:45
73	7	127	keluar	-1.0000	110.0000	109.0000	Pemakaian pesanan RI-20260928-617	2	2026-09-28 19:10:45
74	3	127	keluar	-1.0000	124.0000	123.0000	Pemakaian pesanan RI-20260928-617	2	2026-09-28 19:10:45
75	1	128	keluar	-0.2000	21.9360	21.7360	Pemakaian pesanan RI-20260929-744	2	2026-09-29 16:52:08
76	5	128	keluar	-0.1000	4.3000	4.2000	Pemakaian pesanan RI-20260929-744	2	2026-09-29 16:52:08
77	4	129	keluar	-0.0800	3.9520	3.8720	Pemakaian pesanan RI-20260930-549	2	2026-09-30 13:55:03
78	7	129	keluar	-1.0000	109.0000	108.0000	Pemakaian pesanan RI-20260930-549	2	2026-09-30 13:55:03
79	3	129	keluar	-1.0000	123.0000	122.0000	Pemakaian pesanan RI-20260930-549	2	2026-09-30 13:55:03
80	1	130	keluar	-0.4000	21.7360	21.3360	Pemakaian pesanan RI-20260930-634	2	2026-09-30 16:36:17
81	5	130	keluar	-0.2000	4.2000	4.0000	Pemakaian pesanan RI-20260930-634	2	2026-09-30 16:36:17
82	4	\N	masuk	5.0000	3.8720	8.8720	Pembelian dari supplier	3	2026-10-01 07:30:00
83	1	131	keluar	-0.0480	21.3360	21.2880	Pemakaian pesanan RI-20261001-174	2	2026-10-01 16:26:34
84	2	131	keluar	-0.0072	3.2708	3.2636	Pemakaian pesanan RI-20261001-174	2	2026-10-01 16:26:34
85	1	132	keluar	-0.0960	21.2880	21.1920	Pemakaian pesanan RI-20261002-271	2	2026-10-02 11:17:59
86	2	132	keluar	-0.0144	3.2636	3.2492	Pemakaian pesanan RI-20261002-271	2	2026-10-02 11:17:59
87	1	133	keluar	-0.0400	21.1920	21.1520	Pemakaian pesanan RI-20261003-345	2	2026-10-03 08:30:31
88	2	133	keluar	-0.0060	3.2492	3.2432	Pemakaian pesanan RI-20261003-345	2	2026-10-03 08:30:31
89	7	133	keluar	-2.0000	108.0000	106.0000	Pemakaian pesanan RI-20261003-345	2	2026-10-03 08:30:31
90	3	133	keluar	-2.0000	122.0000	120.0000	Pemakaian pesanan RI-20261003-345	2	2026-10-03 08:30:31
91	6	134	keluar	-2.5000	6.0000	3.5000	Pemakaian pesanan RI-20261003-344	2	2026-10-03 13:48:30
92	5	134	keluar	-0.5000	4.0000	3.5000	Pemakaian pesanan RI-20261003-344	2	2026-10-03 13:48:30
93	1	135	keluar	-0.0720	21.1520	21.0800	Pemakaian pesanan RI-20261003-001	2	2026-10-03 17:54:41
94	2	135	keluar	-0.0108	3.2432	3.2324	Pemakaian pesanan RI-20261003-001	2	2026-10-03 17:54:41
95	7	135	keluar	-1.0000	106.0000	105.0000	Pemakaian pesanan RI-20261003-001	2	2026-10-03 17:54:41
96	3	135	keluar	-1.0000	120.0000	119.0000	Pemakaian pesanan RI-20261003-001	2	2026-10-03 17:54:41
97	5	\N	masuk	3.0000	3.5000	6.5000	Pembelian dari supplier	3	2026-10-05 07:30:00
98	1	137	keluar	-0.0800	21.0800	21.0000	Pemakaian pesanan RI-20261005-890	2	2026-10-05 13:32:49
99	2	137	keluar	-0.0120	3.2324	3.2204	Pemakaian pesanan RI-20261005-890	2	2026-10-05 13:32:49
100	7	137	keluar	-2.0000	105.0000	103.0000	Pemakaian pesanan RI-20261005-890	2	2026-10-05 13:32:49
101	3	137	keluar	-2.0000	119.0000	117.0000	Pemakaian pesanan RI-20261005-890	2	2026-10-05 13:32:49
102	4	136	keluar	-0.0160	8.8720	8.8560	Pemakaian pesanan RI-20261005-090	2	2026-10-05 17:41:32
103	1	138	keluar	-0.0800	21.0000	20.9200	Pemakaian pesanan RI-20261006-295	2	2026-10-06 10:20:00
104	1	139	keluar	-0.1000	20.9200	20.8200	Pemakaian pesanan RI-20261006-929	2	2026-10-06 15:47:50
105	7	139	keluar	-1.0000	103.0000	102.0000	Pemakaian pesanan RI-20261006-929	2	2026-10-06 15:47:50
106	3	139	keluar	-1.0000	117.0000	116.0000	Pemakaian pesanan RI-20261006-929	2	2026-10-06 15:47:50
107	1	140	keluar	-0.3200	20.8200	20.5000	Pemakaian pesanan RI-20261006-174	2	2026-10-06 18:55:44
108	5	140	keluar	-0.1600	6.5000	6.3400	Pemakaian pesanan RI-20261006-174	2	2026-10-06 18:55:44
109	7	140	keluar	-2.0000	102.0000	100.0000	Pemakaian pesanan RI-20261006-174	2	2026-10-06 18:55:44
110	3	140	keluar	-2.0000	116.0000	114.0000	Pemakaian pesanan RI-20261006-174	2	2026-10-06 18:55:44
111	4	142	keluar	-0.1200	8.8560	8.7360	Pemakaian pesanan RI-20261007-832	2	2026-10-07 18:45:08
112	1	143	keluar	-0.4000	20.5000	20.1000	Pemakaian pesanan RI-20261008-221	2	2026-10-08 19:21:17
113	1	145	keluar	-0.3200	20.1000	19.7800	Pemakaian pesanan RI-20261009-764	2	2026-10-09 17:32:10
114	2	145	keluar	-0.0480	3.2204	3.1724	Pemakaian pesanan RI-20261009-764	2	2026-10-09 17:32:10
115	1	144	keluar	-0.2000	19.7800	19.5800	Pemakaian pesanan RI-20261009-574	2	2026-10-09 19:39:36
116	2	144	keluar	-0.0300	3.1724	3.1424	Pemakaian pesanan RI-20261009-574	2	2026-10-09 19:39:36
117	3	144	keluar	-2.0000	114.0000	112.0000	Pemakaian pesanan RI-20261009-574	2	2026-10-09 19:39:36
118	9	144	keluar	-0.0500	5.6000	5.5500	Pemakaian pesanan RI-20261009-574	2	2026-10-09 19:39:36
119	1	146	keluar	-0.0600	19.5800	19.5200	Pemakaian pesanan RI-20261010-799	2	2026-10-10 14:55:04
120	2	146	keluar	-0.0090	3.1424	3.1334	Pemakaian pesanan RI-20261010-799	2	2026-10-10 14:55:04
121	6	148	keluar	-1.0000	3.5000	2.5000	Pemakaian pesanan RI-20261011-509	2	2026-10-11 15:30:30
122	5	148	keluar	-0.2000	6.3400	6.1400	Pemakaian pesanan RI-20261011-509	2	2026-10-11 15:30:30
123	6	\N	masuk	3.0000	2.5000	5.5000	Pembelian dari supplier	3	2026-10-12 07:30:00
124	1	150	keluar	-0.2000	19.5200	19.3200	Pemakaian pesanan RI-20261012-971	2	2026-10-12 08:51:47
125	2	150	keluar	-0.0300	3.1334	3.1034	Pemakaian pesanan RI-20261012-971	2	2026-10-12 08:51:47
126	8	150	keluar	-1.0000	19.0000	18.0000	Pemakaian pesanan RI-20261012-971	2	2026-10-12 08:51:47
127	6	149	keluar	-1.0000	5.5000	4.5000	Pemakaian pesanan RI-20261012-669	2	2026-10-12 12:33:04
128	5	149	keluar	-0.2000	6.1400	5.9400	Pemakaian pesanan RI-20261012-669	2	2026-10-12 12:33:04
129	1	151	keluar	-0.0480	19.3200	19.2720	Pemakaian pesanan RI-20261013-583	2	2026-10-13 10:24:37
130	2	151	keluar	-0.0072	3.1034	3.0962	Pemakaian pesanan RI-20261013-583	2	2026-10-13 10:24:37
131	7	151	keluar	-1.0000	100.0000	99.0000	Pemakaian pesanan RI-20261013-583	2	2026-10-13 10:24:37
132	3	151	keluar	-1.0000	112.0000	111.0000	Pemakaian pesanan RI-20261013-583	2	2026-10-13 10:24:37
133	1	152	keluar	-0.0800	19.2720	19.1920	Pemakaian pesanan RI-20261013-097	2	2026-10-13 10:41:39
134	2	152	keluar	-0.0120	3.0962	3.0842	Pemakaian pesanan RI-20261013-097	2	2026-10-13 10:41:39
135	4	153	keluar	-0.0720	8.7360	8.6640	Pemakaian pesanan RI-20261013-105	2	2026-10-13 16:17:18
136	3	153	keluar	-6.0000	111.0000	105.0000	Pemakaian pesanan RI-20261013-105	2	2026-10-13 16:17:18
137	9	153	keluar	-0.1500	5.5500	5.4000	Pemakaian pesanan RI-20261013-105	2	2026-10-13 16:17:18
138	4	154	keluar	-0.0480	8.6640	8.6160	Pemakaian pesanan RI-20261014-987	2	2026-10-14 12:14:02
139	1	155	keluar	-0.0240	19.1920	19.1680	Pemakaian pesanan RI-20261014-817	2	2026-10-14 13:19:57
140	7	155	keluar	-1.0000	99.0000	98.0000	Pemakaian pesanan RI-20261014-817	2	2026-10-14 13:19:57
141	3	155	keluar	-1.0000	105.0000	104.0000	Pemakaian pesanan RI-20261014-817	2	2026-10-14 13:19:57
142	1	156	keluar	-0.2000	19.1680	18.9680	Pemakaian pesanan RI-20261014-815	2	2026-10-14 14:07:50
143	5	156	keluar	-0.1000	5.9400	5.8400	Pemakaian pesanan RI-20261014-815	2	2026-10-14 14:07:50
144	1	157	keluar	-0.0720	18.9680	18.8960	Pemakaian pesanan RI-20261015-063	2	2026-10-15 16:54:34
145	7	157	keluar	-1.0000	98.0000	97.0000	Pemakaian pesanan RI-20261015-063	2	2026-10-15 16:54:34
146	3	157	keluar	-1.0000	104.0000	103.0000	Pemakaian pesanan RI-20261015-063	2	2026-10-15 16:54:34
147	1	158	keluar	-0.0400	18.8960	18.8560	Pemakaian pesanan RI-20261015-860	2	2026-10-15 17:26:04
148	2	158	keluar	-0.0060	3.0842	3.0782	Pemakaian pesanan RI-20261015-860	2	2026-10-15 17:26:04
149	1	159	keluar	-0.2400	18.8560	18.6160	Pemakaian pesanan RI-20261016-753	2	2026-10-16 12:51:50
150	2	159	keluar	-0.0360	3.0782	3.0422	Pemakaian pesanan RI-20261016-753	2	2026-10-16 12:51:50
151	1	161	keluar	-0.0080	18.6160	18.6080	Pemakaian pesanan RI-20261017-129	2	2026-10-17 09:04:35
152	2	161	keluar	-0.0012	3.0422	3.0410	Pemakaian pesanan RI-20261017-129	2	2026-10-17 09:04:35
153	4	160	keluar	-0.0080	8.6160	8.6080	Pemakaian pesanan RI-20261017-456	2	2026-10-17 15:20:05
154	2	160	keluar	-0.0012	3.0410	3.0398	Pemakaian pesanan RI-20261017-456	2	2026-10-17 15:20:05
155	7	160	keluar	-1.0000	97.0000	96.0000	Pemakaian pesanan RI-20261017-456	2	2026-10-17 15:20:05
156	3	160	keluar	-1.0000	103.0000	102.0000	Pemakaian pesanan RI-20261017-456	2	2026-10-17 15:20:05
157	1	162	keluar	-0.0300	18.6080	18.5780	Pemakaian pesanan RI-20261019-638	2	2026-10-19 16:03:42
158	1	164	keluar	-0.0800	18.5780	18.4980	Pemakaian pesanan RI-20261020-888	2	2026-10-20 13:23:54
159	2	164	keluar	-0.0120	3.0398	3.0278	Pemakaian pesanan RI-20261020-888	2	2026-10-20 13:23:54
160	3	164	keluar	-2.0000	102.0000	100.0000	Pemakaian pesanan RI-20261020-888	2	2026-10-20 13:23:54
161	9	164	keluar	-0.0500	5.4000	5.3500	Pemakaian pesanan RI-20261020-888	2	2026-10-20 13:23:54
162	1	167	keluar	-0.2000	18.4980	18.2980	Pemakaian pesanan RI-20261021-858	2	2026-10-21 10:14:04
163	7	167	keluar	-1.0000	96.0000	95.0000	Pemakaian pesanan RI-20261021-858	2	2026-10-21 10:14:04
164	3	167	keluar	-1.0000	100.0000	99.0000	Pemakaian pesanan RI-20261021-858	2	2026-10-21 10:14:04
165	1	165	keluar	-0.0600	18.2980	18.2380	Pemakaian pesanan RI-20261021-896	2	2026-10-21 14:26:33
166	3	165	keluar	-2.0000	99.0000	97.0000	Pemakaian pesanan RI-20261021-896	2	2026-10-21 14:26:33
167	9	165	keluar	-0.0500	5.3500	5.3000	Pemakaian pesanan RI-20261021-896	2	2026-10-21 14:26:33
168	4	166	keluar	-0.0080	8.6080	8.6000	Pemakaian pesanan RI-20261021-993	2	2026-10-21 18:20:58
169	2	166	keluar	-0.0012	3.0278	3.0266	Pemakaian pesanan RI-20261021-993	2	2026-10-21 18:20:58
170	6	168	keluar	-0.7500	4.5000	3.7500	Pemakaian pesanan RI-20261022-466	2	2026-10-22 18:54:04
171	5	168	keluar	-0.1500	5.8400	5.6900	Pemakaian pesanan RI-20261022-466	2	2026-10-22 18:54:04
172	1	169	keluar	-0.0480	18.2380	18.1900	Pemakaian pesanan RI-20261023-219	2	2026-10-23 09:08:22
173	2	169	keluar	-0.0072	3.0266	3.0194	Pemakaian pesanan RI-20261023-219	2	2026-10-23 09:08:22
174	7	169	keluar	-1.0000	95.0000	94.0000	Pemakaian pesanan RI-20261023-219	2	2026-10-23 09:08:22
175	3	169	keluar	-1.0000	97.0000	96.0000	Pemakaian pesanan RI-20261023-219	2	2026-10-23 09:08:22
176	1	171	keluar	-0.1800	18.1900	18.0100	Pemakaian pesanan RI-20261024-390	2	2026-10-24 11:05:24
177	2	171	keluar	-0.0270	3.0194	2.9924	Pemakaian pesanan RI-20261024-390	2	2026-10-24 11:05:24
178	1	170	keluar	-0.2000	18.0100	17.8100	Pemakaian pesanan RI-20261024-493	2	2026-10-24 15:34:13
179	8	170	keluar	-2.0000	18.0000	16.0000	Pemakaian pesanan RI-20261024-493	2	2026-10-24 15:34:13
180	1	173	keluar	-0.2000	17.8100	17.6100	Pemakaian pesanan RI-20261025-531	2	2026-10-25 13:38:03
181	5	173	keluar	-0.1000	5.6900	5.5900	Pemakaian pesanan RI-20261025-531	2	2026-10-25 13:38:03
182	4	174	keluar	-0.1000	8.6000	8.5000	Pemakaian pesanan RI-20261026-720	2	2026-10-26 13:26:37
183	2	174	keluar	-0.0150	2.9924	2.9774	Pemakaian pesanan RI-20261026-720	2	2026-10-26 13:26:37
184	1	176	keluar	-0.1600	17.6100	17.4500	Pemakaian pesanan RI-20261027-010	2	2026-10-27 09:11:21
185	2	176	keluar	-0.0240	2.9774	2.9534	Pemakaian pesanan RI-20261027-010	2	2026-10-27 09:11:21
186	7	176	keluar	-1.0000	94.0000	93.0000	Pemakaian pesanan RI-20261027-010	2	2026-10-27 09:11:21
187	3	176	keluar	-1.0000	96.0000	95.0000	Pemakaian pesanan RI-20261027-010	2	2026-10-27 09:11:21
188	1	175	keluar	-0.2400	17.4500	17.2100	Pemakaian pesanan RI-20261027-014	2	2026-10-27 19:15:00
189	1	177	keluar	-0.1000	17.2100	17.1100	Pemakaian pesanan RI-20261028-607	2	2026-10-28 09:00:08
190	2	177	keluar	-0.0150	2.9534	2.9384	Pemakaian pesanan RI-20261028-607	2	2026-10-28 09:00:08
191	1	4	keluar	-0.0040	17.1100	17.1060	Pemakaian pesanan data uji tim	2	2026-10-29 02:52:36
192	2	4	keluar	-0.0006	2.9384	2.9378	Pemakaian pesanan data uji tim	2	2026-10-29 02:52:36
193	1	5	keluar	-0.0020	17.1060	17.1040	Pemakaian pesanan data uji tim	2	2026-10-29 04:01:13
194	2	5	keluar	-0.0003	2.9378	2.9375	Pemakaian pesanan data uji tim	2	2026-10-29 04:01:13
195	4	178	keluar	-0.2400	8.5000	8.2600	Pemakaian pesanan RI-20261029-293	2	2026-10-29 19:39:02
196	2	178	keluar	-0.0360	2.9375	2.9015	Pemakaian pesanan RI-20261029-293	2	2026-10-29 19:39:02
197	3	178	keluar	-2.0000	95.0000	93.0000	Pemakaian pesanan RI-20261029-293	2	2026-10-29 19:39:02
198	9	178	keluar	-0.0500	5.3000	5.2500	Pemakaian pesanan RI-20261029-293	2	2026-10-29 19:39:02
199	1	180	keluar	-0.0800	17.1040	17.0240	Pemakaian pesanan RI-20261030-593	2	2026-10-30 17:07:56
200	1	179	keluar	-0.3200	17.0240	16.7040	Pemakaian pesanan RI-20261030-693	2	2026-10-30 19:34:37
201	3	179	keluar	-4.0000	93.0000	89.0000	Pemakaian pesanan RI-20261030-693	2	2026-10-30 19:34:37
202	9	179	keluar	-0.1000	5.2500	5.1500	Pemakaian pesanan RI-20261030-693	2	2026-10-30 19:34:37
203	1	182	keluar	-0.0600	16.7040	16.6440	Pemakaian pesanan RI-20261031-762	2	2026-10-31 15:33:21
204	2	182	keluar	-0.0090	2.9015	2.8925	Pemakaian pesanan RI-20261031-762	2	2026-10-31 15:33:21
205	8	182	keluar	-1.0000	16.0000	15.0000	Pemakaian pesanan RI-20261031-762	2	2026-10-31 15:33:21
206	1	183	keluar	-0.0300	16.6440	16.6140	Pemakaian pesanan RI-20261101-892	2	2026-11-01 16:20:43
207	2	183	keluar	-0.0045	2.8925	2.8880	Pemakaian pesanan RI-20261101-892	2	2026-11-01 16:20:43
208	1	184	keluar	-0.0400	16.6140	16.5740	Pemakaian pesanan RI-20261102-750	2	2026-11-02 12:10:31
209	5	184	keluar	-0.0200	5.5900	5.5700	Pemakaian pesanan RI-20261102-750	2	2026-11-02 12:10:31
210	1	185	keluar	-0.2000	16.5740	16.3740	Pemakaian pesanan RI-20261103-420	2	2026-11-03 15:57:03
211	5	185	keluar	-0.1000	5.5700	5.4700	Pemakaian pesanan RI-20261103-420	2	2026-11-03 15:57:03
212	4	187	keluar	-0.1440	8.2600	8.1160	Pemakaian pesanan RI-20261104-887	2	2026-11-04 10:20:58
213	2	187	keluar	-0.0216	2.8880	2.8664	Pemakaian pesanan RI-20261104-887	2	2026-11-04 10:20:58
214	1	186	keluar	-0.1200	16.3740	16.2540	Pemakaian pesanan RI-20261104-632	2	2026-11-04 16:54:46
215	2	186	keluar	-0.0180	2.8664	2.8484	Pemakaian pesanan RI-20261104-632	2	2026-11-04 16:54:46
216	4	188	keluar	-0.1200	8.1160	7.9960	Pemakaian pesanan RI-20261105-077	2	2026-11-05 18:57:47
217	1	189	keluar	-0.0080	16.2540	16.2460	Pemakaian pesanan RI-20261106-633	2	2026-11-06 15:48:54
218	2	189	keluar	-0.0012	2.8484	2.8472	Pemakaian pesanan RI-20261106-633	2	2026-11-06 15:48:54
219	7	189	keluar	-1.0000	93.0000	92.0000	Pemakaian pesanan RI-20261106-633	2	2026-11-06 15:48:54
220	3	189	keluar	-1.0000	89.0000	88.0000	Pemakaian pesanan RI-20261106-633	2	2026-11-06 15:48:54
221	4	190	keluar	-0.0720	7.9960	7.9240	Pemakaian pesanan RI-20261107-164	2	2026-11-07 10:19:53
222	2	190	keluar	-0.0108	2.8472	2.8364	Pemakaian pesanan RI-20261107-164	2	2026-11-07 10:19:53
223	3	190	keluar	-2.0000	88.0000	86.0000	Pemakaian pesanan RI-20261107-164	2	2026-11-07 10:19:53
224	9	190	keluar	-0.0500	5.1500	5.1000	Pemakaian pesanan RI-20261107-164	2	2026-11-07 10:19:53
225	1	191	keluar	-0.1600	16.2460	16.0860	Pemakaian pesanan RI-20261107-162	2	2026-11-07 15:06:47
226	2	191	keluar	-0.0240	2.8364	2.8124	Pemakaian pesanan RI-20261107-162	2	2026-11-07 15:06:47
227	1	7	keluar	-0.0040	16.0860	16.0820	Pemakaian pesanan data uji tim	2	2026-11-08 17:20:25
228	2	7	keluar	-0.0006	2.8124	2.8118	Pemakaian pesanan data uji tim	2	2026-11-08 17:20:25
229	8	\N	koreksi	-15.0000	15.0000	0.0000	Stock opname: sisa hard cover rusak/terlipat	3	2026-11-08 19:00:00
230	1	194	keluar	-0.2000	16.0820	15.8820	Pemakaian pesanan RI-20261109-206	2	2026-11-09 11:08:42
231	1	192	keluar	-0.0200	15.8820	15.8620	Pemakaian pesanan RI-20261109-835	2	2026-11-09 14:25:42
232	5	192	keluar	-0.0100	5.4700	5.4600	Pemakaian pesanan RI-20261109-835	2	2026-11-09 14:25:42
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, nama, email, password, no_telepon, role, created_at) FROM stdin;
1	Ahmad Fauzi	ahmad@example.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	081234567890	pelanggan	2026-10-14 21:08:21.663971
4	Uji Pelanggan	uji.pelanggan@example.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	081234567890	pelanggan	2026-10-21 00:06:38.105855
3	Pemilik Restu Ibu	owner@easyprint.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	081122334455	owner	2026-10-14 21:08:21.663971
5	Tes CP2	tes.cp2@example.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	081234567890	pelanggan	2026-10-29 01:28:55.405456
2	Operator Restu Ibu	operator@easyprint.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	089876543210	admin	2026-10-14 21:08:21.663971
6	Sinta Maharani	sinta.maharani@example.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	081233450011	pelanggan	2026-09-16 10:00:00
7	Rizky Pratama	rizky.pratama@example.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	085746120982	pelanggan	2026-09-17 10:00:00
8	Nadia Putri	nadia.putri@example.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	081335667120	pelanggan	2026-09-18 10:00:00
9	Bima Saputra	bima.saputra@example.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	089677542210	pelanggan	2026-09-10 10:00:00
10	Rani Anggraini	rani.anggraini@example.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	082142553009	pelanggan	2026-09-11 10:00:00
11	Fikri Hidayat	fikri.hidayat@example.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	081931224576	pelanggan	2026-09-12 10:00:00
12	Dewi Lestari	dewi.lestari@example.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	087853119024	pelanggan	2026-09-13 10:00:00
13	CV Mitra Karya	admin@mitrakarya.example.com	$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG	0341491234	pelanggan	2026-09-14 10:00:00
\.


--
-- Name: auth_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_tokens_id_seq', 18, true);


--
-- Name: bahan_baku_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bahan_baku_id_seq', 9, true);


--
-- Name: bahan_layanan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bahan_layanan_id_seq', 15, true);


--
-- Name: detail_pesanan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.detail_pesanan_id_seq', 150, true);


--
-- Name: layanan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.layanan_id_seq', 9, true);


--
-- Name: notifikasi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifikasi_id_seq', 48, true);


--
-- Name: notifikasi_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifikasi_users_id_seq', 58, true);


--
-- Name: pesanan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pesanan_id_seq', 197, true);


--
-- Name: riwayat_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.riwayat_status_id_seq', 459, true);


--
-- Name: riwayat_stok_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.riwayat_stok_id_seq', 232, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 13, true);


--
-- Name: auth_tokens auth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_pkey PRIMARY KEY (id);


--
-- Name: auth_tokens auth_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: bahan_baku bahan_baku_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bahan_baku
    ADD CONSTRAINT bahan_baku_pkey PRIMARY KEY (id);


--
-- Name: bahan_layanan bahan_layanan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bahan_layanan
    ADD CONSTRAINT bahan_layanan_pkey PRIMARY KEY (id);


--
-- Name: detail_pesanan detail_pesanan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detail_pesanan
    ADD CONSTRAINT detail_pesanan_pkey PRIMARY KEY (id);


--
-- Name: layanan layanan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.layanan
    ADD CONSTRAINT layanan_pkey PRIMARY KEY (id);


--
-- Name: notifikasi notifikasi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifikasi
    ADD CONSTRAINT notifikasi_pkey PRIMARY KEY (id);


--
-- Name: notifikasi_users notifikasi_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifikasi_users
    ADD CONSTRAINT notifikasi_users_pkey PRIMARY KEY (id);


--
-- Name: pesanan pesanan_kode_pesanan_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pesanan
    ADD CONSTRAINT pesanan_kode_pesanan_key UNIQUE (kode_pesanan);


--
-- Name: pesanan pesanan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pesanan
    ADD CONSTRAINT pesanan_pkey PRIMARY KEY (id);


--
-- Name: riwayat_status riwayat_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.riwayat_status
    ADD CONSTRAINT riwayat_status_pkey PRIMARY KEY (id);


--
-- Name: riwayat_stok riwayat_stok_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.riwayat_stok
    ADD CONSTRAINT riwayat_stok_pkey PRIMARY KEY (id);


--
-- Name: bahan_layanan uq_bahan_layanan; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bahan_layanan
    ADD CONSTRAINT uq_bahan_layanan UNIQUE (layanan_id, bahan_baku_id);


--
-- Name: notifikasi_users uq_notifikasi_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifikasi_users
    ADD CONSTRAINT uq_notifikasi_user UNIQUE (notifikasi_id, user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_auth_tokens_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_tokens_expires_at ON public.auth_tokens USING btree (expires_at);


--
-- Name: idx_auth_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_tokens_user_id ON public.auth_tokens USING btree (user_id);


--
-- Name: idx_detail_pesanan_pesanan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_detail_pesanan_pesanan_id ON public.detail_pesanan USING btree (pesanan_id);


--
-- Name: idx_pesanan_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pesanan_created_at ON public.pesanan USING btree (created_at);


--
-- Name: idx_pesanan_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pesanan_status ON public.pesanan USING btree (status);


--
-- Name: idx_pesanan_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pesanan_user_id ON public.pesanan USING btree (user_id);


--
-- Name: idx_riwayat_status_pesanan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_riwayat_status_pesanan ON public.riwayat_status USING btree (pesanan_id, created_at);


--
-- Name: idx_riwayat_stok_bahan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_riwayat_stok_bahan ON public.riwayat_stok USING btree (bahan_baku_id, created_at);


--
-- Name: idx_riwayat_stok_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_riwayat_stok_created ON public.riwayat_stok USING btree (created_at);


--
-- Name: layanan trg_cek_harga_layanan; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_cek_harga_layanan BEFORE INSERT OR UPDATE OF harga ON public.layanan FOR EACH ROW EXECUTE FUNCTION public.fn_cek_harga_layanan();


--
-- Name: detail_pesanan trg_cek_jumlah_detail; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_cek_jumlah_detail BEFORE INSERT OR UPDATE OF jumlah ON public.detail_pesanan FOR EACH ROW EXECUTE FUNCTION public.fn_cek_jumlah_detail();


--
-- Name: bahan_baku trg_cek_stok_bahan; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_cek_stok_bahan BEFORE INSERT OR UPDATE OF stok ON public.bahan_baku FOR EACH ROW EXECUTE FUNCTION public.fn_cek_stok_bahan();


--
-- Name: bahan_baku trg_log_mutasi_stok; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_log_mutasi_stok AFTER INSERT OR UPDATE OF stok ON public.bahan_baku FOR EACH ROW EXECUTE FUNCTION public.fn_log_mutasi_stok();


--
-- Name: pesanan trg_log_status_pesanan; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_log_status_pesanan AFTER INSERT OR UPDATE OF status ON public.pesanan FOR EACH ROW EXECUTE FUNCTION public.fn_log_status_pesanan();


--
-- Name: pesanan trg_notifikasi_status_pesanan; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_notifikasi_status_pesanan AFTER UPDATE OF status ON public.pesanan FOR EACH ROW EXECUTE FUNCTION public.fn_notifikasi_status_pesanan();


--
-- Name: bahan_baku trg_peringatan_stok_kritis; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_peringatan_stok_kritis AFTER INSERT OR UPDATE OF stok, reorder_point ON public.bahan_baku FOR EACH ROW EXECUTE FUNCTION public.fn_peringatan_stok_kritis();


--
-- Name: pesanan trg_pesanan_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_pesanan_updated_at BEFORE UPDATE ON public.pesanan FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();


--
-- Name: bahan_baku trg_update_status_bahan; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_update_status_bahan BEFORE INSERT OR UPDATE OF stok, reorder_point ON public.bahan_baku FOR EACH ROW EXECUTE FUNCTION public.fn_update_status_bahan();


--
-- Name: detail_pesanan trg_update_total_pesanan; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_update_total_pesanan AFTER INSERT OR DELETE OR UPDATE ON public.detail_pesanan FOR EACH ROW EXECUTE FUNCTION public.fn_update_total_pesanan();


--
-- Name: auth_tokens auth_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bahan_layanan fk_bahan_layanan_bahan; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bahan_layanan
    ADD CONSTRAINT fk_bahan_layanan_bahan FOREIGN KEY (bahan_baku_id) REFERENCES public.bahan_baku(id) ON DELETE CASCADE;


--
-- Name: bahan_layanan fk_bahan_layanan_layanan; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bahan_layanan
    ADD CONSTRAINT fk_bahan_layanan_layanan FOREIGN KEY (layanan_id) REFERENCES public.layanan(id) ON DELETE CASCADE;


--
-- Name: detail_pesanan fk_detail_layanan; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detail_pesanan
    ADD CONSTRAINT fk_detail_layanan FOREIGN KEY (layanan_id) REFERENCES public.layanan(id) ON DELETE RESTRICT;


--
-- Name: detail_pesanan fk_detail_pesanan; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detail_pesanan
    ADD CONSTRAINT fk_detail_pesanan FOREIGN KEY (pesanan_id) REFERENCES public.pesanan(id) ON DELETE CASCADE;


--
-- Name: notifikasi fk_notifikasi_pesanan; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifikasi
    ADD CONSTRAINT fk_notifikasi_pesanan FOREIGN KEY (pesanan_id) REFERENCES public.pesanan(id) ON DELETE SET NULL;


--
-- Name: notifikasi_users fk_notifikasi_users_notifikasi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifikasi_users
    ADD CONSTRAINT fk_notifikasi_users_notifikasi FOREIGN KEY (notifikasi_id) REFERENCES public.notifikasi(id) ON DELETE CASCADE;


--
-- Name: notifikasi_users fk_notifikasi_users_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifikasi_users
    ADD CONSTRAINT fk_notifikasi_users_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: pesanan fk_pesanan_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pesanan
    ADD CONSTRAINT fk_pesanan_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: riwayat_status riwayat_status_diubah_oleh_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.riwayat_status
    ADD CONSTRAINT riwayat_status_diubah_oleh_fkey FOREIGN KEY (diubah_oleh) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: riwayat_status riwayat_status_pesanan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.riwayat_status
    ADD CONSTRAINT riwayat_status_pesanan_id_fkey FOREIGN KEY (pesanan_id) REFERENCES public.pesanan(id) ON DELETE CASCADE;


--
-- Name: riwayat_stok riwayat_stok_bahan_baku_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.riwayat_stok
    ADD CONSTRAINT riwayat_stok_bahan_baku_id_fkey FOREIGN KEY (bahan_baku_id) REFERENCES public.bahan_baku(id) ON DELETE CASCADE;


--
-- Name: riwayat_stok riwayat_stok_pesanan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.riwayat_stok
    ADD CONSTRAINT riwayat_stok_pesanan_id_fkey FOREIGN KEY (pesanan_id) REFERENCES public.pesanan(id) ON DELETE SET NULL;


--
-- Name: riwayat_stok riwayat_stok_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.riwayat_stok
    ADD CONSTRAINT riwayat_stok_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict hkAwllfPRJUgCi9SRPIZNUclIbQBs9flZDbyycGa6SJ4y4TSuif9jE8N43oFyQD

