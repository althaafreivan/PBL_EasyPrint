#!/usr/bin/env python3
"""
Generator data uji EasyPrint (deterministik, seed acak tetap).

Menghasilkan database/seed/002_data_uji.sql yang berisi:
  - 8 pelanggan tambahan, 6 layanan baru, 6 bahan baku baru, konfigurasi BOM
  - +-100 pesanan 14 Sep - 9 Nov 2026 dengan riwayat status realistis
  - riwayat stok (stok awal, pemakaian per pesanan, pembelian supplier)
  - notifikasi untuk aktivitas beberapa hari terakhir

Jalankan ulang bila ingin mengubah parameter:
    python3 database/seed/generate_seed.py > database/seed/002_data_uji.sql
"""
import random
from datetime import datetime, timedelta, time
from decimal import Decimal, ROUND_HALF_UP

random.seed(20261109)
NOW = datetime(2026, 11, 9, 16, 30)
START = datetime(2026, 9, 14)
PASSWORD_HASH = "$2y$12$Kq69GPS6KG4rw/agt0tG2Oasoocc.JyovblFO//pI/TNUN43MjwGG"  # EasyPrintTest2026!

def q(s):
    return "NULL" if s is None else "'" + str(s).replace("'", "''") + "'"

def ts(d):
    return "NULL" if d is None else q(d.strftime("%Y-%m-%d %H:%M:%S"))

def dec(x, p=4):
    return str(Decimal(x).quantize(Decimal(10) ** -p, rounding=ROUND_HALF_UP))

# ---------------------------------------------------------------- master data
PELANGGAN = [
    (6,  "Sinta Maharani",   "sinta.maharani@example.com",  "081233450011"),
    (7,  "Rizky Pratama",    "rizky.pratama@example.com",   "085746120982"),
    (8,  "Nadia Putri",      "nadia.putri@example.com",     "081335667120"),
    (9,  "Bima Saputra",     "bima.saputra@example.com",    "089677542210"),
    (10, "Rani Anggraini",   "rani.anggraini@example.com",  "082142553009"),
    (11, "Fikri Hidayat",    "fikri.hidayat@example.com",   "081931224576"),
    (12, "Dewi Lestari",     "dewi.lestari@example.com",    "087853119024"),
    (13, "CV Mitra Karya",   "admin@mitrakarya.example.com", "0341491234"),
]
# pelanggan lama yang ikut dipakai
PEL_IDS = [1, 4, 5] + [p[0] for p in PELANGGAN]
PEL_BOBOT = [3, 1, 1, 4, 3, 4, 2, 3, 3, 2, 2]

# id, nama, harga, satuan, kategori, deskripsi
LAYANAN_BARU = [
    (4, "Print A4 Warna",         1500,  "lembar", "cetak",     "Cetak full color kertas HVS A4 80gr"),
    (5, "Print F4 Hitam Putih",    600,  "lembar", "cetak",     "Cetak hitam putih kertas HVS F4 70gr"),
    (6, "Fotokopi A4 Hitam Putih", 300,  "lembar", "fotokopi",  "Fotokopi hitam putih kertas A4 70gr"),
    (7, "Fotokopi F4 Hitam Putih", 350,  "lembar", "fotokopi",  "Fotokopi hitam putih kertas F4 70gr"),
    (8, "Jilid Spiral",           7000,  "buku",   "finishing", "Jilid ring spiral dengan cover mika bening"),
    (9, "Jilid Hard Cover",      25000,  "buku",   "finishing", "Jilid hard cover untuk skripsi/laporan"),
]
HARGA = {1: 500, 2: 5000, 3: 2500, **{l[0]: l[2] for l in LAYANAN_BARU}}
NAMA_LAYANAN = {1: "Print HVS A4 Hitam Putih", 2: "Jilid Lakban", 3: "Cetak Brosur Glossy A4",
                **{l[0]: l[1] for l in LAYANAN_BARU}}

# id, nama, satuan, reorder_point, harga_satuan
BAHAN_BARU = [
    (4, "Kertas HVS F4 70gr",            "rim",   3,  52000),
    (5, "Tinta Warna Epson 003 (CMY)",   "botol", 3,  85000),
    (6, "Kertas Art Paper A4 150gr",     "pak",   2,  65000),
    (7, "Ring Spiral",                   "pcs",  20,   1500),
    (8, "Hard Cover A4",                 "pcs",   5,   9000),
    (9, "Lakban Hitam",                  "roll",  2,  12000),
]
REORDER = {1: 5, 2: 3, 3: 10, **{b[0]: b[3] for b in BAHAN_BARU}}
SATUAN = {1: "rim", 2: "botol", 3: "lembar", **{b[0]: b[2] for b in BAHAN_BARU}}
NAMA_BAHAN = {1: "Kertas HVS A4 70gr", 2: "Tinta Hitam Epson 003", 3: "Mika Bening A4",
              **{b[0]: b[1] for b in BAHAN_BARU}}

# Bill of Materials (layanan_id, bahan_id, kebutuhan per satuan layanan). (1,1) & (2,3) sudah ada di dump.
BOM_BARU = [
    (1, 2, "0.0003"), (2, 9, "0.0500"),
    (3, 6, "0.0100"), (3, 5, "0.0020"),
    (4, 1, "0.0020"), (4, 5, "0.0010"),
    (5, 4, "0.0020"), (5, 2, "0.0003"),
    (6, 1, "0.0020"),
    (7, 4, "0.0020"),
    (8, 7, "1.0000"), (8, 3, "1.0000"),
    (9, 8, "1.0000"),
]
BOM = {}
for l, b, k in [(1, 1, "0.0020"), (2, 3, "2.0000")] + BOM_BARU:
    BOM.setdefault(l, []).append((b, Decimal(k)))

# Stok awal 14 Sep, paket pembelian & batas berhenti restock (agar demo punya item kritis)
STOK_AWAL = {1: 25, 2: 3.5, 3: 150, 4: 4.5, 5: 5, 6: 6, 7: 120, 8: 20, 9: 6}
PAKET     = {1: 10, 2: 4, 3: 100, 4: 5, 5: 3, 6: 3, 7: 50, 8: 10, 9: 3}
STOP_RESTOCK = {2: datetime(2026, 9, 1), 8: datetime(2026, 10, 28), 4: datetime(2026, 10, 15)}

# ---------------------------------------------------------------- pesanan
UTAMA = [(1, 40), (6, 25), (4, 10), (5, 8), (7, 7), (3, 4)]
FINISH = [(8, 50), (2, 35), (9, 15)]
CATATAN = [None, None, None, "Mohon dijilid rapi", "Cetak bolak-balik", "Ambil sore hari",
           "Halaman 1-3 berwarna", "Untuk tugas kuliah, mohon cepat", "Margin kiri lebih lebar",
           "Fotokopi 2 rangkap", None, "Cover warna biru"]
ALASAN_TOLAK = [
    "Berkas tidak terbaca / buram. Mohon scan ulang dengan resolusi lebih tinggi.",
    "Berkas terkunci password sehingga tidak dapat dicetak.",
    "Jumlah halaman berkas tidak sesuai dengan jumlah lembar yang dipesan.",
]

def pilih(opsi):
    return random.choices([o[0] for o in opsi], weights=[o[1] for o in opsi])[0]

orders = []           # dict per pesanan
kode_terpakai = set()
pid = 100             # id pesanan seed mulai 100 agar tidak bentrok dengan data uji tim

hari = START
while hari.date() <= NOW.date():
    n = random.choice([1, 1, 2, 2, 2, 3]) if hari.weekday() < 5 else random.choice([2, 3, 3])
    if hari.weekday() == 6:
        n = random.choice([0, 1])
    if hari.date() == NOW.date():
        n = 5
    for _ in range(n):
        jam = random.randint(8, 18 if hari.date() != NOW.date() else 15)
        t0 = datetime.combine(hari.date(), time(jam, random.randint(0, 59), random.randint(0, 59)))
        if t0 > NOW:
            continue
        user = random.choices(PEL_IDS, weights=PEL_BOBOT)[0]
        utama = pilih(UTAMA)
        lembar = random.choice([4, 8, 10, 12, 15, 20, 24, 30, 36, 40, 50, 60, 80, 100, 120])
        if utama == 3:
            lembar = random.choice([25, 50, 100])
        eks = random.choices([1, 2, 3, 5], weights=[60, 25, 10, 5])[0]
        items = [(utama, lembar * eks, f"{lembar} lembar x {eks} eks"
                  + (" | dua sisi" if random.random() < 0.3 else ""))]
        if random.random() < 0.35 and utama != 3:
            fin = pilih(FINISH)
            items.append((fin, eks, f"{eks} buku"))
        while True:
            kode = f"RI-{t0:%Y%m%d}-{random.randint(1, 999):03d}"
            if kode not in kode_terpakai:
                kode_terpakai.add(kode)
                break
        umur = (NOW - t0).total_seconds() / 3600
        r = random.random()
        if umur > 72:
            alur = "tolak" if r < 0.05 else ("selesai" if r < 0.08 else "diambil")
        elif umur > 24:
            alur = "tolak" if r < 0.05 else ("selesai" if r < 0.45 else "diambil")
        elif umur > 6:
            alur = random.choice(["diproses", "selesai", "selesai", "diambil"])
        else:
            alur = random.choice(["pending", "pending", "verif", "diproses"])
        orders.append(dict(id=pid, kode=kode, user=user, t0=t0, items=items, alur=alur,
                           catatan=random.choice(CATATAN), file=random.random() < 0.85))
        pid += 1
    hari += timedelta(days=1)

# Satu pesanan hari ini yang membutuhkan hard cover -> akan tertunda karena stok habis
orders.append(dict(id=pid, kode=f"RI-{NOW:%Y%m%d}-777", user=6,
                   t0=NOW.replace(hour=9, minute=12, second=5),
                   items=[(1, 120, "120 lembar x 1 eks"), (9, 1, "1 buku")],
                   alur="tertunda", catatan="Skripsi, jilid hard cover warna biru dongker", file=True))
pid += 1

def tambah_menit(t, a, b):
    return t + timedelta(minutes=random.randint(a, b))

for o in orders:
    t0 = o["t0"]
    langkah = [(None, "Pending", t0, "Pesanan dibuat", o["user"])]
    t = t0
    alur = o["alur"]
    if alur == "pending":
        pass
    elif alur == "tolak":
        t = tambah_menit(t, 8, 45)
        o["alasan"] = random.choice(ALASAN_TOLAK)
        langkah.append(("Pending", "Ditolak", t, o["alasan"], 2))
    else:
        t = tambah_menit(t, 5, 40)
        langkah.append(("Pending", "Diverifikasi", t, None, 2))
        if alur == "tertunda":
            t = tambah_menit(t, 3, 15)
            langkah.append(("Diverifikasi", "Tertunda - Stok Tidak Tersedia", t,
                            "Stok Hard Cover A4 tidak mencukupi", 2))
        elif alur != "verif":
            t = tambah_menit(t, 3, 30)
            langkah.append(("Diverifikasi", "Diproses", t, None, 2))
            o["t_proses"] = t
            if alur in ("selesai", "diambil"):
                t = tambah_menit(t, 25, 200)
                langkah.append(("Diproses", "Selesai", t, None, 2))
            if alur == "diambil":
                t = t + timedelta(minutes=random.randint(40, 60 * 30))
                if t > NOW:
                    t = NOW - timedelta(minutes=random.randint(5, 50))
                langkah.append(("Selesai", "Diambil", t, None, 2))
                o["metode"] = "Tunai" if random.random() < 0.75 else "QRIS"
                o["dibayar"] = t
    # pastikan tidak melewati NOW
    langkah = [l for l in langkah if l[2] <= NOW]
    o["langkah"] = langkah
    o["status"] = langkah[-1][1]
    if "t_proses" in o and o["t_proses"] > NOW:
        del o["t_proses"]
    o["updated"] = langkah[-1][2]
    o["total"] = sum(HARGA[l] * j for l, j, _ in o["items"])

# Pemakaian bahan untuk pesanan data uji tim yang stoknya sudah dikurangi (id 4, 5, 7)
TIM = [(4, datetime(2026, 10, 29, 2, 52, 36), [(1, 2)]),
       (5, datetime(2026, 10, 29, 4, 1, 13), [(1, 1)]),
       (7, datetime(2026, 11, 8, 17, 20, 25), [(1, 2)])]

# ---------------------------------------------------------------- simulasi stok
events = []  # (waktu, bahan, delta, jenis, pesanan_id, keterangan)
for o in orders:
    if "t_proses" not in o:
        continue
    for l, j, _ in o["items"]:
        for b, k in BOM.get(l, []):
            events.append((o["t_proses"], b, -(k * j), "keluar", o["id"], f"Pemakaian pesanan {o['kode']}"))
for pid_tim, t, its in TIM:
    for l, j in its:
        for b, k in BOM.get(l, []):
            events.append((t, b, -(k * j), "keluar", pid_tim, "Pemakaian pesanan data uji tim"))
events.sort(key=lambda e: e[0])

saldo = {b: Decimal(str(STOK_AWAL[b])) for b in STOK_AWAL}
riwayat = []
for b in sorted(saldo):
    riwayat.append((START.replace(hour=7), b, saldo[b], "masuk", None, "Stok awal", 3, Decimal(0), saldo[b]))

hari = START
idx = 0
while hari.date() <= NOW.date():
    pagi = datetime.combine(hari.date(), time(7, 30))
    if hari.weekday() != 6:
        for b in sorted(saldo):
            if b in STOP_RESTOCK and pagi >= STOP_RESTOCK[b]:
                continue
            if saldo[b] < Decimal(REORDER[b]) * Decimal("1.3"):
                qty = Decimal(PAKET[b])
                riwayat.append((pagi, b, qty, "masuk", None, "Pembelian dari supplier", 3, saldo[b], saldo[b] + qty))
                saldo[b] += qty
    akhir = datetime.combine(hari.date(), time(23, 59, 59))
    while idx < len(events) and events[idx][0] <= akhir:
        t, b, d, jenis, pes, ket = events[idx]
        if saldo[b] + d < 0:
            d = -saldo[b]  # tidak boleh negatif (jarang terjadi)
        if d != 0:
            riwayat.append((t, b, d, jenis, pes, ket, 2, saldo[b], saldo[b] + d))
            saldo[b] += d
        idx += 1
    hari += timedelta(days=1)

# Stock opname: hard cover terakhir rusak 1 pcs -> habis (demo status "habis")
if saldo[8] > 0:
    t = datetime(2026, 11, 8, 19, 0)
    d = -saldo[8]
    riwayat.append((t, 8, d, "koreksi", None, "Stock opname: sisa hard cover rusak/terlipat", 3, saldo[8], Decimal(0)))
    saldo[8] = Decimal(0)

riwayat.sort(key=lambda r: r[0])

# ---------------------------------------------------------------- output SQL
out = []
w = out.append
w("-- =====================================================================")
w("-- EasyPrint - Data uji realistis (dihasilkan oleh generate_seed.py)")
w("-- Jalankan SETELAH 001_integrasi_fe_be.sql:")
w("--   psql -U postgres -d easyprint_db -f database/seed/002_data_uji.sql")
w("-- Semua akun baru memakai password yang sama dengan akun tim: EasyPrintTest2026!")
w("-- Catatan: stok bahan baku di-set ulang mengikuti simulasi sirkulasi stok.")
w("-- =====================================================================")
w("BEGIN;")
w("SET search_path = public;")
w("")
for tr in ["trg_log_status_pesanan", "trg_notifikasi_status_pesanan", "trg_pesanan_updated_at"]:
    w(f"ALTER TABLE pesanan DISABLE TRIGGER {tr};")
for tr in ["trg_log_mutasi_stok", "trg_peringatan_stok_kritis"]:
    w(f"ALTER TABLE bahan_baku DISABLE TRIGGER {tr};")
w("")
w("-- Pelanggan")
w("INSERT INTO users (id, nama, email, password, no_telepon, role, created_at) VALUES")
w(",\n".join(f"  ({i}, {q(n)}, {q(e)}, {q(PASSWORD_HASH)}, {q(t)}, 'pelanggan', '2026-09-1{i % 9} 10:00:00')"
             for i, n, e, t in PELANGGAN) + ";")
w("")
w("-- Layanan")
w("UPDATE layanan SET kategori = 'cetak' WHERE id IN (1, 3);")
w("UPDATE layanan SET kategori = 'finishing' WHERE id = 2;")
w("INSERT INTO layanan (id, nama_layanan, harga, satuan, deskripsi, kategori) VALUES")
w(",\n".join(f"  ({i}, {q(n)}, {h}, {q(s)}, {q(d)}, {q(k)})" for i, n, h, s, k, d in LAYANAN_BARU) + ";")
w("")
w("-- Bahan baku (stok final di-set di bagian akhir)")
w("INSERT INTO bahan_baku (id, nama_bahan, stok, satuan, reorder_point, harga_satuan) VALUES")
w(",\n".join(f"  ({i}, {q(n)}, 0, {q(s)}, {r}, {h})" for i, n, s, r, h in BAHAN_BARU) + ";")
w("")
w("-- Bill of Materials")
w("INSERT INTO bahan_layanan (layanan_id, bahan_baku_id, jumlah_kebutuhan) VALUES")
w(",\n".join(f"  ({l}, {b}, {k})" for l, b, k in BOM_BARU) + ";")
w("")
w("-- Pesanan")
for o in orders:
    w(f"INSERT INTO pesanan (id, kode_pesanan, user_id, total_harga, status, catatan, created_at, stok_dikurangi, "
      f"alasan_tolak, metode_bayar, dibayar_at, updated_at) VALUES ({o['id']}, {q(o['kode'])}, {o['user']}, "
      f"{o['total']}, {q(o['status'])}, {q(o['catatan'])}, {ts(o['t0'])}, {'true' if 't_proses' in o else 'false'}, "
      f"{q(o.get('alasan'))}, {q(o.get('metode'))}, {ts(o.get('dibayar'))}, {ts(o['updated'])});")
w("")
w("-- Detail pesanan (trigger trg_update_total_pesanan ikut menghitung ulang total)")
rows = []
for o in orders:
    for n, (l, j, spek) in enumerate(o["items"]):
        f = "contoh_dokumen_seed.pdf" if (n == 0 and o["file"]) else None
        rows.append(f"  ({o['id']}, {l}, {j}, {HARGA[l] * j}, {q(f)}, {q(spek)})")
w("INSERT INTO detail_pesanan (pesanan_id, layanan_id, jumlah, subtotal, file_dokumen, spesifikasi) VALUES")
w(",\n".join(rows) + ";")
w("")
w("-- Riwayat status")
rows = []
for o in orders:
    for lama, baru, t, ket, oleh in o["langkah"]:
        rows.append(f"  ({o['id']}, {q(lama)}, {q(baru)}, {q(ket)}, {oleh}, {ts(t)})")
w("INSERT INTO riwayat_status (pesanan_id, status_lama, status_baru, keterangan, diubah_oleh, created_at) VALUES")
w(",\n".join(rows) + ";")
w("")
w("-- Riwayat stok: ganti stok awal hasil migrasi dengan simulasi lengkap")
w("DELETE FROM riwayat_stok WHERE keterangan = 'Stok awal (migrasi)';")
rows = [f"  ({b}, {pes if pes else 'NULL'}, {q(j)}, {dec(d)}, {dec(sb)}, {dec(ss)}, {q(k)}, {u}, {ts(t)})"
        for t, b, d, j, pes, k, u, sb, ss in riwayat]
w("INSERT INTO riwayat_stok (bahan_baku_id, pesanan_id, jenis, jumlah, stok_sebelum, stok_sesudah, keterangan, user_id, created_at) VALUES")
w(",\n".join(rows) + ";")
w("")
w("-- Stok final (trigger fn_update_status_bahan menghitung status tersedia/kritis/habis)")
for b in sorted(saldo):
    w(f"UPDATE bahan_baku SET stok = {dec(saldo[b])} WHERE id = {b};")
w("")
w("-- Notifikasi aktivitas 4 hari terakhir")
batas = NOW - timedelta(days=4)
for o in orders:
    for lama, baru, t, ket, _ in o["langkah"]:
        if t < batas:
            continue
        dibaca = "true" if t < NOW - timedelta(days=1) else "false"
        if lama is None:
            judul, pesan = "Pesanan Dibuat", f"Pesanan {o['kode']} berhasil dibuat dan menunggu verifikasi."
            penerima = [o["user"], 2]
        else:
            judul = "Perubahan Status Pesanan"
            pesan = f"Pesanan {o['kode']} berubah status dari {lama} menjadi {baru}" + (f". {ket}" if ket else "")
            penerima = [o["user"]]
        w("WITH n AS (INSERT INTO notifikasi (pesanan_id, judul, pesan, created_at) VALUES "
          f"({o['id']}, {q(judul)}, {q(pesan)}, {ts(t)}) RETURNING id) "
          "INSERT INTO notifikasi_users (notifikasi_id, user_id, is_read) "
          + " UNION ALL ".join(f"SELECT id, {u}, {dibaca} FROM n" for u in penerima) + ";")
for b in sorted(saldo):
    if saldo[b] <= REORDER[b]:
        judul = "Stok Habis" if saldo[b] <= 0 else "Stok Kritis"
        pesan = f"{NAMA_BAHAN[b]} tersisa {saldo[b].normalize():f} {SATUAN[b]} (reorder point {REORDER[b]})."
        w("WITH n AS (INSERT INTO notifikasi (pesanan_id, judul, pesan, created_at) VALUES "
          f"(NULL, {q(judul)}, {q(pesan)}, '2026-11-09 07:30:00') RETURNING id) "
          "INSERT INTO notifikasi_users (notifikasi_id, user_id, is_read) "
          "SELECT id, 2, false FROM n UNION ALL SELECT id, 3, false FROM n;")
w("")
for tr in ["trg_log_status_pesanan", "trg_notifikasi_status_pesanan", "trg_pesanan_updated_at"]:
    w(f"ALTER TABLE pesanan ENABLE TRIGGER {tr};")
for tr in ["trg_log_mutasi_stok", "trg_peringatan_stok_kritis"]:
    w(f"ALTER TABLE bahan_baku ENABLE TRIGGER {tr};")
w("")
w("-- Sinkronkan sequence identity")
for tabel in ["users", "layanan", "bahan_baku", "bahan_layanan", "pesanan", "detail_pesanan",
              "notifikasi", "notifikasi_users", "riwayat_status", "riwayat_stok"]:
    w(f"SELECT setval(pg_get_serial_sequence('{tabel}', 'id'), (SELECT MAX(id) FROM {tabel}));")
w("")
w("COMMIT;")
print("\n".join(out))

import sys
print(f"-- ringkasan: {len(orders)} pesanan, {len(riwayat)} mutasi stok, stok akhir: "
      + ", ".join(f"{NAMA_BAHAN[b]}={saldo[b].normalize():f}" for b in sorted(saldo)), file=sys.stderr)
