# Laporan Analisis & Integrasi — EasyPrint (Kelompok 2 TI-2D)

Tanggal: 9 November 2026 · Ruang lingkup: Frontend, Backend, Database, dan kesesuaian dengan dokumen PBL

## 1. Ringkasan

**Kondisi awal.** Ketiga bagian sudah dikerjakan dengan baik secara terpisah, tetapi **belum tersambung sama sekali**:

- **Frontend** (26 halaman, desain rapi sesuai Figma) masih 100% memakai data contoh dari `includes/mock/*.php`.
  Halaman login bahkan menentukan peran hanya dari awalan email, tanpa memeriksa password.
- **Backend** (REST API native PHP, ±20 endpoint) sudah cukup matang: prepared statement, `password_hash`, token
  ber-hash SHA-256, transaksi + `FOR UPDATE` untuk potong stok. Tetapi belum dipakai frontend, beberapa endpoint
  yang dibutuhkan layar belum ada, dan ada bug yang memunculkan error 500.
- **Database** (7 tabel, 6 trigger, 1 view, 1 fungsi) sudah ternormalisasi dengan constraint yang baik, tetapi belum
  bisa menyimpan beberapa data yang diminta desain: status Ditolak, spesifikasi cetak, mutasi stok, dan pembayaran.
  View dan fungsinya juga belum dipakai aplikasi, padahal itu syarat penilaian Basis Data Lanjut.

**Hasil integrasi.** Semua halaman sekarang membaca dan menulis data nyata lewat REST API, sesuai arsitektur SOP
*pblguide*: frontend di :3000 tanpa koneksi database, backend di :8000. Alur bisnis lengkap sudah diuji di browser
untuk tiga peran: pesan → verifikasi → proses (stok terpotong otomatis) → selesai → kasir → struk, ditambah alur
tolak, tertunda karena stok, restock, CRUD master, laporan, dan notifikasi.
Hasil uji: **0 error JavaScript, 0 respons HTTP 5xx, 0 warning PHP**.

---

## 2. Bahan yang dianalisis

| Bahan | Isi utama yang dipakai sebagai acuan |
|---|---|
| `PBL_2026_-_Requirement.pdf` | Syarat BDL: 3–5 entitas ≥3NF, PK/FK + constraint tambahan, join/agregasi/subquery/CTE **yang dipakai fitur**, ≥1 view & ≥1 fungsi/SP/trigger **yang dipakai fitur**, data uji memadai |
| `RPP-PBL-TI-Sem3.pdf` | Syarat DPW: full-stack terhubung DB nyata (bukan dummy statis), ≥3 halaman utama, login/logout + otorisasi ≥2 peran, **CRUD lengkap entitas utama**, validasi & error informatif, struktur kode terpisah (MVC), prepared statement, password ter-hash. SIM: dashboard teragregasi (tren/perbandingan periode) |
| `Revisi_Proposal_Kelompok_2.pdf` | 3 peran & hak akses, 6 status tracking (DEC-02), reorder point, laporan transaksi & sirkulasi stok, nota digital |
| `Frame_1_1.pdf` | Userflow, ERD, deskripsi 16 layar (termasuk tombol **Tolak dengan catatan penolakan**, preview berkas, kasir & struk) |
| `pblguide.nyxora.life` | SOP: FE Native PHP :3000 **tanpa query DB**, `includes/api_client.php` (cURL), BE :8000 JSON murni + CORS, struktur `backend/config`, `models/StokModel.php`, endpoint CP-1…CP-4 |
| `Frontend.zip`, `Backend.zip`, `easy_print.sql` | Kode & dump yang diintegrasikan |

---

## 3. Temuan pada kode awal

Tingkat dampak: 🔴 kritis (fitur tidak jalan / celah keamanan) · 🟠 tinggi (error atau data salah) · 🟡 sedang (UX/kerapian)

### 3.1 Frontend

| # | Lokasi | Temuan | Dampak |
|---|---|---|---|
| F1 | semua `pages/*.php` | Data dari `includes/mock/*.php`; tidak ada satu pun pemanggilan API | 🔴 |
| F2 | `pages/login.php` | Peran ditentukan dari awalan email (`owner…` → owner), password tidak diperiksa, tidak ada sesi | 🔴 keamanan |
| F3 | `pages/register.php` | `action="login.php"` → data pendaftaran dibuang | 🔴 |
| F4 | `assets/js/order-review.js` | Tombol *Kirim Pesanan* hanya redirect ke tracking; pesanan tidak pernah dikirim | 🔴 |
| F5 | `assets/js/owner-report.js` | Baris `<td …>` tersasar di akhir file → **SyntaxError**, tabel transaksi tidak pernah tampil | 🟠 |
| F6 | `components/admin-head.php` | `<body class="admin"></body>` langsung ditutup, dan `admin-extra.css` tidak pernah dimuat → Dashboard Admin (`.opk`, `.ops`), struk (`.receipt`), dan modal (`.mdl`) tanpa gaya | 🟠 |
| F7 | `assets/js/admin-orders.js` | Tombol *Preview* hanya `return` string; aksi Terima/Tolak hanya mengubah array di memori | 🟠 |
| F8 | `order-form` | Berkas di langkah 2 tidak bisa dibawa ke langkah 3 (sessionStorage hanya teks). Batas 20 MB + `.doc` tidak sama dengan backend (10 MB, PDF/DOCX) | 🟠 |
| F9 | `pages/check-result.php` | Pencarian hanya memakai kode ("validasi telepon dilakukan backend nanti") → siapa pun yang tahu kode bisa melihat pesanan orang lain | 🟠 privasi |
| F10 | `components/stepper2.php` | Status *Diverifikasi* tidak dikenali (indeks aktif kembali ke 0) | 🟡 |
| F11 | `components/sidebar-admin.php` | Menu Dashboard admin `href="#"`; nama/email akun di-hardcode | 🟡 |
| F12 | `components/navbar-app.php` | *Keluar* hanya tautan ke login.php (tidak ada logout) | 🟡 |
| F13 | `pages/landing.php` | Navbar menaut ke `#layanan`, tetapi bagian katalog & harga (diminta Frame) tidak ada | 🟡 |
| F14 | `tracking*.php` | Tiga halaman tracking memilih pesanan berdasarkan indeks array mock | 🟡 |
| F15 | CSS | Landing punya scroll horizontal (dekorasi `deco--circle-right`); appbar pelanggan meluber ±30 px di HP | 🟡 |

### 3.2 Backend

| # | Lokasi | Temuan | Dampak |
|---|---|---|---|
| B1 | `POST /api/layanan` | `INSERT` tanpa kolom `satuan` (NOT NULL) → **setiap tambah layanan gagal 500** | 🔴 |
| B2 | `PATCH /api/orders/status` | Tidak ada validasi alur status (bisa Pending→Diambil, Diambil→Pending) | 🟠 |
| B3 | `models/StokModel.php` | Layanan tanpa konfigurasi bahan → `RuntimeException` → 500 (layanan baru tidak bisa diproses) | 🟠 |
| B4 | `PATCH /api/orders/status` | Pesanan Tertunda yang stoknya sudah pernah dipotong tidak bisa dilanjutkan ("sudah ditandai pernah dikurangi") | 🟠 |
| B5 | `public/index.php`, `models/StokModel.php` | Baris kosong sebelum `<?php` → output sebelum `header()`: warning *headers already sent* bila `output_buffering` mati (umum di Laragon/CLI), dan JSON diawali newline | 🟠 |
| B6 | `PATCH /api/orders/status` | Notifikasi status ditautkan dengan mengambil "notifikasi terakhir milik pesanan" → rawan salah tautan bila ada notifikasi lain | 🟡 |
| B7 | `DELETE /api/layanan/{id}` | Layanan yang sudah dipakai pesanan → 500 (FK RESTRICT) dengan pesan generik | 🟡 |
| B8 | hak akses | Admin boleh CRUD layanan & mengubah reorder point, padahal proposal menempatkannya pada Owner | 🟡 |
| B9 | `date('Ymd')` | Tanpa zona waktu → antara 00.00–07.00 WIB, kode pesanan memakai tanggal kemarin (UTC) | 🟡 |
| B10 | endpoint hilang | Belum ada: logout, unduh/preview berkas (fitur anti-misprint), cek pesanan publik, tambah/hapus bahan, CRUD konfigurasi bahan, riwayat stok, laporan per periode | 🟠 |
| B11 | struktur | Seluruh API di satu `index.php` ±1.200 baris berupa rantai `if` (RPP meminta pemisahan logika) | 🟡 |

### 3.3 Database

| # | Temuan | Dampak |
|---|---|---|
| D1 | Status **Ditolak** tidak ada di CHECK, padahal ada di Frame, halaman `tracking-ditolak`, dan mock | 🟠 |
| D2 | Tidak ada tabel mutasi stok → laporan *sirkulasi bahan* (Proposal 5.3 Owner no. 3) tidak bisa dibuat | 🟠 |
| D3 | Spesifikasi cetak (lembar × eksemplar, sisi) dan metode bayar tidak punya tempat penyimpanan | 🟡 |
| D4 | `v_detail_pesanan` dan `fn_ringkasan_pesanan` tidak dipakai backend → belum memenuhi "benar-benar digunakan oleh fitur aplikasi" | 🟠 penilaian |
| D5 | Data uji minim (8 pesanan, 3 layanan, 3 bahan, 2 BOM). Pesanan #5 dibuat oleh akun admin; satu path berkas `storage/uploads/...` tidak sesuai folder upload | 🟡 |
| D6 | Trigger `fn_cek_stok_bahan` & `fn_cek_harga_layanan` menduplikasi CHECK constraint yang sudah ada (tidak salah, hanya redundan; pesan error-nya ramah sehingga dipertahankan) | info |

---

## 4. Yang dikerjakan

### 4.1 Database — `database/migrations/001_integrasi_fe_be.sql`

Dump asli **tidak diubah**. Semua perubahan ada di satu file migrasi yang idempoten dan diberi komentar alasannya.

| Perubahan | Untuk fitur |
|---|---|
| `pesanan`: status `Ditolak` + `alasan_tolak` (CHECK: Ditolak wajib beralasan), `metode_bayar` (CHECK Tunai/QRIS/Transfer), `dibayar_at`, `updated_at` | Tolak dengan catatan, kasir & struk |
| `detail_pesanan.spesifikasi` | Rincian cetak di antrean, tracking, nota |
| `layanan.kategori` (CHECK cetak/fotokopi/finishing), `layanan.aktif` | Katalog per kategori; layanan berhistori dinonaktifkan, bukan dihapus |
| Tabel **`riwayat_status`** + trigger `trg_log_status_pesanan` | Timeline tracking & "riwayat aktivitas" (siapa, kapan, alasan) |
| Tabel **`riwayat_stok`** + trigger `trg_log_mutasi_stok` | Log stok otomatis, laporan sirkulasi bahan masuk/keluar |
| Trigger **`trg_peringatan_stok_kritis`** | Notifikasi otomatis ke admin & owner saat stok menyentuh reorder point |
| Trigger `fn_notifikasi_status_pesanan` diperbarui | Notifikasi langsung ditautkan ke pelanggan (memperbaiki B6) |
| View **`v_kebutuhan_bahan_pesanan`** | Kolom "Kebutuhan bahan vs stok" di panel antrean admin |
| `fn_konteks()` + `set_config('easyprint.*')` | API mengirim konteks aktor/keterangan ke trigger dalam transaksi yang sama |
| 4 indeks (`pesanan.user_id/status/created_at`, `detail_pesanan.pesanan_id`) | Kecepatan filter antrean & laporan |

**Data uji** (`database/seed/002_data_uji.sql`, dibuat oleh `generate_seed.py` dengan seed acak tetap):
8 pelanggan, 9 layanan, 9 bahan, 15 BOM, **98 pesanan** (14 Sep – 9 Nov 2026, semua status terwakili), 459 riwayat
status, 229 mutasi stok yang konsisten (stok awal → pemakaian per pesanan → pembelian supplier), dan notifikasi
4 hari terakhir. Hasil akhir sengaja menyisakan 1 bahan kritis dan 1 bahan habis untuk demo reorder point & DEC-02.

### 4.2 Fitur basis data lanjut yang kini dipakai aplikasi

| Syarat BDL | Implementasi | Dipakai di |
|---|---|---|
| Join multi-tabel | `GET /orders` (pesanan⋈users⋈detail⋈layanan + `STRING_AGG`) | Antrean admin, Pesanan Saya |
| Agregasi + **HAVING** | Layanan terpopuler `GROUP BY … HAVING COUNT(DISTINCT pesanan_id) > 0` | Dashboard Owner |
| **Subquery** | Nilai bahan keluar (subquery agregat ⋈ bahan_baku); jumlah pemakaian layanan | Laporan; Master Layanan |
| **CTE** | `WITH per_bulan` (KPI bulan ini vs bulan lalu); `WITH penjualan_layanan` + `RANK()` | Dashboard & Laporan Owner |
| Window function | Persentase layanan `SUM(COUNT(...)) OVER ()`; `RANK() OVER` | Dashboard & Laporan |
| `generate_series` + LEFT JOIN | Tren 7 hari (hari tanpa pesanan tetap 0) | Dashboard Owner |
| Agregasi bersyarat `FILTER` | Masuk/keluar per bahan, ringkasan laporan | Stok, Laporan |
| **View** | `v_detail_pesanan` (dump tim) → rincian & layanan teratas laporan; `v_kebutuhan_bahan_pesanan` → panel antrean | Laporan; Antrean Admin |
| **Fungsi** | `fn_ringkasan_pesanan(dari, sampai)` (dump tim) → KPI "pesanan masuk" | Laporan Owner |
| **Trigger** (10 aktif) | total pesanan otomatis, status bahan tersedia/kritis/habis, validasi, notifikasi status, log status, log mutasi stok, peringatan stok kritis, updated_at | Seluruh alur |
| Transaksi & penguncian | `BEGIN … SELECT … FOR UPDATE … COMMIT` saat potong stok dan ubah status | Proses pesanan |

### 4.3 Backend

- Disusun ulang menjadi `public/index.php` (front controller + tabel rute) → `controllers/*` → `models/StokModel.php`,
  dengan helper `core/http.php` (respons, validasi) dan `core/auth.php` (Bearer + `require_user(['admin'])`).
  **URL dan bentuk respons lama dipertahankan**, jadi koleksi Apidog tim tetap berlaku.
- Memperbaiki seluruh temuan B1–B11, termasuk state machine status pesanan, BOM kosong, kelanjutan dari Tertunda,
  hak akses owner, dan zona waktu WIB (PHP + sesi PostgreSQL).
- 16 endpoint baru (lihat `docs/API.md`), di antaranya `/orders/{id}/file` (stream berkas dengan pemeriksaan
  kepemilikan + `basename()` anti path-traversal), `/track` (cek publik: kode **dan** telepon harus cocok, nomor
  disamarkan), `/laporan/transaksi`, `/stok/riwayat`, serta CRUD bahan dan BOM.
- Penanganan error terpusat: tanpa stack trace ke klien; error PostgreSQL dipetakan ke 400/409 dengan pesan yang jelas;
  pesan `RAISE EXCEPTION` dari trigger diteruskan apa adanya.
- `config/database.php` membaca `DB_*` dari environment atau `config/env.php` (di-.gitignore) sesuai SOP.

### 4.4 Frontend

- `includes/api_client.php` → `callBackendApi()` (cURL, sesuai SOP CP-1) dipakai semua halaman untuk render server-side.
- Login/registrasi memanggil API; token disimpan di **sesi PHP** (cookie `httpOnly`, `SameSite=Lax`, ID sesi
  diregenerasi), dengan CSRF token pada form, `require_role()` per halaman, redirect sesuai peran, dan logout yang
  menghapus token di server.
- Aksi JavaScript (ubah status, CRUD, upload) memakai `fetch()` ke `public/api-proxy.php`, yang meneruskan ke backend
  dengan token dari sesi. Token tidak pernah terekspos ke JavaScript, sehingga aman dari pencurian lewat XSS. Request
  yang mengubah data wajib membawa header `X-Requested-With: EasyPrint` sebagai lapisan anti-CSRF.
- Alur pesanan 3 langkah dipertahankan. Berkas disimpan sementara di **IndexedDB** (`draft-file.js`) agar tetap
  tersedia di langkah review tanpa upload ganda. Pilihan layanan diambil dari katalog API; estimasi di browser memakai
  rumus yang sama dengan backend.
- Tiga halaman tracking digabung menjadi `tracking.php?id=` yang menyesuaikan status (normal / tertunda / ditolak /
  siap diambil), dengan timeline dari `riwayat_status`.
- Antrean admin: filter 8 status + "Perlu tindakan", pencarian kode/nama/telepon, panel detail (item, preview berkas,
  kebutuhan bahan vs stok, riwayat), dan aksi sesuai status (Verifikasi, Proses, Tunda, Tolak+alasan, Selesai, ke Kasir).
- Halaman baru: `profil.php` (melengkapi CRUD users), `file.php` (preview berkas), `logout.php`, `api-proxy.php`.
- Seluruh bug F1–F15 diperbaiki. Gaya tambahan dikumpulkan di `assets/css/integrasi.css` agar CSS asli tim tidak terusik.

### 4.5 Pemetaan halaman ↔ endpoint

| Halaman | Peran | Endpoint |
|---|---|---|
| index (landing) | publik | `GET /layanan` |
| login, register, logout | publik | `POST /login`, `POST /register`, `POST /logout` |
| check-order → check-result | publik | `GET /track` |
| dashboard | pelanggan | `GET /orders`, `GET /layanan` |
| order-service → order-form → order-review → order-success | pelanggan | `GET /layanan`, `POST /orders` (multipart), `GET /orders/{id}` |
| orders, tracking, invoice, profil | pelanggan | `GET /orders`, `DELETE /orders/{id}`, `GET /orders/{id}`, `GET /orders/{id}/invoice`, `GET/PATCH /me` |
| panel notifikasi (semua peran) | login | `GET /notifications`, `PATCH /notifications/read`, `DELETE /notifications[/{id}]` |
| admin-dashboard | admin | `GET /dashboard`, `GET /stok` |
| admin-orders | admin | `GET /orders`, `GET /orders/{id}`, `PATCH /orders/status`, `GET /orders/{id}/file` |
| admin-cashier → admin-receipt | admin | `GET /orders?q=`, `GET /orders?status=Selesai`, `PATCH /orders/status` (Diambil + metode) |
| admin-stock | admin | `GET /stok`, `GET /stok/riwayat`, `POST /stok/{id}/restock`, `PATCH /stok/{id}` |
| owner-dashboard | owner | `GET /dashboard` |
| owner-report | owner | `GET /laporan/transaksi`, `GET /dashboard` (rekap bulanan) |
| owner-inventory | owner | `GET/POST /stok`, `PATCH/DELETE /stok/{id}`, `POST /stok/{id}/restock` |
| owner-services | owner | `GET /layanan?semua=1`, `POST/PATCH/DELETE /layanan`, `POST/PATCH/DELETE /bahan-layanan`, `GET /stok` |

---

## 5. Kepatuhan terhadap requirement (setelah integrasi)

| Requirement | Sebelum | Sesudah |
|---|---|---|
| DPW: terhubung ke basis data nyata, bukan dummy statis | ❌ mock | ✅ |
| DPW: login/logout + otorisasi ≥2 peran | ❌ login palsu | ✅ 3 peran, dicek di FE (halaman) **dan** BE (endpoint) |
| DPW: CRUD lengkap entitas utama | ⚠️ sebagian, dan tambah layanan error | ✅ users (daftar/profil), layanan, bahan_baku, bahan_layanan, pesanan (buat/lihat/ubah status/batal), notifikasi |
| DPW: validasi input & error informatif | ⚠️ | ✅ HTML5 + JS + validasi server, pesan berbahasa Indonesia, tanpa stack trace |
| DPW: struktur kode terpisah | ⚠️ satu file BE | ✅ router / controller / model / core; FE pages / components / includes |
| DPW: prepared statement, password ter-hash | ✅ | ✅ (+ CSRF, sesi httpOnly, token tidak terekspos, cek MIME upload) |
| BDL: view & fungsi/trigger dipakai fitur | ❌ tidak dipakai | ✅ 2 view, 1 fungsi, 10 trigger dipakai |
| BDL: join / agregasi / HAVING / subquery / CTE dipakai fitur | ⚠️ join & group by saja | ✅ semuanya (lihat 4.2) |
| BDL: data uji realistis & memadai | ⚠️ 8 pesanan | ✅ 106 pesanan, 2 bulan sirkulasi stok |
| SIM: dashboard teragregasi (tren, perbandingan periode) | ❌ mock | ✅ KPI vs periode setara bulan lalu, tren 7 hari, layanan populer, rekap bulanan, sirkulasi bahan, ekspor CSV/PDF |
| Proposal: 6 status (DEC-02) + Tertunda otomatis bila stok kurang | ⚠️ hanya di API | ✅ ujung ke ujung, termasuk notifikasi & tampilan pelanggan |
| Proposal: reorder point & peringatan stok | ⚠️ hanya query | ✅ trigger → notifikasi admin/owner, badge Kritis/Habis, dashboard |
| SOP: FE :3000 tanpa DB, BE :8000 JSON, `api_client.php` cURL, CORS | ⚠️ FE belum memanggil API | ✅ |

---

## 6. Hasil pengujian

Lingkungan uji: PHP 8.3.6, PostgreSQL 16.15, Chrome headless (Playwright), viewport 1440×1000 dan 390×844.

| Skenario | Hasil |
|---|---|
| Restore dump asli → migrasi → seed; restore `easyprint_db_lengkap.sql` ke database baru | ✅ tanpa error |
| API (curl): login 3 peran, 401/403/404/405, register duplikat (409), validasi angka negatif, berkas PDF palsu ditolak, transisi status tidak sah ditolak (409), Ditolak tanpa alasan ditolak, potong stok + log, tertunda otomatis, lanjut setelah restock, CRUD layanan/BOM/bahan, nonaktif layanan berhistori, notifikasi baca/hapus, batal pesanan, ubah profil, logout | ✅ |
| Browser pelanggan: login salah → pesan; registrasi (konfirmasi password salah → pesan) → auto login; buat pesanan Print+Jilid dengan upload; fotokopi tanpa berkas; jilid saja; batalkan pesanan; tracking; notifikasi; nota; profil; logout | ✅ |
| Browser admin: dashboard; antrean → Verifikasi → Proses → Selesai; Tolak dengan alasan; kasir QRIS → struk; restock; retry pesanan tertunda | ✅ |
| Browser owner: dashboard; laporan periode; tambah bahan; tambah layanan; owner membuka halaman admin → dialihkan | ✅ |
| Cek pesanan publik: kode + telepon benar → tampil; salah → pesan "tidak ditemukan" | ✅ |
| Error JavaScript / HTTP 5xx / warning PHP selama seluruh uji | **0** |
| Layar HP 390 px (dashboard, tracking, pesanan, form): tidak ada scroll horizontal | ✅ |

---

## 7. Catatan & rekomendasi untuk tim

1. **Git & SOP branch.** Perubahan ini besar dan menyentuh semua folder. Sesuai Team Charter (1 orang 1 branch, PR ke
   Evan), sebaiknya dipecah menjadi beberapa PR, misalnya: `feat/db-migrasi-integrasi` (Rama/Daniel),
   `feat/be-api-endpoints` (Fawas), `feat/fe-integrasi-api` (Najwa). Dengan begitu riwayat commit tetap mencerminkan
   pembagian kerja, karena RPP menilai Git sepanjang pengembangan, bukan satu commit besar.
2. **Change Log / Governance.** Catat keputusan baru sebagai DEC: status *Ditolak* (dari Frame, di luar 6 status
   proposal), tabel `riwayat_status` & `riwayat_stok`, serta pembatasan CRUD layanan & reorder point hanya untuk Owner.
3. **Dokumen BDL (Milestone 1–3).** Perbarui CDM/PDM/ERD dan data dictionary: 2 tabel baru, 7 kolom baru,
   constraint baru, 1 view, 4 trigger baru. Bagian 4.2 di atas bisa langsung dipakai sebagai daftar "query lanjut
   yang dipakai fitur" untuk Milestone 3.
4. **Perbedaan dengan contoh kode pblguide** (dipertahankan, bukan kesalahan): nama kolom dump tim (`id`, `user_id`,
   `status`) berbeda dari contoh di guide (`id_user`, `status_pesanan`); CSS kustom tim dipakai menggantikan Tailwind
   CDN pada contoh. Kunci body `id_pesanan` / `status_pesanan` pada `PATCH /orders/status` tetap sama dengan guide.
5. **Data uji tim** (pesanan "Tes CP2", pesanan yang dibuat akun admin, kode `EP-…`/`ORD-…`) masih disimpan apa
   adanya. Pertimbangkan untuk dibersihkan sebelum UAT bersama mitra.
6. **Menjelang deploy/Expo:** gunakan HTTPS (aktifkan `secure` pada cookie sesi), batasi percobaan login, ganti
   password akun uji, dan isi `CORS_ORIGINS` sesuai domain.
7. **Di luar ruang lingkup** (sesuai proposal 4.2): notifikasi WhatsApp, payment gateway, integrasi mesin cetak.
   Notifikasi saat ini tampil di dalam aplikasi (ikon lonceng).
8. Halaman admin dan owner sudah rapi di desktop dan tablet. Untuk layar HP, tabel lebar bisa di-scroll horizontal,
   tetapi tampilannya masih bisa dipoles lagi di CP-4 (responsif).
