# Referensi REST API EasyPrint

Base URL: `http://127.0.0.1:8000/api` · Semua respons JSON `{"status":"success"|"error", ...}`
Autentikasi: header `Authorization: Bearer <access_token>` (didapat dari `POST /login`, berlaku 8 jam).

Kode status: `200` OK · `201` Created · `400` validasi · `401` belum login/token kedaluwarsa · `403` peran tidak berhak ·
`404` tidak ditemukan · `405` metode salah · `409` konflik (duplikat, transisi status tidak sah, data masih berelasi) · `500` server.

> Endpoint bertanda ★ sudah ada di backend tim (kontrak request/response dipertahankan); sisanya ditambahkan saat integrasi.

## Autentikasi & profil

| Metode | Endpoint | Peran | Body / query | Keterangan |
|---|---|---|---|---|
| GET | `/health` ★ | publik | – | cek API + koneksi database |
| POST | `/register` ★ | publik | `nama, email, password(≥8), no_telepon?` | selalu membuat peran `pelanggan` |
| POST | `/login` ★ | publik | `email, password` | → `access_token`, `user{id,nama,email,role}` |
| POST | `/logout` | login | – | menghapus token dari `auth_tokens` |
| GET | `/me` ★ | login | – | profil sendiri |
| PATCH | `/me` | login | `nama, no_telepon?, password_lama?, password_baru?` | ubah profil / password |

## Layanan & Bill of Materials

| Metode | Endpoint | Peran | Body / query | Keterangan |
|---|---|---|---|---|
| GET | `/layanan` ★ | publik | `?semua=1` (owner: termasuk nonaktif) | kini menyertakan `satuan, kategori, deskripsi, aktif, bahan[]` |
| POST | `/layanan` ★ | owner | `nama_layanan, harga, satuan, kategori, deskripsi?, aktif?` | |
| PATCH/PUT | `/layanan/{id}` ★ | owner | sama dengan POST | |
| DELETE | `/layanan/{id}` ★ | owner | – | bila sudah dipakai pesanan → **dinonaktifkan**, bukan dihapus |
| GET | `/bahan-layanan` | admin, owner | – | daftar konfigurasi bahan per layanan |
| POST | `/bahan-layanan` | owner | `layanan_id, bahan_baku_id, jumlah_kebutuhan` | |
| PATCH | `/bahan-layanan/{id}` | owner | `jumlah_kebutuhan` | |
| DELETE | `/bahan-layanan/{id}` | owner | – | |

## Pesanan

| Metode | Endpoint | Peran | Body / query | Keterangan |
|---|---|---|---|---|
| POST | `/orders` ★ | login | multipart: `items` (JSON string), `catatan?`, `file_dokumen?` (PDF/DOCX ≤10 MB) · atau JSON `{items:[...]}` | `items[] = {layanan_id, jumlah, spesifikasi?}`. Harga dihitung server. → `id_pesanan, kode_pesanan` |
| GET | `/orders` ★ | login | `?status=Pending,Diproses` `?q=kode/nama/telepon` `?limit=` | pelanggan: miliknya; admin/owner: semua |
| GET | `/orders/{id}` ★ | pemilik / staf | – | `pesanan, items, riwayat[]`, untuk staf + `kebutuhan_bahan[]` |
| GET | `/orders/{id}/invoice` ★ | pemilik / staf | – | data nota (`lunas`, `metode_bayar`, item) |
| GET | `/orders/{id}/file` | pemilik / staf | – | unduh/pratinjau berkas (stream, bukan JSON) |
| PATCH | `/orders/status` ★ | admin | `id_pesanan, status_pesanan, alasan?` (wajib utk Ditolak), `metode_bayar?` (Tunai/QRIS/Transfer utk Diambil) | memotong stok saat → Diproses; bila kurang otomatis → *Tertunda - Stok Tidak Tersedia* |
| DELETE | `/orders/{id}` | pelanggan pemilik | – | batalkan pesanan berstatus Pending |
| GET | `/track` | publik | `?kode=RI-...&telepon=08...` | cek status tanpa login (nomor telepon harus cocok) |

Alur status yang diizinkan:

```
Pending ──► Diverifikasi ──► Diproses ──► Selesai ──► Diambil
   │             │  ▲            │
   │             │  └── Tertunda / Tertunda - Stok Tidak Tersedia ◄┘
   └─────────────┴──► Ditolak  (status akhir, wajib alasan)
```
(`Pending → Diproses` juga diizinkan untuk verifikasi + proses sekaligus.)

## Notifikasi

| Metode | Endpoint | Peran | Body | Keterangan |
|---|---|---|---|---|
| GET | `/notifications` ★ | login | `?limit=` | + `belum_dibaca`, `kode_pesanan` |
| PATCH | `/notifications/read` ★ | login | `{id_notifikasi}` atau `{semua:true}` | |
| DELETE | `/notifications/{id}` | login | – | hapus dari kotak notifikasi sendiri |
| DELETE | `/notifications` | login | – | bersihkan semua |

## Stok bahan baku

| Metode | Endpoint | Peran | Body / query | Keterangan |
|---|---|---|---|---|
| GET | `/stok` ★ | admin, owner | – | + `stok_kritis, masuk_bulan_ini, keluar_bulan_ini` |
| POST | `/stok` | owner | `nama_bahan, satuan, stok?, reorder_point?, harga_satuan?` | |
| PATCH | `/stok/{id}` ★ | admin: `stok`+`keterangan` · owner: semua kolom | | koreksi stok (DEC-04) tercatat sebagai `koreksi` |
| DELETE | `/stok/{id}` | owner | – | ditolak bila masih dipakai konfigurasi layanan |
| POST | `/stok/{id}/restock` | admin, owner | `jumlah, keterangan?, tanggal?` | pasokan masuk |
| GET | `/stok/riwayat` | admin, owner | `?bahan_id=&limit=` | log mutasi (masuk/keluar/koreksi) |
| GET | `/laporan/stok` ★ | admin, owner | – | kondisi stok vs reorder point |

## Dashboard & laporan

| Metode | Endpoint | Peran | Query | Isi |
|---|---|---|---|---|
| GET | `/dashboard` ★ | admin, owner | – | `rekap_omzet`★, `stok_kritis`★, `kpi`, `tren_7_hari`, `layanan_populer`, `per_status`, `prioritas` |
| GET | `/laporan/transaksi` | owner, admin | `?dari=YYYY-MM-DD&sampai=YYYY-MM-DD` | `ringkasan`, `transaksi[]`, `layanan_teratas[]`, `sirkulasi_bahan[]` |

## Contoh (curl)

```bash
TOKEN=$(curl -s http://127.0.0.1:8000/api/login -H "Content-Type: application/json" \
  -d '{"email":"ahmad@example.com","password":"EasyPrintTest2026!"}' | php -r 'echo json_decode(stream_get_contents(STDIN))->access_token;')

curl http://127.0.0.1:8000/api/orders -H "Authorization: Bearer $TOKEN" \
  -F 'items=[{"layanan_id":1,"jumlah":40,"spesifikasi":"40 lembar x 1 eks"},{"layanan_id":8,"jumlah":1}]' \
  -F 'catatan=Mohon dijilid rapi' -F 'file_dokumen=@skripsi.pdf;type=application/pdf'
```
