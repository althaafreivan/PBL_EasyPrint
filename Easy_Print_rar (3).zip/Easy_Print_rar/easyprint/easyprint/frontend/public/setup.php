<?php
// Setup Laragon sudah selesai; halaman ini dinonaktifkan. File ini boleh dihapus.
http_response_code(404);
exit;
