<?php

require_once __DIR__ . '/backend/config/env.php';

try {
    $pdo = new PDO(
        "pgsql:host=" . getenv('DB_HOST') .
        ";port=" . getenv('DB_PORT') .
        ";dbname=" . getenv('DB_NAME'),
        getenv('DB_USER'),
        getenv('DB_PASS')
    );

    echo "KONEKSI PDO BERHASIL!" . PHP_EOL;

    echo "Database: " .
        $pdo->query("SELECT current_database()")->fetchColumn();

} catch (PDOException $e) {

    echo "KONEKSI GAGAL!" . PHP_EOL;
    echo $e->getMessage();

}